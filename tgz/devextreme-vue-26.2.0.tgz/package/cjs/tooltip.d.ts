/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Tooltip, { Properties } from "devextreme/ui/tooltip";
import { event } from "devextreme/events/events.types";
import { ContentReadyEvent, DisposingEvent, HiddenEvent, HidingEvent, InitializedEvent, OptionChangedEvent, ShowingEvent, ShownEvent } from "devextreme/ui/tooltip";
import { Position, HorizontalAlignment, VerticalAlignment, Direction, PositionAlignment } from "devextreme/common";
import { PositionConfig, AnimationConfig, CollisionResolution, AnimationState, AnimationType, CollisionResolutionCombination } from "devextreme/common/core/animation";
type AccessibleOptions = Pick<Properties, "animation" | "container" | "contentTemplate" | "deferRendering" | "disabled" | "height" | "hideEvent" | "hideOnOutsideClick" | "hideOnParentScroll" | "hint" | "hoverStateEnabled" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "onContentReady" | "onDisposing" | "onHidden" | "onHiding" | "onInitialized" | "onOptionChanged" | "onShowing" | "onShown" | "position" | "rtlEnabled" | "shading" | "shadingColor" | "showEvent" | "tabFocusLoopEnabled" | "target" | "visible" | "width" | "wrapperAttr">;
interface DxTooltip extends AccessibleOptions {
    readonly instance?: Tooltip;
}
declare const DxTooltip: import("vue").DefineComponent<{
    animation: PropType<Record<string, any>>;
    container: {};
    contentTemplate: {};
    deferRendering: BooleanConstructor;
    disabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hideEvent: PropType<string | Record<string, any>>;
    hideOnOutsideClick: PropType<boolean | ((event: event) => boolean)>;
    hideOnParentScroll: BooleanConstructor;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    maxHeight: (NumberConstructor | StringConstructor)[];
    maxWidth: (NumberConstructor | StringConstructor)[];
    minHeight: (NumberConstructor | StringConstructor)[];
    minWidth: (NumberConstructor | StringConstructor)[];
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onHidden: PropType<(e: HiddenEvent) => void>;
    onHiding: PropType<(e: HidingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onShowing: PropType<(e: ShowingEvent) => void>;
    onShown: PropType<(e: ShownEvent) => void>;
    position: PropType<Record<string, any> | Position | PositionConfig>;
    rtlEnabled: BooleanConstructor;
    shading: BooleanConstructor;
    shadingColor: StringConstructor;
    showEvent: PropType<string | Record<string, any>>;
    tabFocusLoopEnabled: BooleanConstructor;
    target: {};
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    wrapperAttr: {};
}, unknown, unknown, {
    instance(): Tooltip;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:animation": null;
    "update:container": null;
    "update:contentTemplate": null;
    "update:deferRendering": null;
    "update:disabled": null;
    "update:height": null;
    "update:hideEvent": null;
    "update:hideOnOutsideClick": null;
    "update:hideOnParentScroll": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:maxHeight": null;
    "update:maxWidth": null;
    "update:minHeight": null;
    "update:minWidth": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onHidden": null;
    "update:onHiding": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onShowing": null;
    "update:onShown": null;
    "update:position": null;
    "update:rtlEnabled": null;
    "update:shading": null;
    "update:shadingColor": null;
    "update:showEvent": null;
    "update:tabFocusLoopEnabled": null;
    "update:target": null;
    "update:visible": null;
    "update:width": null;
    "update:wrapperAttr": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    animation: PropType<Record<string, any>>;
    container: {};
    contentTemplate: {};
    deferRendering: BooleanConstructor;
    disabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hideEvent: PropType<string | Record<string, any>>;
    hideOnOutsideClick: PropType<boolean | ((event: event) => boolean)>;
    hideOnParentScroll: BooleanConstructor;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    maxHeight: (NumberConstructor | StringConstructor)[];
    maxWidth: (NumberConstructor | StringConstructor)[];
    minHeight: (NumberConstructor | StringConstructor)[];
    minWidth: (NumberConstructor | StringConstructor)[];
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onHidden: PropType<(e: HiddenEvent) => void>;
    onHiding: PropType<(e: HidingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onShowing: PropType<(e: ShowingEvent) => void>;
    onShown: PropType<(e: ShownEvent) => void>;
    position: PropType<Record<string, any> | Position | PositionConfig>;
    rtlEnabled: BooleanConstructor;
    shading: BooleanConstructor;
    shadingColor: StringConstructor;
    showEvent: PropType<string | Record<string, any>>;
    tabFocusLoopEnabled: BooleanConstructor;
    target: {};
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    wrapperAttr: {};
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:container"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:deferRendering"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hideOnOutsideClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hideOnParentScroll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onHidden"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onHiding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onShowing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onShown"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shading"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadingColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabFocusLoopEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wrapperAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hideEvent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showEvent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:target"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    deferRendering: boolean;
    hideOnParentScroll: boolean;
    shading: boolean;
    tabFocusLoopEnabled: boolean;
}>;
declare const DxAnimation: import("vue").DefineComponent<{
    hide: PropType<string | number | Record<string, any> | AnimationConfig>;
    show: PropType<string | number | Record<string, any> | AnimationConfig>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:hide": null;
    "update:show": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    hide: PropType<string | number | Record<string, any> | AnimationConfig>;
    show: PropType<string | number | Record<string, any> | AnimationConfig>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hide"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxAt: import("vue").DefineComponent<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxBoundaryOffset: import("vue").DefineComponent<{
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxCollision: import("vue").DefineComponent<{
    x: PropType<CollisionResolution>;
    y: PropType<CollisionResolution>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: PropType<CollisionResolution>;
    y: PropType<CollisionResolution>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFrom: import("vue").DefineComponent<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:left": null;
    "update:opacity": null;
    "update:position": null;
    "update:scale": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scale"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHide: import("vue").DefineComponent<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:complete": null;
    "update:delay": null;
    "update:direction": null;
    "update:duration": null;
    "update:easing": null;
    "update:from": null;
    "update:staggerDelay": null;
    "update:start": null;
    "update:to": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:from"?: ((...args: any[]) => any) | undefined;
    "onUpdate:to"?: ((...args: any[]) => any) | undefined;
    "onUpdate:complete"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:duration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:easing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:staggerDelay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:start"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHideEvent: import("vue").DefineComponent<{
    delay: NumberConstructor;
    name: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:delay": null;
    "update:name": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    delay: NumberConstructor;
    name: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMy: import("vue").DefineComponent<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxOffset: import("vue").DefineComponent<{
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPosition: import("vue").DefineComponent<{
    at: PropType<Record<string, any> | PositionAlignment>;
    boundary: {};
    boundaryOffset: PropType<string | Record<string, any>>;
    collision: PropType<Record<string, any> | CollisionResolutionCombination>;
    my: PropType<Record<string, any> | PositionAlignment>;
    of: {};
    offset: PropType<string | Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:at": null;
    "update:boundary": null;
    "update:boundaryOffset": null;
    "update:collision": null;
    "update:my": null;
    "update:of": null;
    "update:offset": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    at: PropType<Record<string, any> | PositionAlignment>;
    boundary: {};
    boundaryOffset: PropType<string | Record<string, any>>;
    collision: PropType<Record<string, any> | CollisionResolutionCombination>;
    my: PropType<Record<string, any> | PositionAlignment>;
    of: {};
    offset: PropType<string | Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:at"?: ((...args: any[]) => any) | undefined;
    "onUpdate:boundary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:boundaryOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:collision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:my"?: ((...args: any[]) => any) | undefined;
    "onUpdate:of"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShow: import("vue").DefineComponent<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:complete": null;
    "update:delay": null;
    "update:direction": null;
    "update:duration": null;
    "update:easing": null;
    "update:from": null;
    "update:staggerDelay": null;
    "update:start": null;
    "update:to": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:from"?: ((...args: any[]) => any) | undefined;
    "onUpdate:to"?: ((...args: any[]) => any) | undefined;
    "onUpdate:complete"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:duration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:easing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:staggerDelay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:start"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShowEvent: import("vue").DefineComponent<{
    delay: NumberConstructor;
    name: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:delay": null;
    "update:name": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    delay: NumberConstructor;
    name: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTo: import("vue").DefineComponent<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:left": null;
    "update:opacity": null;
    "update:position": null;
    "update:scale": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scale"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxTooltip;
export { DxTooltip, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxFrom, DxHide, DxHideEvent, DxMy, DxOffset, DxPosition, DxShow, DxShowEvent, DxTo };
import type * as DxTooltipTypes from "devextreme/ui/tooltip_types";
export { DxTooltipTypes };
