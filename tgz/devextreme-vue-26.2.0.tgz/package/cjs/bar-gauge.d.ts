/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import BarGauge, { Properties } from "devextreme/viz/bar_gauge";
import { DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, OptionChangedEvent, TooltipHiddenEvent, TooltipShownEvent, BarGaugeBarInfo, BarGaugeLegendItem } from "devextreme/viz/bar_gauge";
import { Palette, PaletteExtensionMode, ShiftLabelOverlap, Theme, AnimationEaseMode, Font, TextOverflow, WordWrap, DashStyle } from "devextreme/common/charts";
import { HorizontalAlignment, VerticalEdge, ExportFormat, Position, Orientation } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "animation" | "backgroundColor" | "barSpacing" | "baseValue" | "centerTemplate" | "disabled" | "elementAttr" | "encodeHtml" | "endValue" | "export" | "geometry" | "label" | "legend" | "loadingIndicator" | "margin" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onOptionChanged" | "onTooltipHidden" | "onTooltipShown" | "palette" | "paletteExtensionMode" | "pathModified" | "redrawOnResize" | "relativeInnerRadius" | "resolveLabelOverlapping" | "rtlEnabled" | "size" | "startValue" | "theme" | "title" | "tooltip" | "values">;
interface DxBarGauge extends AccessibleOptions {
    readonly instance?: BarGauge;
}
declare const DxBarGauge: import("vue").DefineComponent<{
    animation: {};
    backgroundColor: StringConstructor;
    barSpacing: NumberConstructor;
    baseValue: NumberConstructor;
    centerTemplate: {};
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    endValue: NumberConstructor;
    export: PropType<Record<string, any>>;
    geometry: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    legend: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onTooltipHidden: PropType<(e: TooltipHiddenEvent) => void>;
    onTooltipShown: PropType<(e: TooltipShownEvent) => void>;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    pathModified: BooleanConstructor;
    redrawOnResize: BooleanConstructor;
    relativeInnerRadius: NumberConstructor;
    resolveLabelOverlapping: PropType<ShiftLabelOverlap>;
    rtlEnabled: BooleanConstructor;
    size: PropType<Record<string, any>>;
    startValue: NumberConstructor;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    values: PropType<number[]>;
}, unknown, unknown, {
    instance(): BarGauge;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:animation": null;
    "update:backgroundColor": null;
    "update:barSpacing": null;
    "update:baseValue": null;
    "update:centerTemplate": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:encodeHtml": null;
    "update:endValue": null;
    "update:export": null;
    "update:geometry": null;
    "update:label": null;
    "update:legend": null;
    "update:loadingIndicator": null;
    "update:margin": null;
    "update:onDisposing": null;
    "update:onDrawn": null;
    "update:onExported": null;
    "update:onExporting": null;
    "update:onFileSaving": null;
    "update:onIncidentOccurred": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onTooltipHidden": null;
    "update:onTooltipShown": null;
    "update:palette": null;
    "update:paletteExtensionMode": null;
    "update:pathModified": null;
    "update:redrawOnResize": null;
    "update:relativeInnerRadius": null;
    "update:resolveLabelOverlapping": null;
    "update:rtlEnabled": null;
    "update:size": null;
    "update:startValue": null;
    "update:theme": null;
    "update:title": null;
    "update:tooltip": null;
    "update:values": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    animation: {};
    backgroundColor: StringConstructor;
    barSpacing: NumberConstructor;
    baseValue: NumberConstructor;
    centerTemplate: {};
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    endValue: NumberConstructor;
    export: PropType<Record<string, any>>;
    geometry: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    legend: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onTooltipHidden: PropType<(e: TooltipHiddenEvent) => void>;
    onTooltipShown: PropType<(e: TooltipShownEvent) => void>;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    pathModified: BooleanConstructor;
    redrawOnResize: BooleanConstructor;
    relativeInnerRadius: NumberConstructor;
    resolveLabelOverlapping: PropType<ShiftLabelOverlap>;
    rtlEnabled: BooleanConstructor;
    size: PropType<Record<string, any>>;
    startValue: NumberConstructor;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    values: PropType<number[]>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:encodeHtml"?: ((...args: any[]) => any) | undefined;
    "onUpdate:export"?: ((...args: any[]) => any) | undefined;
    "onUpdate:loadingIndicator"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDrawn"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExported"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExporting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onFileSaving"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onIncidentOccurred"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTooltipHidden"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTooltipShown"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pathModified"?: ((...args: any[]) => any) | undefined;
    "onUpdate:redrawOnResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:theme"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:palette"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paletteExtensionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:legend"?: ((...args: any[]) => any) | undefined;
    "onUpdate:resolveLabelOverlapping"?: ((...args: any[]) => any) | undefined;
    "onUpdate:centerTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:geometry"?: ((...args: any[]) => any) | undefined;
    "onUpdate:baseValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barSpacing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:relativeInnerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:values"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    encodeHtml: boolean;
    pathModified: boolean;
    redrawOnResize: boolean;
    rtlEnabled: boolean;
}>;
declare const DxAnimation: import("vue").DefineComponent<{
    duration: NumberConstructor;
    easing: PropType<AnimationEaseMode>;
    enabled: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:duration": null;
    "update:easing": null;
    "update:enabled": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    duration: NumberConstructor;
    easing: PropType<AnimationEaseMode>;
    enabled: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:duration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:easing"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxBarGaugeTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:verticalAlignment": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxBarGaugeTitleSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:cornerRadius": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxExport: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:fileName": null;
    "update:formats": null;
    "update:margin": null;
    "update:printingEnabled": null;
    "update:svgToCanvas": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fileName"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formats"?: ((...args: any[]) => any) | undefined;
    "onUpdate:printingEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:svgToCanvas"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    printingEnabled: boolean;
}>;
declare const DxFont: import("vue").DefineComponent<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:family": null;
    "update:opacity": null;
    "update:size": null;
    "update:weight": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:family"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weight"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxGeometry: import("vue").DefineComponent<{
    endAngle: NumberConstructor;
    startAngle: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:endAngle": null;
    "update:startAngle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    endAngle: NumberConstructor;
    startAngle: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startAngle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endAngle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxItemTextFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxLabel: import("vue").DefineComponent<{
    connectorColor: StringConstructor;
    connectorWidth: NumberConstructor;
    customizeText: PropType<(barValue: {
        value: number;
        valueText: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    indent: NumberConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:connectorColor": null;
    "update:connectorWidth": null;
    "update:customizeText": null;
    "update:font": null;
    "update:format": null;
    "update:indent": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    connectorColor: StringConstructor;
    connectorWidth: NumberConstructor;
    customizeText: PropType<(barValue: {
        value: number;
        valueText: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    indent: NumberConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:indent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connectorColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connectorWidth"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxLegend: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    columnCount: NumberConstructor;
    columnItemSpacing: NumberConstructor;
    customizeHint: PropType<(arg: {
        item: BarGaugeBarInfo;
        text: string;
    }) => string>;
    customizeItems: PropType<(items: Array<BarGaugeLegendItem>) => Array<BarGaugeLegendItem>>;
    customizeText: PropType<(arg: {
        item: BarGaugeBarInfo;
        text: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    itemsAlignment: PropType<HorizontalAlignment>;
    itemTextFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    itemTextPosition: PropType<Position>;
    margin: PropType<number | Record<string, any>>;
    markerSize: NumberConstructor;
    markerTemplate: {};
    orientation: PropType<Orientation>;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    rowCount: NumberConstructor;
    rowItemSpacing: NumberConstructor;
    title: PropType<string | Record<string, any>>;
    verticalAlignment: PropType<VerticalEdge>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:border": null;
    "update:columnCount": null;
    "update:columnItemSpacing": null;
    "update:customizeHint": null;
    "update:customizeItems": null;
    "update:customizeText": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:itemsAlignment": null;
    "update:itemTextFormat": null;
    "update:itemTextPosition": null;
    "update:margin": null;
    "update:markerSize": null;
    "update:markerTemplate": null;
    "update:orientation": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:rowCount": null;
    "update:rowItemSpacing": null;
    "update:title": null;
    "update:verticalAlignment": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    columnCount: NumberConstructor;
    columnItemSpacing: NumberConstructor;
    customizeHint: PropType<(arg: {
        item: BarGaugeBarInfo;
        text: string;
    }) => string>;
    customizeItems: PropType<(items: Array<BarGaugeLegendItem>) => Array<BarGaugeLegendItem>>;
    customizeText: PropType<(arg: {
        item: BarGaugeBarInfo;
        text: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    itemsAlignment: PropType<HorizontalAlignment>;
    itemTextFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    itemTextPosition: PropType<Position>;
    margin: PropType<number | Record<string, any>>;
    markerSize: NumberConstructor;
    markerTemplate: {};
    orientation: PropType<Orientation>;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    rowCount: NumberConstructor;
    rowItemSpacing: NumberConstructor;
    title: PropType<string | Record<string, any>>;
    verticalAlignment: PropType<VerticalEdge>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnItemSpacing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeHint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeItems"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemsAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTextPosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:markerSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:markerTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:orientation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowItemSpacing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTextFormat"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxLegendBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:cornerRadius": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxLegendTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    verticalAlignment: PropType<VerticalEdge>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:verticalAlignment": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    verticalAlignment: PropType<VerticalEdge>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLegendTitleSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLoadingIndicator: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:font": null;
    "update:show": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
}, {
    show: boolean;
}>;
declare const DxMargin: import("vue").DefineComponent<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:bottom": null;
    "update:left": null;
    "update:right": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:right"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShadow: import("vue").DefineComponent<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:blur": null;
    "update:color": null;
    "update:offsetX": null;
    "update:offsetY": null;
    "update:opacity": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetX"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetY"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:blur"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSize: import("vue").DefineComponent<{
    height: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:verticalAlignment": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTooltip: import("vue").DefineComponent<{
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    contentTemplate: {};
    cornerRadius: NumberConstructor;
    customizeTooltip: PropType<(scaleValue: {
        index: number;
        value: number;
        valueText: string;
    }) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    interactive: BooleanConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    zIndex: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:arrowLength": null;
    "update:border": null;
    "update:color": null;
    "update:container": null;
    "update:contentTemplate": null;
    "update:cornerRadius": null;
    "update:customizeTooltip": null;
    "update:enabled": null;
    "update:font": null;
    "update:format": null;
    "update:interactive": null;
    "update:opacity": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:shadow": null;
    "update:zIndex": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    contentTemplate: {};
    cornerRadius: NumberConstructor;
    customizeTooltip: PropType<(scaleValue: {
        index: number;
        value: number;
        valueText: string;
    }) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    interactive: BooleanConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    zIndex: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:container"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:interactive"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    interactive: boolean;
}>;
declare const DxTooltipBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
export default DxBarGauge;
export { DxBarGauge, DxAnimation, DxBarGaugeTitle, DxBarGaugeTitleSubtitle, DxBorder, DxExport, DxFont, DxFormat, DxGeometry, DxItemTextFormat, DxLabel, DxLegend, DxLegendBorder, DxLegendTitle, DxLegendTitleSubtitle, DxLoadingIndicator, DxMargin, DxShadow, DxSize, DxSubtitle, DxTitle, DxTooltip, DxTooltipBorder };
import type * as DxBarGaugeTypes from "devextreme/viz/bar_gauge_types";
export { DxBarGaugeTypes };
