/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import PivotGridFieldChooser, { Properties } from "devextreme/ui/pivot_grid_field_chooser";
import PivotGridDataSource from "devextreme/ui/pivot_grid/data_source";
import { ApplyChangesMode, HeaderFilterSearchConfig } from "devextreme/common/grids";
import { FieldChooserLayout, SearchMode } from "devextreme/common";
import { ContentReadyEvent, ContextMenuPreparingEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from "devextreme/ui/pivot_grid_field_chooser";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowSearch" | "applyChangesMode" | "dataSource" | "disabled" | "elementAttr" | "encodeHtml" | "focusStateEnabled" | "headerFilter" | "height" | "hint" | "hoverStateEnabled" | "layout" | "onContentReady" | "onContextMenuPreparing" | "onDisposing" | "onInitialized" | "onOptionChanged" | "rtlEnabled" | "searchTimeout" | "state" | "tabIndex" | "texts" | "visible" | "width">;
interface DxPivotGridFieldChooser extends AccessibleOptions {
    readonly instance?: PivotGridFieldChooser;
}
declare const DxPivotGridFieldChooser: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowSearch: BooleanConstructor;
    applyChangesMode: PropType<ApplyChangesMode>;
    dataSource: PropType<PivotGridDataSource | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    focusStateEnabled: BooleanConstructor;
    headerFilter: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    layout: PropType<FieldChooserLayout>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onContextMenuPreparing: PropType<(e: ContextMenuPreparingEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    searchTimeout: NumberConstructor;
    state: {};
    tabIndex: NumberConstructor;
    texts: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): PivotGridFieldChooser;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:allowSearch": null;
    "update:applyChangesMode": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:encodeHtml": null;
    "update:focusStateEnabled": null;
    "update:headerFilter": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:layout": null;
    "update:onContentReady": null;
    "update:onContextMenuPreparing": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:rtlEnabled": null;
    "update:searchTimeout": null;
    "update:state": null;
    "update:tabIndex": null;
    "update:texts": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowSearch: BooleanConstructor;
    applyChangesMode: PropType<ApplyChangesMode>;
    dataSource: PropType<PivotGridDataSource | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    focusStateEnabled: BooleanConstructor;
    headerFilter: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    layout: PropType<FieldChooserLayout>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onContextMenuPreparing: PropType<(e: ContextMenuPreparingEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    searchTimeout: NumberConstructor;
    state: {};
    tabIndex: NumberConstructor;
    texts: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:encodeHtml"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:headerFilter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContextMenuPreparing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSearch"?: ((...args: any[]) => any) | undefined;
    "onUpdate:texts"?: ((...args: any[]) => any) | undefined;
    "onUpdate:layout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:applyChangesMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:state"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    encodeHtml: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    allowSearch: boolean;
}>;
declare const DxHeaderFilter: import("vue").DefineComponent<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    height: NumberConstructor;
    search: PropType<Record<string, any> | HeaderFilterSearchConfig>;
    searchTimeout: NumberConstructor;
    showRelevantValues: BooleanConstructor;
    texts: PropType<Record<string, any>>;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowSearch": null;
    "update:allowSelectAll": null;
    "update:height": null;
    "update:search": null;
    "update:searchTimeout": null;
    "update:showRelevantValues": null;
    "update:texts": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    height: NumberConstructor;
    search: PropType<Record<string, any> | HeaderFilterSearchConfig>;
    searchTimeout: NumberConstructor;
    showRelevantValues: BooleanConstructor;
    texts: PropType<Record<string, any>>;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSearch"?: ((...args: any[]) => any) | undefined;
    "onUpdate:search"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSelectAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:texts"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showRelevantValues"?: ((...args: any[]) => any) | undefined;
}, {
    allowSearch: boolean;
    allowSelectAll: boolean;
    showRelevantValues: boolean;
}>;
declare const DxHeaderFilterTexts: import("vue").DefineComponent<{
    cancel: StringConstructor;
    emptyValue: StringConstructor;
    ok: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cancel": null;
    "update:emptyValue": null;
    "update:ok": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cancel: StringConstructor;
    emptyValue: StringConstructor;
    ok: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cancel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:emptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ok"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPivotGridFieldChooserTexts: import("vue").DefineComponent<{
    allFields: StringConstructor;
    columnFields: StringConstructor;
    dataFields: StringConstructor;
    filterFields: StringConstructor;
    rowFields: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allFields": null;
    "update:columnFields": null;
    "update:dataFields": null;
    "update:filterFields": null;
    "update:rowFields": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allFields: StringConstructor;
    columnFields: StringConstructor;
    dataFields: StringConstructor;
    filterFields: StringConstructor;
    rowFields: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowFields"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSearch: import("vue").DefineComponent<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    timeout: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:editorOptions": null;
    "update:enabled": null;
    "update:mode": null;
    "update:timeout": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    timeout: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editorOptions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:timeout"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxTexts: import("vue").DefineComponent<{
    allFields: StringConstructor;
    cancel: StringConstructor;
    columnFields: StringConstructor;
    dataFields: StringConstructor;
    emptyValue: StringConstructor;
    filterFields: StringConstructor;
    ok: StringConstructor;
    rowFields: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allFields": null;
    "update:cancel": null;
    "update:columnFields": null;
    "update:dataFields": null;
    "update:emptyValue": null;
    "update:filterFields": null;
    "update:ok": null;
    "update:rowFields": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allFields: StringConstructor;
    cancel: StringConstructor;
    columnFields: StringConstructor;
    dataFields: StringConstructor;
    emptyValue: StringConstructor;
    filterFields: StringConstructor;
    ok: StringConstructor;
    rowFields: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cancel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:emptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ok"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowFields"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxPivotGridFieldChooser;
export { DxPivotGridFieldChooser, DxHeaderFilter, DxHeaderFilterTexts, DxPivotGridFieldChooserTexts, DxSearch, DxTexts };
import type * as DxPivotGridFieldChooserTypes from "devextreme/ui/pivot_grid_field_chooser_types";
export { DxPivotGridFieldChooserTypes };
