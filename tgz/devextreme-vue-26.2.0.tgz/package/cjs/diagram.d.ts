/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Diagram, { Properties } from "devextreme/ui/diagram";
import DataSource from "devextreme/data/data_source";
import { AutoZoomMode, ContentReadyEvent, CustomCommandEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemDblClickEvent, OptionChangedEvent, RequestEditOperationEvent, RequestLayoutUpdateEvent, SelectionChangedEvent, Units, DataLayoutType, Command, CustomCommand, ToolboxDisplayMode, ConnectorLineEnd, ConnectorLineType, PanelVisibility } from "devextreme/ui/diagram";
import { PageOrientation, Orientation, ToolbarItemLocation } from "devextreme/common";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
type AccessibleOptions = Pick<Properties, "autoZoomMode" | "contextMenu" | "contextToolbox" | "customShapes" | "customShapeTemplate" | "customShapeToolboxTemplate" | "defaultItemProperties" | "disabled" | "edges" | "editing" | "elementAttr" | "export" | "fullScreen" | "gridSize" | "hasChanges" | "height" | "historyToolbar" | "mainToolbar" | "nodes" | "onContentReady" | "onCustomCommand" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemDblClick" | "onOptionChanged" | "onRequestEditOperation" | "onRequestLayoutUpdate" | "onSelectionChanged" | "pageColor" | "pageOrientation" | "pageSize" | "propertiesPanel" | "readOnly" | "rtlEnabled" | "showGrid" | "simpleView" | "snapToGrid" | "toolbox" | "units" | "useNativeScrolling" | "viewToolbar" | "viewUnits" | "visible" | "width" | "zoomLevel">;
interface DxDiagram extends AccessibleOptions {
    readonly instance?: Diagram;
}
declare const DxDiagram: import("vue").DefineComponent<{
    autoZoomMode: PropType<AutoZoomMode>;
    contextMenu: PropType<Record<string, any>>;
    contextToolbox: PropType<Record<string, any>>;
    customShapes: PropType<Record<string, any>[]>;
    customShapeTemplate: {};
    customShapeToolboxTemplate: {};
    defaultItemProperties: PropType<Record<string, any>>;
    disabled: BooleanConstructor;
    edges: PropType<Record<string, any>>;
    editing: PropType<Record<string, any>>;
    elementAttr: PropType<Record<string, any>>;
    export: PropType<Record<string, any>>;
    fullScreen: BooleanConstructor;
    gridSize: PropType<number | Record<string, any>>;
    hasChanges: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    historyToolbar: PropType<Record<string, any>>;
    mainToolbar: PropType<Record<string, any>>;
    nodes: PropType<Record<string, any>>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onCustomCommand: PropType<(e: CustomCommandEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemDblClick: PropType<(e: ItemDblClickEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onRequestEditOperation: PropType<(e: RequestEditOperationEvent) => void>;
    onRequestLayoutUpdate: PropType<(e: RequestLayoutUpdateEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    pageColor: StringConstructor;
    pageOrientation: PropType<PageOrientation>;
    pageSize: PropType<Record<string, any>>;
    propertiesPanel: PropType<Record<string, any>>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    showGrid: BooleanConstructor;
    simpleView: BooleanConstructor;
    snapToGrid: BooleanConstructor;
    toolbox: PropType<Record<string, any>>;
    units: PropType<Units>;
    useNativeScrolling: BooleanConstructor;
    viewToolbar: PropType<Record<string, any>>;
    viewUnits: PropType<Units>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    zoomLevel: PropType<number | Record<string, any>>;
}, unknown, unknown, {
    instance(): Diagram;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:autoZoomMode": null;
    "update:contextMenu": null;
    "update:contextToolbox": null;
    "update:customShapes": null;
    "update:customShapeTemplate": null;
    "update:customShapeToolboxTemplate": null;
    "update:defaultItemProperties": null;
    "update:disabled": null;
    "update:edges": null;
    "update:editing": null;
    "update:elementAttr": null;
    "update:export": null;
    "update:fullScreen": null;
    "update:gridSize": null;
    "update:hasChanges": null;
    "update:height": null;
    "update:historyToolbar": null;
    "update:mainToolbar": null;
    "update:nodes": null;
    "update:onContentReady": null;
    "update:onCustomCommand": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onItemClick": null;
    "update:onItemDblClick": null;
    "update:onOptionChanged": null;
    "update:onRequestEditOperation": null;
    "update:onRequestLayoutUpdate": null;
    "update:onSelectionChanged": null;
    "update:pageColor": null;
    "update:pageOrientation": null;
    "update:pageSize": null;
    "update:propertiesPanel": null;
    "update:readOnly": null;
    "update:rtlEnabled": null;
    "update:showGrid": null;
    "update:simpleView": null;
    "update:snapToGrid": null;
    "update:toolbox": null;
    "update:units": null;
    "update:useNativeScrolling": null;
    "update:viewToolbar": null;
    "update:viewUnits": null;
    "update:visible": null;
    "update:width": null;
    "update:zoomLevel": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    autoZoomMode: PropType<AutoZoomMode>;
    contextMenu: PropType<Record<string, any>>;
    contextToolbox: PropType<Record<string, any>>;
    customShapes: PropType<Record<string, any>[]>;
    customShapeTemplate: {};
    customShapeToolboxTemplate: {};
    defaultItemProperties: PropType<Record<string, any>>;
    disabled: BooleanConstructor;
    edges: PropType<Record<string, any>>;
    editing: PropType<Record<string, any>>;
    elementAttr: PropType<Record<string, any>>;
    export: PropType<Record<string, any>>;
    fullScreen: BooleanConstructor;
    gridSize: PropType<number | Record<string, any>>;
    hasChanges: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    historyToolbar: PropType<Record<string, any>>;
    mainToolbar: PropType<Record<string, any>>;
    nodes: PropType<Record<string, any>>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onCustomCommand: PropType<(e: CustomCommandEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemDblClick: PropType<(e: ItemDblClickEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onRequestEditOperation: PropType<(e: RequestEditOperationEvent) => void>;
    onRequestLayoutUpdate: PropType<(e: RequestLayoutUpdateEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    pageColor: StringConstructor;
    pageOrientation: PropType<PageOrientation>;
    pageSize: PropType<Record<string, any>>;
    propertiesPanel: PropType<Record<string, any>>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    showGrid: BooleanConstructor;
    simpleView: BooleanConstructor;
    snapToGrid: BooleanConstructor;
    toolbox: PropType<Record<string, any>>;
    units: PropType<Units>;
    useNativeScrolling: BooleanConstructor;
    viewToolbar: PropType<Record<string, any>>;
    viewUnits: PropType<Units>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    zoomLevel: PropType<number | Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:export"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useNativeScrolling"?: ((...args: any[]) => any) | undefined;
    "onUpdate:readOnly"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fullScreen"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pageSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zoomLevel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:autoZoomMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contextToolbox"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customShapes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customShapeTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customShapeToolboxTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:defaultItemProperties"?: ((...args: any[]) => any) | undefined;
    "onUpdate:edges"?: ((...args: any[]) => any) | undefined;
    "onUpdate:gridSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hasChanges"?: ((...args: any[]) => any) | undefined;
    "onUpdate:historyToolbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mainToolbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:nodes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onCustomCommand"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemDblClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onRequestEditOperation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onRequestLayoutUpdate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pageColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pageOrientation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:propertiesPanel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showGrid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:simpleView"?: ((...args: any[]) => any) | undefined;
    "onUpdate:snapToGrid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toolbox"?: ((...args: any[]) => any) | undefined;
    "onUpdate:units"?: ((...args: any[]) => any) | undefined;
    "onUpdate:viewToolbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:viewUnits"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    useNativeScrolling: boolean;
    readOnly: boolean;
    fullScreen: boolean;
    hasChanges: boolean;
    showGrid: boolean;
    simpleView: boolean;
    snapToGrid: boolean;
}>;
declare const DxAutoLayout: import("vue").DefineComponent<{
    orientation: PropType<Orientation>;
    type: PropType<DataLayoutType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:orientation": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    orientation: PropType<Orientation>;
    type: PropType<DataLayoutType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:orientation"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxCommand: import("vue").DefineComponent<{
    icon: StringConstructor;
    items: PropType<(Command | CustomCommand)[]>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:icon": null;
    "update:items": null;
    "update:location": null;
    "update:name": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    icon: StringConstructor;
    items: PropType<(Command | CustomCommand)[]>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxCommandItem: import("vue").DefineComponent<{
    icon: StringConstructor;
    items: PropType<(Command | CustomCommand)[]>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:icon": null;
    "update:items": null;
    "update:location": null;
    "update:name": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    icon: StringConstructor;
    items: PropType<(Command | CustomCommand)[]>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxConnectionPoint: import("vue").DefineComponent<{
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxContextMenu: import("vue").DefineComponent<{
    commands: PropType<(Command | CustomCommand)[]>;
    enabled: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:commands": null;
    "update:enabled": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    commands: PropType<(Command | CustomCommand)[]>;
    enabled: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commands"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxContextToolbox: import("vue").DefineComponent<{
    category: PropType<string>;
    displayMode: PropType<ToolboxDisplayMode>;
    enabled: BooleanConstructor;
    shapeIconsPerRow: NumberConstructor;
    shapes: PropType<string[]>;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:category": null;
    "update:displayMode": null;
    "update:enabled": null;
    "update:shapeIconsPerRow": null;
    "update:shapes": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    category: PropType<string>;
    displayMode: PropType<ToolboxDisplayMode>;
    enabled: BooleanConstructor;
    shapeIconsPerRow: NumberConstructor;
    shapes: PropType<string[]>;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:category"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shapeIconsPerRow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shapes"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxCustomShape: import("vue").DefineComponent<{
    allowEditImage: BooleanConstructor;
    allowEditText: BooleanConstructor;
    allowResize: BooleanConstructor;
    backgroundImageHeight: NumberConstructor;
    backgroundImageLeft: NumberConstructor;
    backgroundImageToolboxUrl: StringConstructor;
    backgroundImageTop: NumberConstructor;
    backgroundImageUrl: StringConstructor;
    backgroundImageWidth: NumberConstructor;
    baseType: PropType<string>;
    category: StringConstructor;
    connectionPoints: PropType<Record<string, any>[]>;
    defaultHeight: NumberConstructor;
    defaultImageUrl: StringConstructor;
    defaultText: StringConstructor;
    defaultWidth: NumberConstructor;
    imageHeight: NumberConstructor;
    imageLeft: NumberConstructor;
    imageTop: NumberConstructor;
    imageWidth: NumberConstructor;
    keepRatioOnAutoSize: BooleanConstructor;
    maxHeight: NumberConstructor;
    maxWidth: NumberConstructor;
    minHeight: NumberConstructor;
    minWidth: NumberConstructor;
    template: {};
    templateHeight: NumberConstructor;
    templateLeft: NumberConstructor;
    templateTop: NumberConstructor;
    templateWidth: NumberConstructor;
    textHeight: NumberConstructor;
    textLeft: NumberConstructor;
    textTop: NumberConstructor;
    textWidth: NumberConstructor;
    title: StringConstructor;
    toolboxTemplate: {};
    toolboxWidthToHeightRatio: NumberConstructor;
    type: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowEditImage": null;
    "update:allowEditText": null;
    "update:allowResize": null;
    "update:backgroundImageHeight": null;
    "update:backgroundImageLeft": null;
    "update:backgroundImageToolboxUrl": null;
    "update:backgroundImageTop": null;
    "update:backgroundImageUrl": null;
    "update:backgroundImageWidth": null;
    "update:baseType": null;
    "update:category": null;
    "update:connectionPoints": null;
    "update:defaultHeight": null;
    "update:defaultImageUrl": null;
    "update:defaultText": null;
    "update:defaultWidth": null;
    "update:imageHeight": null;
    "update:imageLeft": null;
    "update:imageTop": null;
    "update:imageWidth": null;
    "update:keepRatioOnAutoSize": null;
    "update:maxHeight": null;
    "update:maxWidth": null;
    "update:minHeight": null;
    "update:minWidth": null;
    "update:template": null;
    "update:templateHeight": null;
    "update:templateLeft": null;
    "update:templateTop": null;
    "update:templateWidth": null;
    "update:textHeight": null;
    "update:textLeft": null;
    "update:textTop": null;
    "update:textWidth": null;
    "update:title": null;
    "update:toolboxTemplate": null;
    "update:toolboxWidthToHeightRatio": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowEditImage: BooleanConstructor;
    allowEditText: BooleanConstructor;
    allowResize: BooleanConstructor;
    backgroundImageHeight: NumberConstructor;
    backgroundImageLeft: NumberConstructor;
    backgroundImageToolboxUrl: StringConstructor;
    backgroundImageTop: NumberConstructor;
    backgroundImageUrl: StringConstructor;
    backgroundImageWidth: NumberConstructor;
    baseType: PropType<string>;
    category: StringConstructor;
    connectionPoints: PropType<Record<string, any>[]>;
    defaultHeight: NumberConstructor;
    defaultImageUrl: StringConstructor;
    defaultText: StringConstructor;
    defaultWidth: NumberConstructor;
    imageHeight: NumberConstructor;
    imageLeft: NumberConstructor;
    imageTop: NumberConstructor;
    imageWidth: NumberConstructor;
    keepRatioOnAutoSize: BooleanConstructor;
    maxHeight: NumberConstructor;
    maxWidth: NumberConstructor;
    minHeight: NumberConstructor;
    minWidth: NumberConstructor;
    template: {};
    templateHeight: NumberConstructor;
    templateLeft: NumberConstructor;
    templateTop: NumberConstructor;
    templateWidth: NumberConstructor;
    textHeight: NumberConstructor;
    textLeft: NumberConstructor;
    textTop: NumberConstructor;
    textWidth: NumberConstructor;
    title: StringConstructor;
    toolboxTemplate: {};
    toolboxWidthToHeightRatio: NumberConstructor;
    type: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:category"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowEditImage"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowEditText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundImageHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundImageLeft"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundImageToolboxUrl"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundImageTop"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundImageUrl"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundImageWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:baseType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connectionPoints"?: ((...args: any[]) => any) | undefined;
    "onUpdate:defaultHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:defaultImageUrl"?: ((...args: any[]) => any) | undefined;
    "onUpdate:defaultText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:defaultWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:imageHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:imageLeft"?: ((...args: any[]) => any) | undefined;
    "onUpdate:imageTop"?: ((...args: any[]) => any) | undefined;
    "onUpdate:imageWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keepRatioOnAutoSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:templateHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:templateLeft"?: ((...args: any[]) => any) | undefined;
    "onUpdate:templateTop"?: ((...args: any[]) => any) | undefined;
    "onUpdate:templateWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textLeft"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textTop"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toolboxTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toolboxWidthToHeightRatio"?: ((...args: any[]) => any) | undefined;
}, {
    allowEditImage: boolean;
    allowEditText: boolean;
    allowResize: boolean;
    keepRatioOnAutoSize: boolean;
}>;
declare const DxDefaultItemProperties: import("vue").DefineComponent<{
    connectorLineEnd: PropType<ConnectorLineEnd>;
    connectorLineStart: PropType<ConnectorLineEnd>;
    connectorLineType: PropType<ConnectorLineType>;
    shapeMaxHeight: NumberConstructor;
    shapeMaxWidth: NumberConstructor;
    shapeMinHeight: NumberConstructor;
    shapeMinWidth: NumberConstructor;
    style: PropType<Record<string, any>>;
    textStyle: PropType<Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:connectorLineEnd": null;
    "update:connectorLineStart": null;
    "update:connectorLineType": null;
    "update:shapeMaxHeight": null;
    "update:shapeMaxWidth": null;
    "update:shapeMinHeight": null;
    "update:shapeMinWidth": null;
    "update:style": null;
    "update:textStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    connectorLineEnd: PropType<ConnectorLineEnd>;
    connectorLineStart: PropType<ConnectorLineEnd>;
    connectorLineType: PropType<ConnectorLineType>;
    shapeMaxHeight: NumberConstructor;
    shapeMaxWidth: NumberConstructor;
    shapeMinHeight: NumberConstructor;
    shapeMinWidth: NumberConstructor;
    style: PropType<Record<string, any>>;
    textStyle: PropType<Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connectorLineEnd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connectorLineStart"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connectorLineType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shapeMaxHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shapeMaxWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shapeMinHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shapeMinWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:style"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textStyle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxEdges: import("vue").DefineComponent<{
    customDataExpr: PropType<string | ((data: any, value: any) => any)>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    fromExpr: PropType<string | ((data: any, value: any) => any)>;
    fromLineEndExpr: PropType<string | ((data: any, value: any) => any)>;
    fromPointIndexExpr: PropType<string | ((data: any, value: any) => any)>;
    keyExpr: PropType<string | ((data: any, value: any) => any)>;
    lineTypeExpr: PropType<string | ((data: any, value: any) => any)>;
    lockedExpr: PropType<string | ((data: any, value: any) => any)>;
    pointsExpr: PropType<string | ((data: any, value: any) => any)>;
    styleExpr: PropType<string | ((data: any, value: any) => any)>;
    textExpr: PropType<string | ((data: any, value: any) => any)>;
    textStyleExpr: PropType<string | ((data: any, value: any) => any)>;
    toExpr: PropType<string | ((data: any, value: any) => any)>;
    toLineEndExpr: PropType<string | ((data: any, value: any) => any)>;
    toPointIndexExpr: PropType<string | ((data: any, value: any) => any)>;
    zIndexExpr: PropType<string | ((data: any, value: any) => any)>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:customDataExpr": null;
    "update:dataSource": null;
    "update:fromExpr": null;
    "update:fromLineEndExpr": null;
    "update:fromPointIndexExpr": null;
    "update:keyExpr": null;
    "update:lineTypeExpr": null;
    "update:lockedExpr": null;
    "update:pointsExpr": null;
    "update:styleExpr": null;
    "update:textExpr": null;
    "update:textStyleExpr": null;
    "update:toExpr": null;
    "update:toLineEndExpr": null;
    "update:toPointIndexExpr": null;
    "update:zIndexExpr": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    customDataExpr: PropType<string | ((data: any, value: any) => any)>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    fromExpr: PropType<string | ((data: any, value: any) => any)>;
    fromLineEndExpr: PropType<string | ((data: any, value: any) => any)>;
    fromPointIndexExpr: PropType<string | ((data: any, value: any) => any)>;
    keyExpr: PropType<string | ((data: any, value: any) => any)>;
    lineTypeExpr: PropType<string | ((data: any, value: any) => any)>;
    lockedExpr: PropType<string | ((data: any, value: any) => any)>;
    pointsExpr: PropType<string | ((data: any, value: any) => any)>;
    styleExpr: PropType<string | ((data: any, value: any) => any)>;
    textExpr: PropType<string | ((data: any, value: any) => any)>;
    textStyleExpr: PropType<string | ((data: any, value: any) => any)>;
    toExpr: PropType<string | ((data: any, value: any) => any)>;
    toLineEndExpr: PropType<string | ((data: any, value: any) => any)>;
    toPointIndexExpr: PropType<string | ((data: any, value: any) => any)>;
    zIndexExpr: PropType<string | ((data: any, value: any) => any)>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keyExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customDataExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fromExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fromLineEndExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fromPointIndexExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lineTypeExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lockedExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pointsExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:styleExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textStyleExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toLineEndExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toPointIndexExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zIndexExpr"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxEditing: import("vue").DefineComponent<{
    allowAddShape: BooleanConstructor;
    allowChangeConnection: BooleanConstructor;
    allowChangeConnectorPoints: BooleanConstructor;
    allowChangeConnectorText: BooleanConstructor;
    allowChangeShapeText: BooleanConstructor;
    allowDeleteConnector: BooleanConstructor;
    allowDeleteShape: BooleanConstructor;
    allowMoveShape: BooleanConstructor;
    allowResizeShape: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowAddShape": null;
    "update:allowChangeConnection": null;
    "update:allowChangeConnectorPoints": null;
    "update:allowChangeConnectorText": null;
    "update:allowChangeShapeText": null;
    "update:allowDeleteConnector": null;
    "update:allowDeleteShape": null;
    "update:allowMoveShape": null;
    "update:allowResizeShape": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowAddShape: BooleanConstructor;
    allowChangeConnection: BooleanConstructor;
    allowChangeConnectorPoints: BooleanConstructor;
    allowChangeConnectorText: BooleanConstructor;
    allowChangeShapeText: BooleanConstructor;
    allowDeleteConnector: BooleanConstructor;
    allowDeleteShape: BooleanConstructor;
    allowMoveShape: BooleanConstructor;
    allowResizeShape: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowAddShape"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowChangeConnection"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowChangeConnectorPoints"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowChangeConnectorText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowChangeShapeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDeleteConnector"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDeleteShape"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowMoveShape"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowResizeShape"?: ((...args: any[]) => any) | undefined;
}, {
    allowAddShape: boolean;
    allowChangeConnection: boolean;
    allowChangeConnectorPoints: boolean;
    allowChangeConnectorText: boolean;
    allowChangeShapeText: boolean;
    allowDeleteConnector: boolean;
    allowDeleteShape: boolean;
    allowMoveShape: boolean;
    allowResizeShape: boolean;
}>;
declare const DxExport: import("vue").DefineComponent<{
    fileName: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:fileName": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    fileName: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fileName"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxGridSize: import("vue").DefineComponent<{
    items: PropType<number[]>;
    value: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:items": null;
    "update:value": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    items: PropType<number[]>;
    value: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxGroup: import("vue").DefineComponent<{
    category: PropType<string>;
    commands: PropType<(Command | CustomCommand)[]>;
    displayMode: PropType<ToolboxDisplayMode>;
    expanded: BooleanConstructor;
    shapes: PropType<string[]>;
    title: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:category": null;
    "update:commands": null;
    "update:displayMode": null;
    "update:expanded": null;
    "update:shapes": null;
    "update:title": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    category: PropType<string>;
    commands: PropType<(Command | CustomCommand)[]>;
    displayMode: PropType<ToolboxDisplayMode>;
    expanded: BooleanConstructor;
    shapes: PropType<string[]>;
    title: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:expanded"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commands"?: ((...args: any[]) => any) | undefined;
    "onUpdate:category"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shapes"?: ((...args: any[]) => any) | undefined;
}, {
    expanded: boolean;
}>;
declare const DxHistoryToolbar: import("vue").DefineComponent<{
    commands: PropType<(Command | CustomCommand)[]>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:commands": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    commands: PropType<(Command | CustomCommand)[]>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commands"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxItem: import("vue").DefineComponent<{
    height: NumberConstructor;
    icon: StringConstructor;
    items: PropType<(Command | CustomCommand)[]>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    text: StringConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:icon": null;
    "update:items": null;
    "update:location": null;
    "update:name": null;
    "update:text": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    icon: StringConstructor;
    items: PropType<(Command | CustomCommand)[]>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    text: StringConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMainToolbar: import("vue").DefineComponent<{
    commands: PropType<(Command | CustomCommand)[]>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:commands": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    commands: PropType<(Command | CustomCommand)[]>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commands"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxNodes: import("vue").DefineComponent<{
    autoLayout: PropType<Record<string, any> | DataLayoutType>;
    autoSizeEnabled: BooleanConstructor;
    containerChildrenExpr: PropType<string | ((data: any, value: any) => any)>;
    containerKeyExpr: PropType<string | ((data: any, value: any) => any)>;
    customDataExpr: PropType<string | ((data: any, value: any) => any)>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    heightExpr: PropType<string | ((data: any, value: any) => any)>;
    imageUrlExpr: PropType<string | ((data: any, value: any) => any)>;
    itemsExpr: PropType<string | ((data: any, value: any) => any)>;
    keyExpr: PropType<string | ((data: any, value: any) => any)>;
    leftExpr: PropType<string | ((data: any, value: any) => any)>;
    lockedExpr: PropType<string | ((data: any, value: any) => any)>;
    parentKeyExpr: PropType<string | ((data: any, value: any) => any)>;
    styleExpr: PropType<string | ((data: any, value: any) => any)>;
    textExpr: PropType<string | ((data: any, value: any) => any)>;
    textStyleExpr: PropType<string | ((data: any, value: any) => any)>;
    topExpr: PropType<string | ((data: any, value: any) => any)>;
    typeExpr: PropType<string | ((data: any, value: any) => any)>;
    widthExpr: PropType<string | ((data: any, value: any) => any)>;
    zIndexExpr: PropType<string | ((data: any, value: any) => any)>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:autoLayout": null;
    "update:autoSizeEnabled": null;
    "update:containerChildrenExpr": null;
    "update:containerKeyExpr": null;
    "update:customDataExpr": null;
    "update:dataSource": null;
    "update:heightExpr": null;
    "update:imageUrlExpr": null;
    "update:itemsExpr": null;
    "update:keyExpr": null;
    "update:leftExpr": null;
    "update:lockedExpr": null;
    "update:parentKeyExpr": null;
    "update:styleExpr": null;
    "update:textExpr": null;
    "update:textStyleExpr": null;
    "update:topExpr": null;
    "update:typeExpr": null;
    "update:widthExpr": null;
    "update:zIndexExpr": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    autoLayout: PropType<Record<string, any> | DataLayoutType>;
    autoSizeEnabled: BooleanConstructor;
    containerChildrenExpr: PropType<string | ((data: any, value: any) => any)>;
    containerKeyExpr: PropType<string | ((data: any, value: any) => any)>;
    customDataExpr: PropType<string | ((data: any, value: any) => any)>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    heightExpr: PropType<string | ((data: any, value: any) => any)>;
    imageUrlExpr: PropType<string | ((data: any, value: any) => any)>;
    itemsExpr: PropType<string | ((data: any, value: any) => any)>;
    keyExpr: PropType<string | ((data: any, value: any) => any)>;
    leftExpr: PropType<string | ((data: any, value: any) => any)>;
    lockedExpr: PropType<string | ((data: any, value: any) => any)>;
    parentKeyExpr: PropType<string | ((data: any, value: any) => any)>;
    styleExpr: PropType<string | ((data: any, value: any) => any)>;
    textExpr: PropType<string | ((data: any, value: any) => any)>;
    textStyleExpr: PropType<string | ((data: any, value: any) => any)>;
    topExpr: PropType<string | ((data: any, value: any) => any)>;
    typeExpr: PropType<string | ((data: any, value: any) => any)>;
    widthExpr: PropType<string | ((data: any, value: any) => any)>;
    zIndexExpr: PropType<string | ((data: any, value: any) => any)>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemsExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keyExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customDataExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lockedExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:styleExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textStyleExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zIndexExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:autoLayout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:autoSizeEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:containerChildrenExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:containerKeyExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:heightExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:imageUrlExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:leftExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parentKeyExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:topExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:typeExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:widthExpr"?: ((...args: any[]) => any) | undefined;
}, {
    autoSizeEnabled: boolean;
}>;
declare const DxPageSize: import("vue").DefineComponent<{
    height: NumberConstructor;
    items: PropType<Record<string, any>[]>;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:items": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    items: PropType<Record<string, any>[]>;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPageSizeItem: import("vue").DefineComponent<{
    height: NumberConstructor;
    text: StringConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:text": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    text: StringConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPropertiesPanel: import("vue").DefineComponent<{
    tabs: PropType<Record<string, any>[]>;
    visibility: PropType<PanelVisibility>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:tabs": null;
    "update:visibility": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    tabs: PropType<Record<string, any>[]>;
    visibility: PropType<PanelVisibility>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabs"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visibility"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTab: import("vue").DefineComponent<{
    commands: PropType<(Command | CustomCommand)[]>;
    groups: PropType<Record<string, any>[]>;
    title: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:commands": null;
    "update:groups": null;
    "update:title": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    commands: PropType<(Command | CustomCommand)[]>;
    groups: PropType<Record<string, any>[]>;
    title: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:groups"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commands"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTabGroup: import("vue").DefineComponent<{
    commands: PropType<(Command | CustomCommand)[]>;
    title: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:commands": null;
    "update:title": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    commands: PropType<(Command | CustomCommand)[]>;
    title: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commands"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxToolbox: import("vue").DefineComponent<{
    groups: PropType<Record<string, any>[]>;
    shapeIconsPerRow: NumberConstructor;
    showSearch: BooleanConstructor;
    visibility: PropType<PanelVisibility>;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:groups": null;
    "update:shapeIconsPerRow": null;
    "update:showSearch": null;
    "update:visibility": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    groups: PropType<Record<string, any>[]>;
    shapeIconsPerRow: NumberConstructor;
    showSearch: BooleanConstructor;
    visibility: PropType<PanelVisibility>;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:groups"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shapeIconsPerRow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visibility"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showSearch"?: ((...args: any[]) => any) | undefined;
}, {
    showSearch: boolean;
}>;
declare const DxToolboxGroup: import("vue").DefineComponent<{
    category: PropType<string>;
    displayMode: PropType<ToolboxDisplayMode>;
    expanded: BooleanConstructor;
    shapes: PropType<string[]>;
    title: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:category": null;
    "update:displayMode": null;
    "update:expanded": null;
    "update:shapes": null;
    "update:title": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    category: PropType<string>;
    displayMode: PropType<ToolboxDisplayMode>;
    expanded: BooleanConstructor;
    shapes: PropType<string[]>;
    title: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:expanded"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:category"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shapes"?: ((...args: any[]) => any) | undefined;
}, {
    expanded: boolean;
}>;
declare const DxViewToolbar: import("vue").DefineComponent<{
    commands: PropType<(Command | CustomCommand)[]>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:commands": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    commands: PropType<(Command | CustomCommand)[]>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commands"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxZoomLevel: import("vue").DefineComponent<{
    items: PropType<number[]>;
    value: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:items": null;
    "update:value": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    items: PropType<number[]>;
    value: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxDiagram;
export { DxDiagram, DxAutoLayout, DxCommand, DxCommandItem, DxConnectionPoint, DxContextMenu, DxContextToolbox, DxCustomShape, DxDefaultItemProperties, DxEdges, DxEditing, DxExport, DxGridSize, DxGroup, DxHistoryToolbar, DxItem, DxMainToolbar, DxNodes, DxPageSize, DxPageSizeItem, DxPropertiesPanel, DxTab, DxTabGroup, DxToolbox, DxToolboxGroup, DxViewToolbar, DxZoomLevel };
import type * as DxDiagramTypes from "devextreme/ui/diagram_types";
export { DxDiagramTypes };
