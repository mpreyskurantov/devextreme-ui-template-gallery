/**
* DevExtreme (data/odata/context.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { ODataContext } from '../../common/data';

export {
  ODataContextOptions,
  ODataRequestOptions,
} from '../../common/data';

export default ODataContext;
