/**
* DevExtreme (data/load_options.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { LoadOptions as BaseLoadOptions } from '../common/data';

/** @deprecated Use LoadOptions from common/data instead */
export interface LoadOptions extends BaseLoadOptions { }
