/**
* DevExtreme (ui/tooltip_types.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  ContentReadyEvent,
  DisposingEvent,
  HidingEvent,
  HiddenEvent,
  InitializedEvent,
  OptionChangedEvent,
  ShowingEvent,
  ShownEvent,
  Properties,
} from './tooltip';
