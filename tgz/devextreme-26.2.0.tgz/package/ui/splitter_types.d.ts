/**
* DevExtreme (ui/splitter_types.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  Mode,
  ContentReadyEvent,
  DisposingEvent,
  InitializedEvent,
  ItemClickEvent,
  ItemContextMenuEvent,
  ItemRenderedEvent,
  OptionChangedEvent,
  ResizeEvent,
  ResizeStartEvent,
  ResizeEndEvent,
  ItemCollapsedEvent,
  ItemExpandedEvent,
  dxSplitterOptions,
  Item,
  Properties,
} from './splitter';
