/**
* DevExtreme (ui/widget/template.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import type {
    template,
} from '../../common';

/**
 * @docid ui.template
 * @namespace DevExpress.ui
 * @deprecated
 * @type object
 * @public
 */
export type Template = template;
