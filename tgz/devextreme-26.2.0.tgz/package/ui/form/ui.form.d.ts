/**
* DevExtreme (ui/form/ui.form.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * @docid
 * @hidden
 */
export interface ColCountResponsible {
    /**
     * @docid
     * @default undefined
     * @public
     */
    lg?: number | undefined;
    /**
     * @docid
     * @default undefined
     * @public
     */
    md?: number | undefined;
    /**
     * @docid
     * @default undefined
     * @public
     */
    sm?: number | undefined;
    /**
     * @docid
     * @default undefined
     * @public
     */
    xs?: number | undefined;
}
