/**
* DevExtreme (ui/diagram_types.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  AutoZoomMode,
  Command,
  ConnectorLineEnd,
  ConnectorLineType,
  ConnectorPosition,
  DataLayoutType,
  DiagramExportFormat,
  ItemType,
  ModelOperation,
  PanelVisibility,
  RequestEditOperationReason,
  ShapeCategory,
  ShapeType,
  ToolboxDisplayMode,
  Units,
  ContentReadyEvent,
  CustomCommandEvent,
  DisposingEvent,
  InitializedEvent,
  ItemClickEvent,
  ItemDblClickEvent,
  OptionChangedEvent,
  RequestEditOperationEvent,
  RequestLayoutUpdateEvent,
  SelectionChangedEvent,
  CustomShapeTemplateData,
  CustomShapeToolboxTemplateData,
  Item,
  CustomCommand,
  Properties,
} from './diagram';
