/**
* DevExtreme (ui/button_group.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import {
    UserDefinedElement,
    DxElement,
} from '../core/element';

import {
    template,
    ButtonType,
    ButtonStyle,
    SingleMultipleOrNone,
} from '../common';

import {
    EventInfo,
    NativeEventInfo,
    InitializedEventInfo,
    ChangedOptionInfo,
    ItemInfo,
} from '../events';

import {
    CollectionWidgetItem,
    SelectionChangeInfo,
} from './collection/ui.collection_widget.base';

import Widget, {
    WidgetOptions,
} from './widget/ui.widget';

export {
    ButtonType,
    ButtonStyle,
    SingleMultipleOrNone,
};

/**
 * @docid _ui_button_group_ContentReadyEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type ContentReadyEvent = EventInfo<dxButtonGroup>;

/**
 * @docid _ui_button_group_DisposingEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type DisposingEvent = EventInfo<dxButtonGroup>;

/**
 * @docid _ui_button_group_InitializedEvent
 * @public
 * @type object
 * @inherits InitializedEventInfo
 */
export type InitializedEvent = InitializedEventInfo<dxButtonGroup>;

/**
 * @docid _ui_button_group_ItemClickEvent
 * @public
 * @type object
 * @inherits NativeEventInfo,ItemInfo
 */
export type ItemClickEvent = NativeEventInfo<dxButtonGroup, KeyboardEvent | MouseEvent | PointerEvent> & ItemInfo;

/**
 * @docid _ui_button_group_OptionChangedEvent
 * @public
 * @type object
 * @inherits EventInfo,ChangedOptionInfo
 */
export type OptionChangedEvent = EventInfo<dxButtonGroup> & ChangedOptionInfo;

/**
 * @docid _ui_button_group_SelectionChangedEvent
 * @public
 * @type object
 * @inherits EventInfo,SelectionChangeInfo
 */
export type SelectionChangedEvent = EventInfo<dxButtonGroup> & SelectionChangeInfo;

/**
 * @deprecated use Properties instead
 * @namespace DevExpress.ui
 * @docid
 */
export interface dxButtonGroupOptions extends WidgetOptions<dxButtonGroup> {
    /**
     * @docid
     * @default "content"
     * @type_function_param1 buttonData:object
     * @type_function_return string|Element|jQuery
     * @public
     */
    buttonTemplate?: template | ((buttonData: any, buttonContent: DxElement) => string | UserDefinedElement);
    /**
     * @docid
     * @default true
     * @public
     */
    focusStateEnabled?: boolean;
    /**
     * @docid
     * @default true
     * @public
     */
    hoverStateEnabled?: boolean;
    /**
     * @docid
     * @type Array<dxButtonGroupItem>
     * @public
     */
    items?: Array<Item>;
    /**
     * @docid
     * @default 'text'
     * @public
     */
    keyExpr?: string | ((item: any) => any);
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/button_group:ItemClickEvent}
     * @action
     * @public
     */
    onItemClick?: ((e: ItemClickEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/button_group:SelectionChangedEvent}
     * @action
     * @public
     */
    onSelectionChanged?: ((e: SelectionChangedEvent) => void) | undefined;
    /**
     * @docid
     * @fires dxButtonGroupOptions.onSelectionChanged
     * @public
     */
    selectedItemKeys?: Array<any>;
    /**
     * @docid
     * @fires dxButtonGroupOptions.onSelectionChanged
     * @public
     */
    selectedItems?: Array<any>;
    /**
     * @docid
     * @default 'single'
     * @public
     */
    selectionMode?: SingleMultipleOrNone;
    /**
     * @docid
     * @default 'contained'
     * @public
     */
    stylingMode?: ButtonStyle;
}
/**
 * @docid
 * @inherits Widget
 * @namespace DevExpress.ui
 * @public
 */
export default class dxButtonGroup extends Widget<dxButtonGroupOptions> { }

/**
 * @public
 * @namespace DevExpress.ui.dxButtonGroup
 */
export type Item = dxButtonGroupItem;

/**
 * @deprecated Use Item instead
 * @namespace DevExpress.ui
 */
export interface dxButtonGroupItem extends CollectionWidgetItem {
    /**
     * @docid
     * @public
     */
    hint?: string;
    /**
     * @docid
     * @public
     */
    icon?: string;
    /**
     * @docid
     * @default 'normal'
     * @public
     */
    type?: ButtonType | string;

    /**
     * @docid
     * @public
     */
    elementAttr?: { [key: string]: any };
}

/** @public */
export type Properties = dxButtonGroupOptions;


