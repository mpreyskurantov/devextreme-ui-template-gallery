/**
* DevExtreme (ui/tag_box_types.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  ChangeEvent,
  ClosedEvent,
  ContentReadyEvent,
  CustomItemCreatingEvent,
  DisposingEvent,
  EnterKeyEvent,
  FocusInEvent,
  FocusOutEvent,
  InitializedEvent,
  InputEvent,
  ItemClickEvent,
  KeyDownEvent,
  KeyPressEvent,
  KeyUpEvent,
  MultiTagPreparingEvent,
  OpenedEvent,
  OptionChangedEvent,
  SelectAllValueChangedEvent,
  SelectionChangedEvent,
  ValueChangedEvent,
  DropDownButtonTemplateData,
  Properties,
} from './tag_box';
