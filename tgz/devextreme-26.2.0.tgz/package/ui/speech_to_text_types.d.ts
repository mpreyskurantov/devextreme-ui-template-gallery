/**
* DevExtreme (ui/speech_to_text_types.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  SpeechRecognitionConfig,
  CustomSpeechRecognizer,
  StartClickEvent,
  StopClickEvent,
  ResultEvent,
  ErrorEvent,
  EndEvent,
  ContentReadyEvent,
  DisposingEvent,
  InitializedEvent,
  OptionChangedEvent,
  dxSpeechToTextOptions,
  Properties,
} from './speech_to_text';
