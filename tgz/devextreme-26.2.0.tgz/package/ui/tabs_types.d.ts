/**
* DevExtreme (ui/tabs_types.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  SingleOrMultiple,
  Orientation,
  TabsIconPosition,
  TabsStyle,
  ContentReadyEvent,
  DisposingEvent,
  InitializedEvent,
  ItemClickEvent,
  ItemContextMenuEvent,
  ItemHoldEvent,
  ItemRenderedEvent,
  OptionChangedEvent,
  SelectionChangingEvent,
  SelectionChangedEvent,
  dxTabsOptions,
  Item,
  Properties,
} from './tabs';
