/**
* DevExtreme (ui/text_box_types.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  TextBoxType,
  ChangeEvent,
  ContentReadyEvent,
  CopyEvent,
  CutEvent,
  DisposingEvent,
  EnterKeyEvent,
  FocusInEvent,
  FocusOutEvent,
  InitializedEvent,
  InputEvent,
  KeyDownEvent,
  KeyPressEvent,
  KeyUpEvent,
  OptionChangedEvent,
  PasteEvent,
  ValueChangedEvent,
  Properties,
} from './text_box';
