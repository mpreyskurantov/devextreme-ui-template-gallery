/**
* DevExtreme (ui/scheduler.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import {
  UserDefinedElement,
  DxElement,
} from '../core/element';

import {
  template,
  DayOfWeek,
  FirstDayOfWeek,
  Orientation,
  ScrollMode,
  ToolbarItemLocation,
} from '../common';

import DataSource, { DataSourceLike } from '../data/data_source';

import {
  EventInfo,
  NativeEventInfo,
  InitializedEventInfo,
  ChangedOptionInfo,
  Cancelable,
  DxEvent,
  PointerInteractionEvent,
} from '../events';

import {
  Properties as ButtonGroupProperties,
  Item as ButtonGroupItem,
} from './button_group';
import {
  CollectionWidgetItem,
} from './collection/ui.collection_widget.base';

import dxDraggable from './draggable';

import dxForm, { Properties as FormProperties } from './form';
import dxPopup, { Properties as PopupProperties } from './popup';

import dxSortable from './sortable';
import { dxToolbarItem } from './toolbar';

import Widget, {
  WidgetOptions,
} from './widget/ui.widget';

interface AppointmentDraggingEvent {
  readonly component: dxScheduler;
  readonly event?: DxEvent<MouseEvent | TouchEvent>;
  readonly itemData?: any;
  readonly itemElement?: DxElement;
  readonly fromData?: any;
}

/**
 * @docid
 * @hidden
 */
export interface TargetedAppointmentInfo {
  /**
   * @docid
   */
  readonly appointmentData: Appointment;
  /**
   * @docid
   */
  readonly targetedAppointmentData?: Appointment;
}

export {
    DayOfWeek,
    FirstDayOfWeek,
    Orientation,
    ScrollMode,
};

/** @public */
export type AllDayPanelMode = 'all' | 'allDay' | 'hidden';
/** @public */
export type CellAppointmentsLimit = 'auto' | 'unlimited';
/** @public */
export type SnapToCellsMode = 'always' | 'auto' | 'never';
/** @public */
export type RecurrenceEditMode = 'dialog' | 'occurrence' | 'series';
/** @public */
export type AppointmentFormIconsShowMode = 'both' | 'main' | 'recurrence' | 'none';

/**
 * @docid
 * @public
 * @inherits dxFormOptions
 */
export type AppointmentFormProperties = FormProperties & {
  /**
   * @docid
   * @default "main"
   * @public
   */
  iconsShowMode?: AppointmentFormIconsShowMode;
};
/** @public */
export type ViewType = 'agenda' | 'day' | 'month' | 'timelineDay' | 'timelineMonth' | 'timelineWeek' | 'timelineWorkWeek' | 'week' | 'workWeek';
/** @public */
export type SchedulerScrollToAlign = 'start' | 'center';
/** @public */
export type SchedulerPredefinedToolbarItem = 'today' | 'dateNavigator' | 'viewSwitcher';
/** @public */
export type SchedulerPredefinedDateNavigatorItem = 'prev' | 'next' | 'dateInterval';

/**
 * @docid _ui_scheduler_AppointmentAddedEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type AppointmentAddedEvent = EventInfo<dxScheduler> & {
  /**
   * @docid _ui_scheduler_AppointmentAddedEvent.appointmentData
   */
  readonly appointmentData: Appointment;
  /** @docid _ui_scheduler_AppointmentAddedEvent.error */
  readonly error?: Error;
};

/**
 * @docid _ui_scheduler_AppointmentAddingEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type AppointmentAddingEvent = EventInfo<dxScheduler> & {
  /**
   * @docid _ui_scheduler_AppointmentAddingEvent.appointmentData
   */
  readonly appointmentData: Appointment;
  /**
   * @docid _ui_scheduler_AppointmentAddingEvent.cancel
   */
  cancel: boolean | PromiseLike<boolean>;
};

/**
 * @docid _ui_scheduler_AppointmentClickEvent
 * @public
 * @type object
 * @inherits Cancelable,NativeEventInfo,TargetedAppointmentInfo
 */
export type AppointmentClickEvent = Cancelable & NativeEventInfo<dxScheduler, KeyboardEvent | MouseEvent | PointerEvent> & TargetedAppointmentInfo & {
  /** @docid _ui_scheduler_AppointmentClickEvent.appointmentElement */
  readonly appointmentElement: DxElement;
};

/**
 * @docid _ui_scheduler_AppointmentContextMenuEvent
 * @public
 * @type object
 * @inherits NativeEventInfo,TargetedAppointmentInfo
 */
export type AppointmentContextMenuEvent = NativeEventInfo<dxScheduler, PointerInteractionEvent> & TargetedAppointmentInfo & {
  /** @docid _ui_scheduler_AppointmentContextMenuEvent.appointmentElement */
  readonly appointmentElement: DxElement;
};

/**
 * @docid _ui_scheduler_AppointmentDblClickEvent
 * @public
 * @type object
 * @inherits Cancelable,NativeEventInfo,TargetedAppointmentInfo
 */
export type AppointmentDblClickEvent = Cancelable & NativeEventInfo<dxScheduler, MouseEvent | PointerEvent> & TargetedAppointmentInfo & {
  /** @docid _ui_scheduler_AppointmentDblClickEvent.appointmentElement */
  readonly appointmentElement: DxElement;
};

/**
 * @docid _ui_scheduler_AppointmentDeletedEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type AppointmentDeletedEvent = EventInfo<dxScheduler> & {
  /**
   * @docid _ui_scheduler_AppointmentDeletedEvent.appointmentData
   */
  readonly appointmentData: Appointment;
  /** @docid _ui_scheduler_AppointmentDeletedEvent.error */
  readonly error?: Error;
};

/**
 * @docid _ui_scheduler_AppointmentDeletingEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type AppointmentDeletingEvent = EventInfo<dxScheduler> & {
  /**
   * @docid _ui_scheduler_AppointmentDeletingEvent.appointmentData
   */
  readonly appointmentData: Appointment;
  /**
   * @docid _ui_scheduler_AppointmentDeletingEvent.cancel
   */
  cancel: boolean | PromiseLike<boolean>;
};

/**
 * @docid _ui_scheduler_AppointmentFormOpeningEvent
 * @public
 * @type object
 * @inherits Cancelable,EventInfo
 */
export type AppointmentFormOpeningEvent = Cancelable & EventInfo<dxScheduler> & {
  /**
   * @docid _ui_scheduler_AppointmentFormOpeningEvent.appointmentData
   */
  readonly appointmentData?: Appointment;
  /** @docid _ui_scheduler_AppointmentFormOpeningEvent.form */
  readonly form: dxForm;
  /** @docid _ui_scheduler_AppointmentFormOpeningEvent.popup */
  readonly popup: dxPopup;
};

/**
 * @docid
 * @public
 */
export type AppointmentTooltipShowingAppointmentInfo = {
  readonly appointmentData: Appointment;
  readonly currentAppointmentData: Appointment;
  readonly color: PromiseLike<string>;
};

/**
 * @docid _ui_scheduler_AppointmentTooltipShowingEvent
 * @public
 * @type object
 * @inherits Cancelable,EventInfo
 */
export type AppointmentTooltipShowingEvent = Cancelable & EventInfo<dxScheduler> & {
  /** @docid _ui_scheduler_AppointmentTooltipShowingEvent.targetElement */
  readonly targetElement: DxElement;
  /**
   * @docid _ui_scheduler_AppointmentTooltipShowingEvent.appointments
   */
  readonly appointments: AppointmentTooltipShowingAppointmentInfo[];
};

/**
 * @docid _ui_scheduler_AppointmentRenderedEvent
 * @public
 * @type object
 * @inherits EventInfo,TargetedAppointmentInfo
 */
export type AppointmentRenderedEvent = EventInfo<dxScheduler> & TargetedAppointmentInfo & {
  /** @docid _ui_scheduler_AppointmentRenderedEvent.appointmentElement */
  readonly appointmentElement: DxElement;
};

/**
 * @docid _ui_scheduler_AppointmentUpdatedEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type AppointmentUpdatedEvent = EventInfo<dxScheduler> & {
  /**
   * @docid _ui_scheduler_AppointmentUpdatedEvent.appointmentData
   */
  readonly appointmentData: Appointment;
  /** @docid _ui_scheduler_AppointmentUpdatedEvent.error */
  readonly error?: Error;
};

/**
 * @docid _ui_scheduler_AppointmentUpdatingEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type AppointmentUpdatingEvent = EventInfo<dxScheduler> & {
  /**
   * @docid _ui_scheduler_AppointmentUpdatingEvent.oldData
   */
  readonly oldData: Object;
  /**
   * @docid _ui_scheduler_AppointmentUpdatingEvent.newData
   */
  readonly newData: Object;
  /**
   * @docid _ui_scheduler_AppointmentUpdatingEvent.cancel
   */
  cancel?: boolean | PromiseLike<boolean>;
};

/**
 * @docid _ui_scheduler_CellClickEvent
 * @public
 * @type object
 * @inherits Cancelable,NativeEventInfo
 */
export type CellClickEvent = Cancelable & NativeEventInfo<dxScheduler, KeyboardEvent | MouseEvent | PointerEvent> & {
  /**
   * @docid _ui_scheduler_CellClickEvent.cellData
   * @type object
   */
  readonly cellData: any;
  /** @docid _ui_scheduler_CellClickEvent.cellElement */
  readonly cellElement: DxElement;
};

/**
 * @docid _ui_scheduler_CellContextMenuEvent
 * @public
 * @type object
 * @inherits NativeEventInfo
 */
export type CellContextMenuEvent = NativeEventInfo<dxScheduler, PointerInteractionEvent> & {
  /**
   * @docid _ui_scheduler_CellContextMenuEvent.cellData
   * @type object
   */
  readonly cellData: any;
  /** @docid _ui_scheduler_CellContextMenuEvent.cellElement */
  readonly cellElement: DxElement;
};

/**
 * @docid _ui_scheduler_ContentReadyEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type ContentReadyEvent = EventInfo<dxScheduler>;

/**
 * @docid _ui_scheduler_DisposingEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type DisposingEvent = EventInfo<dxScheduler>;

/**
 * @docid _ui_scheduler_InitializedEvent
 * @public
 * @type object
 * @inherits InitializedEventInfo
 */
export type InitializedEvent = InitializedEventInfo<dxScheduler>;

/**
 * @docid _ui_scheduler_OptionChangedEvent
 * @public
 * @type object
 * @inherits EventInfo,ChangedOptionInfo
 */
export type OptionChangedEvent = EventInfo<dxScheduler> & ChangedOptionInfo;

/**
 * @docid _ui_scheduler_SelectionEndEvent
 * @public
 * @type object
 * @inherits EventInfo
 */
export type SelectionEndEvent = EventInfo<dxScheduler> & {
  /** @docid _ui_scheduler_SelectionEndEvent.selectedCellData */
  readonly selectedCellData: Array<any>;
};

/** @public */
export type AppointmentDraggingAddEvent = AppointmentDraggingEvent & {
  readonly fromComponent?: dxSortable | dxDraggable;
  readonly toComponent?: dxSortable | dxDraggable;
  readonly toData?: any;
};

/** @public */
export type AppointmentDraggingEndEvent = Cancelable & AppointmentDraggingEvent & {
  readonly fromComponent?: dxSortable | dxDraggable;
  readonly toComponent?: dxSortable | dxDraggable;
  readonly toData?: any;
  readonly toItemData?: any;
};

/** @public */
export type AppointmentDraggingMoveEvent = Cancelable & AppointmentDraggingEvent & {
  readonly fromComponent?: dxSortable | dxDraggable;
  readonly toComponent?: dxSortable | dxDraggable;
  readonly toData?: any;
};

/** @public */
export type AppointmentDraggingStartEvent = Cancelable & Omit<AppointmentDraggingEvent, 'itemData'> & {
  itemData?: any;
};

/** @public */
export type AppointmentDraggingRemoveEvent = AppointmentDraggingEvent & {
  readonly fromComponent?: dxSortable | dxDraggable;
  readonly toComponent?: dxSortable | dxDraggable;
};

/**
 * @docid
 * @public
 * @inherits TargetedAppointmentInfo
 */
export type AppointmentTemplateData = TargetedAppointmentInfo;

/**
 * @docid
 * @public
 * @inherits TargetedAppointmentInfo
 */
export type AppointmentTooltipTemplateData = TargetedAppointmentInfo & {
  /**
   * @docid
   */
  readonly isButtonClicked: boolean;
};

/**
 * @docid
 * @public
 */
export type AppointmentCollectorTemplateData = {
  /**
   * @docid
   */
  readonly appointmentCount: number;
  /**
   * @docid
   */
  readonly items: Appointment[];
  /**
   * @docid
   */
  readonly isCompact: boolean;
};

/** @public */
export type DateNavigatorTextInfo = {
  readonly startDate: Date;
  readonly endDate: Date;
  readonly text: string;
};

/**
 * @deprecated use Properties instead
 * @namespace DevExpress.ui
 * @docid
 */
export interface dxSchedulerOptions extends WidgetOptions<dxScheduler> {
    /**
     * @docid
     * @default false
     * @public
     */
    adaptivityEnabled?: boolean;
    /**
     * @docid
     * @default 'allDay'
     * @public
     */
    allDayExpr?: string;
    /**
     * @docid
     * @default "appointmentCollector"
     * @type_function_param1 data:{ui/scheduler:AppointmentCollectorTemplateData}
     * @public
     */
    appointmentCollectorTemplate?: template | ((data: AppointmentCollectorTemplateData, collectorElement: DxElement) => string | UserDefinedElement);
    /**
     * @docid
     * @public
     */
    appointmentDragging?: {
      /**
       * @docid
       * @default true
       */
      autoScroll?: boolean;
      /**
       * @docid
       * @default undefined
       */
      data?: any | undefined;
      /**
       * @docid
       * @default undefined
       */
      group?: string | undefined;
      /**
       * @docid
       * @type_function_param1 e:object
       * @type_function_param1_field event:event
       */
      onAdd?: ((e: AppointmentDraggingAddEvent) => void);
      /**
       * @docid
       * @type_function_param1 e:object
       * @type_function_param1_field event:event
       */
      onDragEnd?: ((e: AppointmentDraggingEndEvent) => void);
      /**
       * @docid
       * @type_function_param1 e:object
       * @type_function_param1_field event:event
       */
      onDragMove?: ((e: AppointmentDraggingMoveEvent) => void);
      /**
       * @docid
       * @type_function_param1 e:object
       * @type_function_param1_field event:event
       */
      onDragStart?: ((e: AppointmentDraggingStartEvent) => void);
      /**
       * @docid
       * @type_function_param1 e:object
       * @type_function_param1_field event:event
       */
      onRemove?: ((e: AppointmentDraggingRemoveEvent) => void);
      /**
       * @docid
       * @default 60
       */
      scrollSensitivity?: number;
      /**
       * @docid
       * @default 60
       */
      scrollSpeed?: number;
    };
    /**
     * @docid
     * @default "item"
     * @type_function_param1 model:{ui/scheduler:AppointmentTemplateData}
     * @public
     */
    appointmentTemplate?: template | ((model: AppointmentTemplateData, itemIndex: number, contentElement: DxElement) => string | UserDefinedElement);
    /**
     * @docid
     * @default "appointmentTooltip"
     * @type_function_param1 model:{ui/scheduler:AppointmentTooltipTemplateData}
     * @public
     */
    appointmentTooltipTemplate?: template | ((model: AppointmentTooltipTemplateData, itemIndex: number, contentElement: DxElement) => string | UserDefinedElement);
    /**
     * @docid
     * @default 30
     * @public
     */
    cellDuration?: number;
    /**
     * @docid
     * @default false
     * @public
     */
    crossScrollingEnabled?: boolean;
    /**
     * @docid
     * @default new Date()
     * @fires dxSchedulerOptions.onOptionChanged
     * @public
     */
    currentDate?: Date | number | string;
    /**
     * @docid
     * @default "day"
     * @fires dxSchedulerOptions.onOptionChanged
     * @public
     */
    currentView?: ViewType | string;
    /**
     * @docid
     * @type_function_param1 info:object
     * @default undefined
     * @public
     */
    customizeDateNavigatorText?: ((info: DateNavigatorTextInfo) => string) | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 itemData:object
     * @public
     */
    dataCellTemplate?: template | ((itemData: any, itemIndex: number, itemElement: DxElement) => string | UserDefinedElement) | undefined;
    /**
     * @docid
     * @default null
     * @public
     * @type string|Array<dxSchedulerAppointment>|Store|DataSource|DataSourceOptions|null
     */
    dataSource?: DataSourceLike<Appointment> | null;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 itemData:object
     * @public
     */
    dateCellTemplate?: template | ((itemData: any, itemIndex: number, itemElement: DxElement) => string | UserDefinedElement) | undefined;
    /**
     * @docid
     * @default undefined
     * @public
     */
    dateSerializationFormat?: string | undefined;
    /**
     * @docid
     * @default 'description'
     * @public
     */
    descriptionExpr?: string;
    /**
     * @docid
     * @default true
     * @public
     */
    editing?: boolean | {
      /**
       * @docid
       * @default true
       */
      allowAdding?: boolean;
      /**
       * @docid
       * @default true
       */
      allowDeleting?: boolean;
      /**
       * @docid
       * @default true
       * @default false &for(Android|iOS)
       */
      allowDragging?: boolean;
      /**
       * @docid
       * @default true
       * @default false &for(Android|iOS)
       */
      allowResizing?: boolean;
      /**
       * @docid
       * @default false
       */
      allowTimeZoneEditing?: boolean;
      /**
       * @docid
       * @default true
       */
      allowUpdating?: boolean;
      /**
       * @docid
       * @public
       */
      form?: AppointmentFormProperties;
      /**
       * @docid
       * @public
       * @type dxPopupOptions
       */
      popup?: PopupProperties;
    };
    /**
     * @docid
     * @default 'endDate'
     * @public
     */
    endDateExpr?: string;
    /**
     * @docid
     * @default 'endDateTimeZone'
     * @public
     */
    endDateTimeZoneExpr?: string;
    /**
     * @docid
     * @default 24
     * @public
     */
    endDayHour?: number;
    /**
     * @docid
     * @default undefined
     * @public
     */
    firstDayOfWeek?: DayOfWeek | undefined;
    /**
     * @docid
     * @default undefined
     * @public
     */
    hiddenWeekDays?: Array<DayOfWeek> | undefined;
    /**
     * @docid
     * @default true &for(desktop)
     * @public
     */
    focusStateEnabled?: boolean;
    /**
     * @docid
     * @default false
     * @public
     */
    groupByDate?: boolean;
    /**
     * @docid
     * @default []
     * @public
     */
    groups?: Array<string>;
    /**
     * @docid
     * @default 300000
     * @public
     */
    indicatorUpdateInterval?: number;
    /**
     * @docid
     * @default undefined
     * @public
     */
    max?: Date | number | string | undefined;
    /**
     * @docid
     * @default "auto"
     * @public
     */
    maxAppointmentsPerCell?: number | CellAppointmentsLimit;
    /**
     * @docid
     * @default undefined
     * @public
     */
    min?: Date | number | string | undefined;
    /**
     * @docid
     * @default "No data to display"
     * @public
     */
    noDataText?: string;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:AppointmentAddedEvent}
     * @action
     * @public
     */
    onAppointmentAdded?: ((e: AppointmentAddedEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:AppointmentAddingEvent}
     * @action
     * @public
     */
    onAppointmentAdding?: ((e: AppointmentAddingEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type function
     * @type_function_param1 e:{ui/scheduler:AppointmentClickEvent}
     * @action
     * @public
     */
    onAppointmentClick?: ((e: AppointmentClickEvent) => void) | string | undefined;
    /**
     * @docid
     * @default undefined
     * @type function
     * @type_function_param1 e:{ui/scheduler:AppointmentContextMenuEvent}
     * @action
     * @public
     */
    onAppointmentContextMenu?: ((e: AppointmentContextMenuEvent) => void) | string | undefined;
    /**
     * @docid
     * @default undefined
     * @type function
     * @type_function_param1 e:{ui/scheduler:AppointmentDblClickEvent}
     * @action
     * @public
     */
    onAppointmentDblClick?: ((e: AppointmentDblClickEvent) => void) | string | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:AppointmentDeletedEvent}
     * @action
     * @public
     */
    onAppointmentDeleted?: ((e: AppointmentDeletedEvent) => void) | undefined;

    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:AppointmentDeletingEvent}
     * @action
     * @public
     */
    onAppointmentDeleting?: ((e: AppointmentDeletingEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:AppointmentTooltipShowingEvent}
     * @action
     * @public
     */
    onAppointmentTooltipShowing?: ((e: AppointmentTooltipShowingEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:AppointmentFormOpeningEvent}
     * @action
     * @public
     */
    onAppointmentFormOpening?: ((e: AppointmentFormOpeningEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:AppointmentRenderedEvent}
     * @action
     * @public
     */
    onAppointmentRendered?: ((e: AppointmentRenderedEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:AppointmentUpdatedEvent}
     * @action
     * @public
     */
    onAppointmentUpdated?: ((e: AppointmentUpdatedEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:AppointmentUpdatingEvent}
     * @action
     * @public
     */
    onAppointmentUpdating?: ((e: AppointmentUpdatingEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type function
     * @type_function_param1 e:{ui/scheduler:CellClickEvent}
     * @action
     * @public
     */
    onCellClick?: ((e: CellClickEvent) => void) | string | undefined;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 e:{ui/scheduler:SelectionEndEvent}
     * @action
     * @public
     */
    onSelectionEnd?: ((e: SelectionEndEvent) => void) | undefined;
    /**
     * @docid
     * @default undefined
     * @type function
     * @type_function_param1 e:{ui/scheduler:CellContextMenuEvent}
     * @action
     * @public
     */
    onCellContextMenu?: ((e: CellContextMenuEvent) => void) | string | undefined;
    /**
     * @docid
     * @default "dialog"
     * @public
     */
    recurrenceEditMode?: RecurrenceEditMode;
    /**
     * @docid
     * @default 'recurrenceException'
     * @public
     */
    recurrenceExceptionExpr?: string;
    /**
     * @docid
     * @default 'recurrenceRule'
     * @public
     */
    recurrenceRuleExpr?: string;
    /**
     * @docid
     * @default false
     * @public
     */
    remoteFiltering?: boolean;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 itemData:object
     * @public
     */
    resourceCellTemplate?: template | ((itemData: any, itemIndex: number, itemElement: DxElement) => string | UserDefinedElement) | undefined;
    /**
     * @docid
     * @default []
     * @public
     */
    resources?: Array<{
      /**
       * @docid
       * @default false
       */
      allowMultiple?: boolean;
      /**
       * @docid
       * @default "color"
       */
      colorExpr?: string;
      /**
       * @docid
       * @default null
       * @type Store|DataSource|DataSourceOptions|string|Array<any>|null
       */
      dataSource?: DataSourceLike<any> | null;
      /**
       * @docid
       * @type_function_param1 resource:object
       * @default 'text'
       */
      displayExpr?: string | ((resource: any) => string);
      /**
       * @docid
       * @default ""
       */
      fieldExpr?: string;
      /**
       * @docid
       * @default ""
       */
      icon?: string;
      /**
       * @docid
       * @default ""
       */
      label?: string;
      /**
       * @docid
       * @default undefined
       */
      parentIdExpr?: string;
      /**
       * @docid
       * @default false
       */
      useColorAsDefault?: boolean;
      /**
       * @docid
       * @default 'id'
       */
      valueExpr?: string | Function;
    }>;
    /**
     * @docid
     * @public
     */
    scrolling?: dxSchedulerScrolling;
    /**
     * @docid
     * @readonly
     * @default []
     * @public
     */
    selectedCellData?: Array<any>;
    /**
     * @docid
     * @default false
     * @public
     */
    shadeUntilCurrentTime?: boolean;
    /**
     * @docid
     * @default true
     * @public
     */
    showAllDayPanel?: boolean;
    /**
     * @docid
     * @default true
     * @public
     */
    showCurrentTimeIndicator?: boolean;
    /**
     * @docid
     * @default 'startDate'
     * @public
     */
    startDateExpr?: string;
    /**
     * @docid
     * @default 'startDateTimeZone'
     * @public
     */
    startDateTimeZoneExpr?: string;
    /**
     * @docid
     * @default 0
     * @public
     */
    startDayHour?: number;
    /**
     * @docid
     * @default 'text'
     * @public
     */
    textExpr?: string;
    /**
     * @docid
     * @default undefined
     * @type_function_param1 itemData:object
     * @public
     */
    timeCellTemplate?: template | ((itemData: any, itemIndex: number, itemElement: DxElement) => string | UserDefinedElement) | undefined;
    /**
     * @docid
     * @default ""
     * @public
     */
    timeZone?: string;
    /**
     * @docid
     * @default false
     * @default true &for(Android|iOS)
     * @default true &for(Material)
     * @default true &for(Fluent)
     * @public
     */
    useDropDownViewSwitcher?: boolean;
    /**
     * @docid
     * @default "all"
     */
    allDayPanelMode?: AllDayPanelMode;
    /**
     * @docid
     * @public
     */
    snapToCellsMode?: SnapToCellsMode;
    /**
     * @docid
     * @default 0
     * @public
     */
    offset?: number;
    /**
     * @docid
     * @default ['day', 'week']
     * @public
     */
    views?: Array<'day' | 'week' | 'workWeek' | 'month' | 'timelineDay' | 'timelineWeek' | 'timelineWorkWeek' | 'timelineMonth' | 'agenda' | {
      /**
       * @docid
       * @default 7
       */
      agendaDuration?: number;
      /**
       * @docid
       * @default "appointmentCollector"
       */
      appointmentCollectorTemplate?: template | ((data: AppointmentCollectorTemplateData, collectorElement: DxElement) => string | UserDefinedElement);
      /**
       * @docid
       * @default "item"
       * @type_function_param1 model:{ui/scheduler:AppointmentTemplateData}
       * @type_function_param1_field appointmentData:object
       * @type_function_param1_field targetedAppointmentData:object
       */
      appointmentTemplate?: template | ((model: AppointmentTemplateData, itemIndex: number, contentElement: DxElement) => string | UserDefinedElement);
      /**
       * @docid
       * @default "appointmentTooltip"
       * @type_function_param1 model:{ui/scheduler:AppointmentTooltipTemplateData}
       * @type_function_param1_field appointmentData:object
       * @type_function_param1_field targetedAppointmentData:object
       */
      appointmentTooltipTemplate?: template | ((model: AppointmentTooltipTemplateData, itemIndex: number, contentElement: DxElement) => string | UserDefinedElement);
      /**
       * @docid
       * @default 30
       */
      cellDuration?: number;
      /**
       * @docid
       * @type_function_param1 itemData:object
       */
      dataCellTemplate?: template | ((itemData: any, itemIndex: number, itemElement: DxElement) => string | UserDefinedElement);
      /**
       * @docid
       * @type_function_param1 itemData:object
       */
      dateCellTemplate?: template | ((itemData: any, itemIndex: number, itemElement: DxElement) => string | UserDefinedElement);
      /**
       * @docid
       * @default 24
       */
      endDayHour?: number;
      /**
       * @docid
       * @default undefined
       */
      firstDayOfWeek?: DayOfWeek | undefined;
      /**
       * @docid
       * @default undefined
       */
      hiddenWeekDays?: Array<DayOfWeek> | undefined;
      /**
       * @docid
       * @default false
       */
      groupByDate?: boolean;
      /**
       * @docid
       */
      groupOrientation?: Orientation;
      /**
       * @docid
       * @default []
       */
      groups?: Array<string>;
      /**
       * @docid
       * @default 1
       */
      intervalCount?: number;
      /**
       * @docid
       * @default "auto"
       */
      maxAppointmentsPerCell?: number | CellAppointmentsLimit;
      /**
       * @docid
       * @default undefined
       */
      name?: string | undefined;
      /**
       * @docid
       * @type_function_param1 itemData:object
       */
      resourceCellTemplate?: template | ((itemData: any, itemIndex: number, itemElement: DxElement) => string | UserDefinedElement);
      /**
       * @docid
       * @default undefined
       */
      startDate?: Date | number | string | undefined;
      /**
       * @docid
       * @default 0
       */
      startDayHour?: number;
      /**
       * @docid
       * @type_function_param1 itemData:object
       */
      timeCellTemplate?: template | ((itemData: any, itemIndex: number, itemElement: DxElement) => string | UserDefinedElement);
      /**
       * @docid
       * @default undefined
       */
      type?: ViewType | undefined;
      /**
       * @docid
       */
      scrolling?: dxSchedulerScrolling;
      /**
       * @docid
       * @default "all"
       */
       allDayPanelMode?: AllDayPanelMode;
       /**
        * @docid
        */
       snapToCellsMode?: SnapToCellsMode;
       /**
        * @docid
        * @default 0
        * @public
        */
       offset?: number;
    }>;
    /**
     * @docid
     * @type dxSchedulerToolbar|undefined
     * @default undefined
     * @public
     */
    toolbar?: Toolbar | undefined;
}

/**
 * @docid
 * @type object
 * @inherits dxButtonGroupOptions
 * @namespace DevExpress.ui.dxScheduler
 * @public
 */
export type DateNavigatorItemProperties = ButtonGroupProperties & {
  /**
   * @docid
   * @type Array<dxButtonGroupItem,Enums.SchedulerPredefinedDateNavigatorItem>
   * @public
   */
  items: Array<ButtonGroupItem | SchedulerPredefinedDateNavigatorItem>;
};

/**
 * @namespace DevExpress.ui
 * @deprecated Use ToolbarItem instead
 */
export type dxSchedulerToolbarItem = ToolbarItem;

/**
 * @docid dxSchedulerToolbarItem
 * @inherits dxToolbarItem
 * @namespace DevExpress.ui.dxScheduler
 * @public
 */
export type ToolbarItem = dxToolbarItem & {
  /**
   * @docid dxSchedulerToolbarItem.name
   * @public
   */
  name?: SchedulerPredefinedToolbarItem;
  /**
   * @docid dxSchedulerToolbarItem.options
   * @public
   */
  options?: DateNavigatorItemProperties | Object;
  /**
   * @docid dxSchedulerToolbarItem.location
   * @public
   */
  location?: ToolbarItemLocation;
};

/**
 * @namespace DevExpress.ui
 * @deprecated Use Toolbar instead
 */
export type dxSchedulerToolbar = Toolbar;

/**
 * @docid dxSchedulerToolbar
 * @namespace DevExpress.ui.dxScheduler
 * @public
 */
export type Toolbar = {
  /**
   * @docid dxSchedulerToolbar.items
   * @type Array<Enums.SchedulerPredefinedToolbarItem|dxSchedulerToolbarItem>
   * @public
   */
  items?: Array<SchedulerPredefinedToolbarItem | ToolbarItem>;
  /**
   * @docid dxSchedulerToolbar.visible
   * @default undefined
   * @public
   */
  visible?: boolean | undefined;
  /**
   * @docid dxSchedulerToolbar.multiline
   * @default false
   * @public
   */
  multiline?: boolean;
  /**
   * @docid dxSchedulerToolbar.disabled
   * @default false
   * @public
   */
  disabled?: boolean;
};

/**
 * @docid
 * @inherits Widget, DataHelperMixin
 * @namespace DevExpress.ui
 * @public
 */
export default class dxScheduler extends Widget<Properties> {
    /**
     * @docid
     * @publicName addAppointment(appointment)
     * @public
     */
    addAppointment(appointment: Appointment): void;
    /**
     * @docid
     * @publicName deleteAppointment(appointment)
     * @public
     */
    deleteAppointment(appointment: Appointment): void;
    /**
     * @docid
     * @publicName deleteRecurrence(appointment, date, recurrenceEditMode)
     * @public
     */
    deleteRecurrence(
      appointmentData: Appointment,
      date: Date | string,
      recurrenceEditMode: RecurrenceEditMode,
    ): void;
    getDataSource(): DataSource;
    /**
     * @docid
     * @publicName getEndViewDate()
     * @public
     */
    getEndViewDate(): Date;
    /**
     * @docid
     * @publicName getOccurrences(startDate, endDate, appointments)
     * @public
     */
    getOccurrences(startDate: Date, endDate: Date, appointments: Appointment[]): Occurrence[];
    /**
     * @docid
     * @publicName getStartViewDate()
     * @public
     */
    getStartViewDate(): Date;
    /**
     * @docid
     * @publicName hideAppointmentPopup(saveChanges)
     * @public
     */
    hideAppointmentPopup(saveChanges?: boolean): void;
    /**
     * @docid
     * @publicName hideAppointmentTooltip()
     * @public
     */
    hideAppointmentTooltip(): void;
    /**
     * @docid
     * @publicName scrollTo(date, options)
     * @public
     */
    scrollTo(date: Date, options?: {
        group?: object;
        allDay?: boolean;
        alignInView?: SchedulerScrollToAlign;
    }): void;
    /**
     * @docid
     * @publicName scrollTo(date, group, allDay)
     * @public
     * @deprecated
     */
    scrollTo(date: Date, group?: object, allDay?: boolean): void;
    /**
     * @docid
     * @publicName showAppointmentPopup(appointmentData, createNewAppointment, currentAppointmentData)
     * @public
     */
    showAppointmentPopup(appointmentData?: Appointment, createNewAppointment?: boolean, currentAppointmentData?: Appointment): void;
    /**
     * @docid
     * @publicName showAppointmentTooltip(appointmentData, target, currentAppointmentData)
     * @public
     */
    showAppointmentTooltip(appointmentData: Appointment, target: string | UserDefinedElement, currentAppointmentData?: Appointment): void;
    /**
     * @docid
     * @publicName updateAppointment(target, appointment)
     * @public
     */
    updateAppointment(target: Appointment, appointment: Appointment): void;
}

/**
 * @public
 * @docid dxSchedulerAppointment
 * @namespace DevExpress.ui
 * @inherits CollectionWidgetItem
 * @type object
 */
export type Appointment = dxSchedulerAppointment;

/**
 * @namespace DevExpress.ui
 * @deprecated Use the Scheduler's Appointment type instead
 */
export type dxSchedulerAppointment = CollectionWidgetItem & {
    /**
     * @docid
     * @public
     */
    allDay?: boolean;
    /**
     * @docid
     * @public
     */
    description?: string;
    /**
     * @docid
     * @default false
     * @public
     */
    disabled?: boolean;
    /**
     * @docid
     * @public
     */
    endDate?: Date | string;
    /**
     * @docid
     * @public
     */
    endDateTimeZone?: string;
    /**
     * @docid
     * @public
     */
    html?: string;
    /**
     * @docid
     * @public
     */
    recurrenceException?: string;
    /**
     * @docid
     * @public
     */
    recurrenceRule?: string;
    /**
     * @docid
     * @public
     */
    startDate?: Date | string;
    /**
     * @docid
     * @public
     */
    startDateTimeZone?: string;
    /**
     * @docid
     * @public
     */
    template?: template;
    /**
     * @docid
     * @public
     */
    text?: string;
    /**
     * @docid
     * @default true
     * @public
     */
    visible?: boolean;
} & Record<string, any>;

/**
 * @docid
 * @public
 */
export type Occurrence = {
  /**
   * @docid
   * @public
   */
  startDate: Date;
  /**
   * @docid
   * @public
   */
  endDate: Date;
  /**
   * @docid
   * @public
   */
  appointmentData: Appointment;
};

/** @public */
export type Properties = dxSchedulerOptions;

/**
 * @docid
 * @public
 * @namespace DevExpress.ui
 */
export interface dxSchedulerScrolling {
  /**
   * @docid
   * @default "standard"
   * @public
   */
  mode?: ScrollMode;
}


