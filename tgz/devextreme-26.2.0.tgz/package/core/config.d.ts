/**
* DevExtreme (core/config.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import {
  config,
  GlobalConfig,
} from '../common';

export {
  FloatingActionButtonDirection,
} from '../common';

/**
 * @namespace DevExpress
 * @deprecated Use GlobalConfig from /common instead
 */
export type globalConfig = GlobalConfig;

export default config;
