/**
* DevExtreme (core/dom_adapter.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export interface DomAdapter {
  querySelectorAll: (element, selector) => any;
  elementMatches: (element, selector) => boolean;
  getActiveElement: (element?: HTMLElement | null) => HTMLElement;
  getDocument: () => Document;
  getDocumentElement: () => HTMLDocument & {
    scrollLeft: number;
    scrollTop: number;
    clientWidth: number;
    scrollHeight: number;
    offsetHeight: number;
    clientHeight: number;
  };
  getHead: () => any;
  listen: (element, event, callback, options?) => any;
  getReadyState: () => DocumentReadyState;
  isNode: (node: unknown) => node is Node;
  isDocument: (element: any) => boolean;
  isDocumentFragment: (element: any) => boolean;
  getBody: () => HTMLBodyElement;
  getRootNode: (element: HTMLElement) => Document | DocumentFragment;
  getAttribute: (element, name) => any;
  setAttribute: (element, name, value) => void;
  createAttribute: (text: string, context?: Document) => Attr;
  removeAttribute: (element, name) => void;
  isElementNode: (element: any) => boolean;
  createElement: (tagName: string, context?: Document) => HTMLElement;
  createDocumentFragment: () => DocumentFragment;
  createTextNode: (text: any, context?: any) => any;
  setClass: (element: HTMLElement, className: string, isAdd: boolean) => void;
  setText: (element, text) => void;
  setProperty: (element, name, value) => void;
  removeElement: (element: HTMLElement) => void;
  inject: (obj: Record<string, unknown>) => void;
  setStyle: (element: HTMLElement, name: string, value: string) => void;
  insertElement: (parentElement: HTMLElement, newElement: HTMLElement, nextSiblingElement?: HTMLElement) => void;
}

declare const domAdapter: DomAdapter;
export default domAdapter;
