/**
* DevExtreme (excel_exporter.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  DataGridCell,
  PivotGridCell,
  DataGridExportOptions as ExcelExportDataGridProps,
  PivotGridExportOptions as ExcelExportPivotGridProps,
  exportDataGrid,
  exportPivotGrid,
  CellAddress,
  CellRange,
} from './common/export/excel';

export {
  ExcelExportBaseOptions as ExcelExportBaseProps,
  ExcelPivotGridCell,
  ExcelDataGridCell,
} from './excel_exporter.types';
