/**
* DevExtreme (animation/position.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { PositionConfig } from '../common/core/animation';

export {
  CollisionResolution,
  CollisionResolutionCombination,
  PositionConfig,
} from '../common/core/animation';

/**
 * @public
 * @deprecated Use the PositionConfig type from common/core/animation instead
 * @namespace DevExpress.animation
 */
export interface positionConfig extends PositionConfig { }
