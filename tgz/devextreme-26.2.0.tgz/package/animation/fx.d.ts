/**
* DevExtreme (animation/fx.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { fx, AnimationConfig } from '../common/core/animation';

export {
  AnimationState,
  AnimationConfig,
  AnimationType,
} from '../common/core/animation';

/**
 * @public
 * @deprecated Use the AnimationConfig type from common/core/animation instead
 */
export type animationConfig = AnimationConfig;

export default fx;
