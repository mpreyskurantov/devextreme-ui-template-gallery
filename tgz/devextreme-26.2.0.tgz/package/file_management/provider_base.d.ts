/**
* DevExtreme (file_management/provider_base.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import FileSystemItem from './file_system_item';
import UploadInfo from './upload_info';

import {
    DxPromise,
} from '../core/utils/deferred';

/**
 * @namespace DevExpress.fileManagement
 * @docid
 * @type object
 */

export interface FileSystemProviderBaseOptions<T = FileSystemProviderBase> {
    /**
     * @docid
     * @public
     */
    dateModifiedExpr?: string | ((item: any, value?: any) => any);
    /**
     * @docid
     * @public
     */
    isDirectoryExpr?: string | ((item: any, value?: any) => any);
    /**
     * @docid
     * @public
     */
    keyExpr?: string | ((item: any, value?: any) => any);
    /**
     * @docid
     * @public
     */
    nameExpr?: string | ((item: any, value?: any) => any);
    /**
     * @docid
     * @public
     */
    sizeExpr?: string | ((item: any, value?: any) => any);
    /**
     * @docid
     * @public
     */
    thumbnailExpr?: string | ((item: any, value?: any) => any);
}
/**
 * @docid
 * @namespace DevExpress.fileManagement
 * @hidden
 * @options FileSystemProviderBaseOptions
 */
export default class FileSystemProviderBase {
    constructor(options?: FileSystemProviderBaseOptions);
    /**
     * @docid
     * @publicName getItems()
     * @return Promise<Array<FileSystemItem>>
     * @public
     */
    getItems(parentDirectory: FileSystemItem): DxPromise<Array<FileSystemItem>>;

    /**
     * @docid
     * @publicName renameItem()
     * @return Promise<any>
     * @public
     */
    renameItem(item: FileSystemItem, newName: string): DxPromise<any>;

    /**
     * @docid
     * @publicName createDirectory()
     * @return Promise<any>
     * @public
     */
    createDirectory(parentDirectory: FileSystemItem, name: string): DxPromise<any>;

    /**
     * @docid
     * @publicName deleteItems()
     * @return Array<Promise<any>>
     * @public
     */
    deleteItems(items: Array<FileSystemItem>): Array<DxPromise<any>>;

    /**
     * @docid
     * @publicName moveItems()
     * @return Array<Promise<any>>
     * @public
     */
    moveItems(items: Array<FileSystemItem>, destinationDirectory: FileSystemItem): Array<DxPromise<any>>;

    /**
     * @docid
     * @publicName copyItems()
     * @return Array<Promise<any>>
     * @public
     */
    copyItems(items: Array<FileSystemItem>, destinationDirectory: FileSystemItem): Array<DxPromise<any>>;

    /**
     * @docid
     * @publicName uploadFileChunk()
     * @return Promise<any>
     * @public
     */
    uploadFileChunk(fileData: File, uploadInfo: UploadInfo, destinationDirectory: FileSystemItem): DxPromise<any>;

    /**
     * @docid
     * @publicName abortFileUpload()
     * @return Promise<any>
     * @public
     */
    abortFileUpload(fileData: File, uploadInfo: UploadInfo, destinationDirectory: FileSystemItem): DxPromise<any>;

    /**
     * @docid
     * @publicName downloadItems()
     * @public
     */
    downloadItems(items: Array<FileSystemItem>): void;

    /**
     * @docid
     * @publicName getItemsContent()
     * @return Promise<object>
     * @public
     */
    getItemsContent(items: Array<FileSystemItem>): DxPromise<any>;
}
