/**
* DevExtreme (common/ai-integration.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @public
 */
export type Prompt = {
  /**
   * @docid
   * @public
   */
  system?: string;
  /**
   * @docid
   * @public
   */
  user?: string;
};

/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @type object
 * @public
 */
export type RequestParamsData = Record<PropertyKey, any>;
/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @type object
 * @public
 */
export type AIResponse = string | Record<PropertyKey, any>;

/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @public
 */
export type RequestParams = {
  /**
   * @docid
   * @public
   */
  prompt: Prompt;
  /**
   * @docid
   * @public
   */
  data?: RequestParamsData;
};

/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @public
 */
export type Response = {
  /**
   * @docid
   * @public
   */
  promise: Promise<AIResponse>;
  /**
   * @docid
   * @public
   */
  abort: () => void;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type ChangeStyleCommandParams = {
  text: string;
  writingStyle: string;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type ChangeToneCommandParams = {
  text: string;
  tone: string;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type ExecuteCommandParams = {
  text: string;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type ExpandCommandParams = {
  text: string;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type ProofreadCommandParams = {
  text: string;
};

/**
* @namespace DevExpress.aiIntegration
*/
export type ShortenCommandParams = {
 text: string;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type SummarizeCommandParams = {
  text: string;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type TranslateCommandParams = {
  text: string;
  lang: string;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type SmartPasteFieldType = | 'color'
  | 'boolean'
  | 'string'
  | 'stringArray'
  | 'number'
  | 'numberRange'
  | 'date'
  | 'dateRange';

/**
 * @namespace DevExpress.aiIntegration
 */
export type FieldInfo = {
  name: string;
  format: string;
  type?: SmartPasteFieldType;
  instruction?: string;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type SmartPasteCommandParams = {
  text: string;
  fields: FieldInfo[];
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type GenerateGridColumnCommandParams = {
  text: string;
  data: Record<PropertyKey, unknown>;
  additionalInfo?: Record<PropertyKey, unknown>;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type ExecuteGridAssistantCommandParams = {
  text: string;
  context: Record<string, unknown>;
  responseSchema: Record<string, unknown>;
  additionalInfo?: Record<PropertyKey, unknown>;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type ChangeStyleCommandResult = string;

/**
 * @namespace DevExpress.aiIntegration
 */
export type ChangeToneCommandResult = string;

/**
 * @namespace DevExpress.aiIntegration
 */
export type ExecuteCommandResult = string;

/**
 * @namespace DevExpress.aiIntegration
 */
export type ExpandCommandResult = string;

/**
 * @namespace DevExpress.aiIntegration
 */
export type ProofreadCommandResult = string;

/**
 * @namespace DevExpress.aiIntegration
 */
export type ShortenCommandResult = string;

/**
 * @namespace DevExpress.aiIntegration
 */
export type SummarizeCommandResult = string;

/**
 * @namespace DevExpress.aiIntegration
 */
export type TranslateCommandResult = string;

/**
 * @namespace DevExpress.aiIntegration
 */
export type SmartPasteResultFieldType = string | string[] | number | number[] | Date | Date[] | boolean;

/**
 * @namespace DevExpress.aiIntegration
 */
export type SmartPasteCommandResult = Array<{
  name: string;
  value: SmartPasteResultFieldType;
}>;

/**
 * @namespace DevExpress.aiIntegration
 */
export type GenerateGridColumnCommandResult = {
  data: Record<PropertyKey, string>;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type ExecuteGridAssistantAction = {
  name: string;
  args: Record<string, unknown>;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type ExecuteGridAssistantCommandResult = {
  actions: ExecuteGridAssistantAction[];
};

/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @public
 */
export type GenerateGridColumnCommandResponse = string | {
/**
 * @docid
 * @public
 */
  data: string | Record<PropertyKey, string>;
};

/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @public
 */
export type ExecuteGridAssistantCommandResponse = string | {
/**
 * @docid
 * @public
 */
  actions: ExecuteGridAssistantAction[] | string;
};

/**
 * @namespace DevExpress.aiIntegration
 */
export type RequestCallbacks<T> = {
  onChunk?: (chunk: string) => void;
  onComplete?: (finalResponse: T) => void;
  onError?: (error: Error) => void;
};

/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @public
 */
export type AIProvider = {
  /**
   * @docid
   * @public
   */
  sendRequest: (params: RequestParams) => Response;
};

/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @public
 */
export type AIIntegrationOptions = {
  /**
   * @docid
   * @public
   */
  lang?: string;
};

/**
 * @docid
 * @namespace DevExpress.aiIntegration
 * @public
 */
export class AIIntegration {
  constructor(provider: AIProvider, options?: AIIntegrationOptions);
  /**
   * @publicName changeStyle(params, callbacks)
   */
  changeStyle(params: ChangeStyleCommandParams, callbacks: RequestCallbacks<ChangeStyleCommandResult>): () => void;
  /**
   * @publicName changeTone(params, callbacks)
   */
  changeTone(params: ChangeToneCommandParams, callbacks: RequestCallbacks<ChangeToneCommandResult>): () => void;
  /**
   * @publicName execute(params, callbacks)
   */
  execute(params: ExecuteCommandParams, callbacks: RequestCallbacks<ExecuteCommandResult>): () => void;
  /**
   * @publicName expand(params, callbacks)
   */
  expand(params: ExpandCommandParams, callbacks: RequestCallbacks<ExpandCommandResult>): () => void;
  /**
   * @publicName proofread(params, callbacks)
   */
  proofread(params: ProofreadCommandParams, callbacks: RequestCallbacks<ProofreadCommandResult>): () => void;
  /**
   * @publicName shorten(params, callbacks)
   */
  shorten(params: ShortenCommandParams, callbacks: RequestCallbacks<ShortenCommandResult>): () => void;
  /**
   * @publicName summarize(params, callbacks)
   */
  summarize(params: SummarizeCommandParams, callbacks: RequestCallbacks<SummarizeCommandResult>): () => void;
  /**
   * @publicName translate(params, callbacks)
   */
  translate(params: TranslateCommandParams, callbacks: RequestCallbacks<TranslateCommandResult>): () => void;
  /**
   * @publicName smartPaste(params, callbacks)
   */
  smartPaste(params: SmartPasteCommandParams, callbacks: RequestCallbacks<SmartPasteCommandResult>): () => void;
  /**
   * @publicName generateGridColumn(params, callbacks)
   */
  generateGridColumn(params: GenerateGridColumnCommandParams, callbacks: RequestCallbacks<GenerateGridColumnCommandResult>): () => void;
  /**
   * @publicName executeGridAssistant(params, callbacks)
   */
  executeGridAssistant(params: ExecuteGridAssistantCommandParams, callbacks: RequestCallbacks<ExecuteGridAssistantCommandResult>): () => void;
}
