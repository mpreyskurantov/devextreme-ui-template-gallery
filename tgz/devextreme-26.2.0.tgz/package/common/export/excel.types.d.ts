/**
* DevExtreme (common/export/excel.types.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * @namespace DevExpress.exportInternal
 * @type object
 */
export interface CellAddress {
  /**
   * @docid
   * @public
   */
  row?: number;
  /**
   * @docid
   * @public
   */
  column?: number;
}

/**
* @namespace DevExpress.exportInternal
* @type object
*/
export interface CellRange {
/**
 * @docid
 * @public
 */
from?: CellAddress;
/**
 * @docid
 * @public
 */
to?: CellAddress;
}
