/**
* DevExtreme (bundles/modules/data.odata.legacy.js)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

/* eslint-disable import/no-commonjs */
require('./data');
require('../../data/odata/store');
require('../../data/odata/context');
require('../../data/odata/utils');
