/**
* DevExtreme (bundles/modules/common.charts.js)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
"use strict";

/* eslint-disable import/no-commonjs */
const DevExpress = require('./core');
DevExpress.common = DevExpress.common || {};
DevExpress.common.charts = require('../../common/charts');
module.exports = DevExpress.common.charts;
