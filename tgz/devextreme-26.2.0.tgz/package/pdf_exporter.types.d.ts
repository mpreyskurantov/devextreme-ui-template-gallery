/**
* DevExtreme (pdf_exporter.types.d.ts)
* Version: 26.2.0
* Build date: Fri Sep 11 2026
*
* Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import {
  DataGridCell as ExcelCell,
} from './common/export/excel';

/**
  * @namespace DevExpress.pdfExporter
  * @deprecated Use DataGridCell instead
  */
export interface PdfDataGridCell extends ExcelCell {}
