/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxVectorMap, { Properties } from "devextreme/viz/vector_map";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ClickEvent, DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, TooltipHiddenEvent, TooltipShownEvent, dxVectorMapAnnotationConfig, MapLayerElement, VectorMapMarkerType, VectorMapLayerType, VectorMapLegendItem, VectorMapMarkerShape } from "devextreme/viz/vector_map";
import type { DashStyle, Font as ChartsFont, TextOverflow, AnnotationType, WordWrap, Palette } from "devextreme/common/charts";
import type { template, HorizontalAlignment, VerticalEdge, ExportFormat, SingleMultipleOrNone, Position, Orientation } from "devextreme/common";
import type { DataSourceOptions } from "devextreme/data/data_source";
import type { Store } from "devextreme/data/store";
import type DataSource from "devextreme/data/data_source";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IVectorMapOptionsNarrowedEvents = {
    onClick?: ((e: ClickEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onDrawn?: ((e: DrawnEvent) => void);
    onExported?: ((e: ExportedEvent) => void);
    onExporting?: ((e: ExportingEvent) => void);
    onFileSaving?: ((e: FileSavingEvent) => void);
    onIncidentOccurred?: ((e: IncidentOccurredEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onTooltipHidden?: ((e: TooltipHiddenEvent) => void) | undefined;
    onTooltipShown?: ((e: TooltipShownEvent) => void) | undefined;
};
type IVectorMapOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IVectorMapOptionsNarrowedEvents> & IHtmlOptions & {
    defaultLoadingIndicator?: Record<string, any>;
    onLoadingIndicatorChange?: (value: Record<string, any>) => void;
}>;
interface VectorMapRef {
    instance: () => dxVectorMap;
}
declare const VectorMap: (props: React.PropsWithChildren<IVectorMapOptions> & {
    ref?: Ref<VectorMapRef>;
}) => ReactElement | null;
type IAnnotationProps = React.PropsWithChildren<{
    allowDragging?: boolean;
    arrowLength?: number;
    arrowWidth?: number;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    coordinates?: Array<number> | undefined;
    customizeTooltip?: ((annotation: dxVectorMapAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont;
    height?: number | undefined;
    image?: Record<string, any> | string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    name?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    template?: ((annotation: dxVectorMapAnnotationConfig | any, element: any) => string | any) | template | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    tooltipEnabled?: boolean;
    tooltipTemplate?: ((annotation: dxVectorMapAnnotationConfig | any, element: any) => string | any) | template | undefined;
    type?: AnnotationType | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap;
    x?: number | undefined;
    y?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    tooltipRender?: (...params: any) => React.ReactNode;
    tooltipComponent?: React.ComponentType<any>;
}>;
declare const Annotation: ((props: IAnnotationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDragging?: boolean | undefined;
    arrowLength?: number | undefined;
    arrowWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    coordinates?: Array<number> | undefined;
    customizeTooltip?: ((annotation: dxVectorMapAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont | undefined;
    height?: number | undefined;
    image?: string | Record<string, any> | {
        height?: number | undefined;
        url?: string | undefined;
        width?: number | undefined;
    } | undefined;
    name?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    template?: template | ((annotation: dxVectorMapAnnotationConfig | any, element: any) => string | any) | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    tooltipEnabled?: boolean | undefined;
    tooltipTemplate?: template | ((annotation: dxVectorMapAnnotationConfig | any, element: any) => string | any) | undefined;
    type?: AnnotationType | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap | undefined;
    x?: number | undefined;
    y?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    tooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    tooltipComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnnotationBorderProps = React.PropsWithChildren<{
    color?: string;
    cornerRadius?: number;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const AnnotationBorder: ((props: IAnnotationBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBackgroundProps = React.PropsWithChildren<{
    borderColor?: string;
    color?: string;
}>;
declare const Background: ((props: IBackgroundProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    borderColor?: string | undefined;
    color?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBorderProps = React.PropsWithChildren<{
    color?: string;
    cornerRadius?: number;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Border: ((props: IBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAnnotationSettingsProps = React.PropsWithChildren<{
    allowDragging?: boolean;
    arrowLength?: number;
    arrowWidth?: number;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    coordinates?: Array<number> | undefined;
    customizeTooltip?: ((annotation: dxVectorMapAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont;
    height?: number | undefined;
    image?: Record<string, any> | string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    template?: ((annotation: dxVectorMapAnnotationConfig | any, element: any) => string | any) | template | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    tooltipEnabled?: boolean;
    tooltipTemplate?: ((annotation: dxVectorMapAnnotationConfig | any, element: any) => string | any) | template | undefined;
    type?: AnnotationType | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap;
    x?: number | undefined;
    y?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    tooltipRender?: (...params: any) => React.ReactNode;
    tooltipComponent?: React.ComponentType<any>;
}>;
declare const CommonAnnotationSettings: ((props: ICommonAnnotationSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDragging?: boolean | undefined;
    arrowLength?: number | undefined;
    arrowWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    coordinates?: Array<number> | undefined;
    customizeTooltip?: ((annotation: dxVectorMapAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont | undefined;
    height?: number | undefined;
    image?: string | Record<string, any> | {
        height?: number | undefined;
        url?: string | undefined;
        width?: number | undefined;
    } | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    template?: template | ((annotation: dxVectorMapAnnotationConfig | any, element: any) => string | any) | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    tooltipEnabled?: boolean | undefined;
    tooltipTemplate?: template | ((annotation: dxVectorMapAnnotationConfig | any, element: any) => string | any) | undefined;
    type?: AnnotationType | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap | undefined;
    x?: number | undefined;
    y?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    tooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    tooltipComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IControlBarProps = React.PropsWithChildren<{
    borderColor?: string;
    color?: string;
    enabled?: boolean;
    horizontalAlignment?: HorizontalAlignment;
    margin?: number;
    opacity?: number;
    panVisible?: boolean;
    verticalAlignment?: VerticalEdge;
    zoomVisible?: boolean;
}>;
declare const ControlBar: ((props: IControlBarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    borderColor?: string | undefined;
    color?: string | undefined;
    enabled?: boolean | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | undefined;
    opacity?: number | undefined;
    panVisible?: boolean | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    zoomVisible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IExportProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    fileName?: string;
    formats?: Array<ExportFormat>;
    margin?: number;
    printingEnabled?: boolean;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
}>;
declare const Export: ((props: IExportProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    fileName?: string | undefined;
    formats?: ExportFormat[] | undefined;
    margin?: number | undefined;
    printingEnabled?: boolean | undefined;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFontProps = React.PropsWithChildren<{
    color?: string;
    family?: string;
    opacity?: number;
    size?: number | string;
    weight?: number;
}>;
declare const Font: ((props: IFontProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    family?: string | undefined;
    opacity?: number | undefined;
    size?: string | number | undefined;
    weight?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IImageProps = React.PropsWithChildren<{
    height?: number;
    url?: string | undefined;
    width?: number;
}>;
declare const Image: ((props: IImageProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    url?: string | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    dataField?: string;
    enabled?: boolean;
    font?: ChartsFont;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    dataField?: string | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILayerProps = React.PropsWithChildren<{
    borderColor?: string;
    borderWidth?: number;
    color?: string;
    colorGroupingField?: string | undefined;
    colorGroups?: Array<number> | undefined;
    customize?: ((elements: Array<MapLayerElement>) => void);
    dataField?: string | undefined;
    dataSource?: Array<any> | DataSource | DataSourceOptions | null | Record<string, any> | Store | string;
    elementType?: VectorMapMarkerType;
    hoveredBorderColor?: string;
    hoveredBorderWidth?: number;
    hoveredColor?: string;
    hoverEnabled?: boolean;
    label?: Record<string, any> | {
        dataField?: string;
        enabled?: boolean;
        font?: ChartsFont;
    };
    maxSize?: number;
    minSize?: number;
    name?: string;
    opacity?: number;
    palette?: Array<string> | Palette;
    paletteIndex?: number;
    paletteSize?: number;
    selectedBorderColor?: string;
    selectedBorderWidth?: number;
    selectedColor?: string;
    selectionMode?: SingleMultipleOrNone;
    size?: number;
    sizeGroupingField?: string | undefined;
    sizeGroups?: Array<number> | undefined;
    type?: VectorMapLayerType;
}>;
declare const Layer: ((props: ILayerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    borderColor?: string | undefined;
    borderWidth?: number | undefined;
    color?: string | undefined;
    colorGroupingField?: string | undefined;
    colorGroups?: Array<number> | undefined;
    customize?: ((elements: Array<MapLayerElement>) => void) | undefined;
    dataField?: string | undefined;
    dataSource?: string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null | undefined;
    elementType?: VectorMapMarkerType | undefined;
    hoveredBorderColor?: string | undefined;
    hoveredBorderWidth?: number | undefined;
    hoveredColor?: string | undefined;
    hoverEnabled?: boolean | undefined;
    label?: Record<string, any> | {
        dataField?: string | undefined;
        enabled?: boolean | undefined;
        font?: ChartsFont | undefined;
    } | undefined;
    maxSize?: number | undefined;
    minSize?: number | undefined;
    name?: string | undefined;
    opacity?: number | undefined;
    palette?: string[] | Palette | undefined;
    paletteIndex?: number | undefined;
    paletteSize?: number | undefined;
    selectedBorderColor?: string | undefined;
    selectedBorderWidth?: number | undefined;
    selectedColor?: string | undefined;
    selectionMode?: SingleMultipleOrNone | undefined;
    size?: number | undefined;
    sizeGroupingField?: string | undefined;
    sizeGroups?: Array<number> | undefined;
    type?: VectorMapLayerType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendProps = React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    columnCount?: number;
    columnItemSpacing?: number;
    customizeHint?: ((itemInfo: {
        color: string;
        end: number;
        index: number;
        size: number;
        start: number;
    }) => string);
    customizeItems?: ((items: Array<VectorMapLegendItem>) => Array<VectorMapLegendItem>);
    customizeText?: ((itemInfo: {
        color: string;
        end: number;
        index: number;
        size: number;
        start: number;
    }) => string);
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    itemsAlignment?: HorizontalAlignment | undefined;
    itemTextPosition?: Position | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    markerColor?: string | undefined;
    markerShape?: VectorMapMarkerShape;
    markerSize?: number;
    markerTemplate?: ((legendItem: VectorMapLegendItem, element: any) => string | any) | template | undefined;
    orientation?: Orientation | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    rowCount?: number;
    rowItemSpacing?: number;
    source?: Record<string, any> | {
        grouping?: string;
        layer?: string;
    };
    title?: Record<string, any> | string | {
        font?: ChartsFont;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: Record<string, any> | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: Record<string, any> | string | {
            font?: ChartsFont;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    };
    verticalAlignment?: VerticalEdge;
    visible?: boolean;
    markerRender?: (...params: any) => React.ReactNode;
    markerComponent?: React.ComponentType<any>;
}>;
declare const Legend: ((props: ILegendProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    columnCount?: number | undefined;
    columnItemSpacing?: number | undefined;
    customizeHint?: ((itemInfo: {
        color: string;
        end: number;
        index: number;
        size: number;
        start: number;
    }) => string) | undefined;
    customizeItems?: ((items: Array<VectorMapLegendItem>) => Array<VectorMapLegendItem>) | undefined;
    customizeText?: ((itemInfo: {
        color: string;
        end: number;
        index: number;
        size: number;
        start: number;
    }) => string) | undefined;
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    itemsAlignment?: HorizontalAlignment | undefined;
    itemTextPosition?: Position | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    markerColor?: string | undefined;
    markerShape?: VectorMapMarkerShape | undefined;
    markerSize?: number | undefined;
    markerTemplate?: template | ((legendItem: VectorMapLegendItem, element: any) => string | any) | undefined;
    orientation?: Orientation | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    rowCount?: number | undefined;
    rowItemSpacing?: number | undefined;
    source?: Record<string, any> | {
        grouping?: string | undefined;
        layer?: string | undefined;
    } | undefined;
    title?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: Record<string, any> | {
            bottom?: number | undefined;
            left?: number | undefined;
            right?: number | undefined;
            top?: number | undefined;
        } | undefined;
        placeholderSize?: number | undefined;
        subtitle?: string | Record<string, any> | {
            font?: ChartsFont | undefined;
            offset?: number | undefined;
            text?: string | undefined;
        } | undefined;
        text?: string | undefined;
        verticalAlignment?: VerticalEdge | undefined;
    } | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    visible?: boolean | undefined;
    markerRender?: ((...params: any) => React.ReactNode) | undefined;
    markerComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendTitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string | undefined;
    };
    text?: string | undefined;
    verticalAlignment?: VerticalEdge;
}>;
declare const LegendTitle: ((props: ILegendTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
    } | undefined;
    text?: string | undefined;
    verticalAlignment?: VerticalEdge | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendTitleSubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string | undefined;
}>;
declare const LegendTitleSubtitle: ((props: ILegendTitleSubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadingIndicatorProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    font?: ChartsFont;
    show?: boolean;
    text?: string;
    defaultShow?: boolean;
    onShowChange?: (value: boolean) => void;
}>;
declare const LoadingIndicator: ((props: ILoadingIndicatorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    show?: boolean | undefined;
    text?: string | undefined;
    defaultShow?: boolean | undefined;
    onShowChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarginProps = React.PropsWithChildren<{
    bottom?: number;
    left?: number;
    right?: number;
    top?: number;
}>;
declare const Margin: ((props: IMarginProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    bottom?: number | undefined;
    left?: number | undefined;
    right?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IProjectionProps = React.PropsWithChildren<{
    aspectRatio?: number;
    from?: ((coordinates: Array<number>) => Array<number>);
    to?: ((coordinates: Array<number>) => Array<number>);
}>;
declare const Projection: ((props: IProjectionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aspectRatio?: number | undefined;
    from?: ((coordinates: Array<number>) => Array<number>) | undefined;
    to?: ((coordinates: Array<number>) => Array<number>) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShadowProps = React.PropsWithChildren<{
    blur?: number;
    color?: string;
    offsetX?: number;
    offsetY?: number;
    opacity?: number;
}>;
declare const Shadow: ((props: IShadowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    blur?: number | undefined;
    color?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISizeProps = React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
}>;
declare const Size: ((props: ISizeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISourceProps = React.PropsWithChildren<{
    grouping?: string;
    layer?: string;
}>;
declare const Source: ((props: ISourceProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    grouping?: string | undefined;
    layer?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Subtitle: ((props: ISubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string | undefined;
    verticalAlignment?: VerticalEdge;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Title: ((props: ITitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipProps = React.PropsWithChildren<{
    arrowLength?: number;
    border?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    container?: any | string | undefined;
    contentTemplate?: ((info: MapLayerElement, element: any) => string | any) | template | undefined;
    cornerRadius?: number;
    customizeTooltip?: ((info: MapLayerElement) => Record<string, any>) | undefined;
    enabled?: boolean;
    font?: ChartsFont;
    opacity?: number | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    zIndex?: number | undefined;
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
}>;
declare const Tooltip: ((props: ITooltipProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    arrowLength?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    container?: any | string | undefined;
    contentTemplate?: template | ((info: MapLayerElement, element: any) => string | any) | undefined;
    cornerRadius?: number | undefined;
    customizeTooltip?: ((info: MapLayerElement) => Record<string, any>) | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    zIndex?: number | undefined;
    contentRender?: ((...params: any) => React.ReactNode) | undefined;
    contentComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipBorderProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const TooltipBorder: ((props: ITooltipBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IVectorMapTitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string | undefined;
    textOverflow?: TextOverflow;
    verticalAlignment?: VerticalEdge;
    wordWrap?: WordWrap;
}>;
declare const VectorMapTitle: ((props: IVectorMapTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IVectorMapTitleSubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const VectorMapTitleSubtitle: ((props: IVectorMapTitleSubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default VectorMap;
export { VectorMap, IVectorMapOptions, VectorMapRef, Annotation, IAnnotationProps, AnnotationBorder, IAnnotationBorderProps, Background, IBackgroundProps, Border, IBorderProps, CommonAnnotationSettings, ICommonAnnotationSettingsProps, ControlBar, IControlBarProps, Export, IExportProps, Font, IFontProps, Image, IImageProps, Label, ILabelProps, Layer, ILayerProps, Legend, ILegendProps, LegendTitle, ILegendTitleProps, LegendTitleSubtitle, ILegendTitleSubtitleProps, LoadingIndicator, ILoadingIndicatorProps, Margin, IMarginProps, Projection, IProjectionProps, Shadow, IShadowProps, Size, ISizeProps, Source, ISourceProps, Subtitle, ISubtitleProps, Title, ITitleProps, Tooltip, ITooltipProps, TooltipBorder, ITooltipBorderProps, VectorMapTitle, IVectorMapTitleProps, VectorMapTitleSubtitle, IVectorMapTitleSubtitleProps };
import type * as VectorMapTypes from 'devextreme/viz/vector_map_types';
export { VectorMapTypes };
