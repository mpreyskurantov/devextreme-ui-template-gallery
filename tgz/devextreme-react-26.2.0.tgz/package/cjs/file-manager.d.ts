/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxFileManager, { Properties } from "devextreme/ui/file_manager";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ContentReadyEvent, ContextMenuItemClickEvent, ContextMenuShowingEvent, DirectoryCreatedEvent, DirectoryCreatingEvent, DisposingEvent, ErrorOccurredEvent, FileUploadedEvent, FileUploadingEvent, InitializedEvent, ItemCopiedEvent, ItemCopyingEvent, ItemDeletedEvent, ItemDeletingEvent, ItemDownloadingEvent, ItemMovedEvent, ItemMovingEvent, ItemRenamedEvent, ItemRenamingEvent, SelectedFileOpenedEvent, ToolbarItemClickEvent, dxFileManagerContextMenuItem, FileManagerPredefinedContextMenuItem, dxFileManagerDetailsColumn, FileManagerPredefinedToolbarItem, FileManagerItemViewMode, dxFileManagerToolbarItem } from "devextreme/ui/file_manager";
import type { HorizontalAlignment, DataType, SortOrder, ToolbarItemLocation, ToolbarItemComponent } from "devextreme/common";
import type { LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IFileManagerOptionsNarrowedEvents = {
    onContentReady?: ((e: ContentReadyEvent) => void);
    onContextMenuItemClick?: ((e: ContextMenuItemClickEvent) => void) | undefined;
    onContextMenuShowing?: ((e: ContextMenuShowingEvent) => void) | undefined;
    onDirectoryCreated?: ((e: DirectoryCreatedEvent) => void) | undefined;
    onDirectoryCreating?: ((e: DirectoryCreatingEvent) => void) | undefined;
    onDisposing?: ((e: DisposingEvent) => void);
    onErrorOccurred?: ((e: ErrorOccurredEvent) => void) | undefined;
    onFileUploaded?: ((e: FileUploadedEvent) => void) | undefined;
    onFileUploading?: ((e: FileUploadingEvent) => void) | undefined;
    onInitialized?: ((e: InitializedEvent) => void);
    onItemCopied?: ((e: ItemCopiedEvent) => void) | undefined;
    onItemCopying?: ((e: ItemCopyingEvent) => void) | undefined;
    onItemDeleted?: ((e: ItemDeletedEvent) => void) | undefined;
    onItemDeleting?: ((e: ItemDeletingEvent) => void) | undefined;
    onItemDownloading?: ((e: ItemDownloadingEvent) => void) | undefined;
    onItemMoved?: ((e: ItemMovedEvent) => void) | undefined;
    onItemMoving?: ((e: ItemMovingEvent) => void) | undefined;
    onItemRenamed?: ((e: ItemRenamedEvent) => void) | undefined;
    onItemRenaming?: ((e: ItemRenamingEvent) => void) | undefined;
    onSelectedFileOpened?: ((e: SelectedFileOpenedEvent) => void) | undefined;
    onToolbarItemClick?: ((e: ToolbarItemClickEvent) => void);
};
type IFileManagerOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IFileManagerOptionsNarrowedEvents> & IHtmlOptions>;
interface FileManagerRef {
    instance: () => dxFileManager;
}
declare const FileManager: (props: React.PropsWithChildren<IFileManagerOptions> & {
    ref?: Ref<FileManagerRef>;
}) => ReactElement | null;
type IColumnProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    caption?: string | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    hidingPriority?: number | undefined;
    sortIndex?: number | undefined;
    sortOrder?: SortOrder | undefined;
    visible?: boolean;
    visibleIndex?: number | undefined;
    width?: number | string | undefined;
}>;
declare const Column: ((props: IColumnProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    caption?: string | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    hidingPriority?: number | undefined;
    sortIndex?: number | undefined;
    sortOrder?: SortOrder | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    width?: number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IContextMenuProps = React.PropsWithChildren<{
    items?: Array<dxFileManagerContextMenuItem | FileManagerPredefinedContextMenuItem>;
}>;
declare const ContextMenu: ((props: IContextMenuProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    items?: (dxFileManagerContextMenuItem | FileManagerPredefinedContextMenuItem)[] | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IContextMenuItemProps = React.PropsWithChildren<{
    beginGroup?: boolean;
    closeMenuOnClick?: boolean;
    disabled?: boolean;
    icon?: string;
    items?: Array<dxFileManagerContextMenuItem>;
    name?: FileManagerPredefinedContextMenuItem | string;
    selectable?: boolean;
    selected?: boolean;
    text?: string;
    visible?: boolean | undefined;
}>;
declare const ContextMenuItem: ((props: IContextMenuItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    beginGroup?: boolean | undefined;
    closeMenuOnClick?: boolean | undefined;
    disabled?: boolean | undefined;
    icon?: string | undefined;
    items?: dxFileManagerContextMenuItem[] | undefined;
    name?: string | undefined;
    selectable?: boolean | undefined;
    selected?: boolean | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDetailsProps = React.PropsWithChildren<{
    columns?: Array<dxFileManagerDetailsColumn | string>;
}>;
declare const Details: ((props: IDetailsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    columns?: (string | dxFileManagerDetailsColumn)[] | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFileSelectionItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    icon?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    name?: FileManagerPredefinedToolbarItem | string;
    options?: any;
    showText?: ShowTextMode;
    text?: string;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent;
}>;
declare const FileSelectionItem: ((props: IFileSelectionItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    icon?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    name?: string | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    beginGroup?: boolean;
    closeMenuOnClick?: boolean;
    disabled?: boolean;
    icon?: string;
    items?: Array<dxFileManagerContextMenuItem>;
    name?: FileManagerPredefinedContextMenuItem | string | FileManagerPredefinedToolbarItem;
    selectable?: boolean;
    selected?: boolean;
    text?: string;
    visible?: boolean | undefined;
    cssClass?: string | undefined;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    options?: any;
    showText?: ShowTextMode;
    widget?: ToolbarItemComponent;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    beginGroup?: boolean | undefined;
    closeMenuOnClick?: boolean | undefined;
    disabled?: boolean | undefined;
    icon?: string | undefined;
    items?: dxFileManagerContextMenuItem[] | undefined;
    name?: string | undefined;
    selectable?: boolean | undefined;
    selected?: boolean | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    cssClass?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    widget?: ToolbarItemComponent | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemViewProps = React.PropsWithChildren<{
    details?: Record<string, any> | {
        columns?: Array<dxFileManagerDetailsColumn | string>;
    };
    mode?: FileManagerItemViewMode;
    showFolders?: boolean;
    showParentFolder?: boolean;
}>;
declare const ItemView: ((props: IItemViewProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    details?: Record<string, any> | {
        columns?: (string | dxFileManagerDetailsColumn)[] | undefined;
    } | undefined;
    mode?: FileManagerItemViewMode | undefined;
    showFolders?: boolean | undefined;
    showParentFolder?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type INotificationsProps = React.PropsWithChildren<{
    showPanel?: boolean;
    showPopup?: boolean;
}>;
declare const Notifications: ((props: INotificationsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    showPanel?: boolean | undefined;
    showPopup?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPermissionsProps = React.PropsWithChildren<{
    copy?: boolean;
    create?: boolean;
    delete?: boolean;
    download?: boolean;
    move?: boolean;
    rename?: boolean;
    upload?: boolean;
}>;
declare const Permissions: ((props: IPermissionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    copy?: boolean | undefined;
    create?: boolean | undefined;
    delete?: boolean | undefined;
    download?: boolean | undefined;
    move?: boolean | undefined;
    rename?: boolean | undefined;
    upload?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarProps = React.PropsWithChildren<{
    fileSelectionItems?: Array<dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem>;
    items?: Array<dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem>;
}>;
declare const Toolbar: ((props: IToolbarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    fileSelectionItems?: (FileManagerPredefinedToolbarItem | dxFileManagerToolbarItem)[] | undefined;
    items?: (FileManagerPredefinedToolbarItem | dxFileManagerToolbarItem)[] | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    icon?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    name?: FileManagerPredefinedToolbarItem | string;
    options?: any;
    showText?: ShowTextMode;
    text?: string;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent;
}>;
declare const ToolbarItem: ((props: IToolbarItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    icon?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    name?: string | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IUploadProps = React.PropsWithChildren<{
    chunkSize?: number;
    maxFileSize?: number;
}>;
declare const Upload: ((props: IUploadProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    chunkSize?: number | undefined;
    maxFileSize?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default FileManager;
export { FileManager, IFileManagerOptions, FileManagerRef, Column, IColumnProps, ContextMenu, IContextMenuProps, ContextMenuItem, IContextMenuItemProps, Details, IDetailsProps, FileSelectionItem, IFileSelectionItemProps, Item, IItemProps, ItemView, IItemViewProps, Notifications, INotificationsProps, Permissions, IPermissionsProps, Toolbar, IToolbarProps, ToolbarItem, IToolbarItemProps, Upload, IUploadProps };
import type * as FileManagerTypes from 'devextreme/ui/file_manager_types';
export { FileManagerTypes };
