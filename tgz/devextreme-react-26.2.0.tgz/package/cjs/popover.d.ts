/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxPopover, { Properties } from "devextreme/ui/popover";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { Position as CommonPosition, HorizontalAlignment, VerticalAlignment, Direction, PositionAlignment, ToolbarItemLocation, template, ToolbarItemComponent } from "devextreme/common";
import type { PositionConfig, AnimationConfig, CollisionResolution, AnimationState, AnimationType, CollisionResolutionCombination } from "devextreme/common/core/animation";
import type { ContentReadyEvent, DisposingEvent, HiddenEvent, HidingEvent, InitializedEvent, ShowingEvent, ShownEvent, TitleRenderedEvent } from "devextreme/ui/popover";
import type { LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
import type { ToolbarLocation } from "devextreme/ui/popup";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IPopoverOptionsNarrowedEvents = {
    onContentReady?: ((e: ContentReadyEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onHidden?: ((e: HiddenEvent) => void);
    onHiding?: ((e: HidingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onShowing?: ((e: ShowingEvent) => void);
    onShown?: ((e: ShownEvent) => void);
    onTitleRendered?: ((e: TitleRenderedEvent) => void);
};
type IPopoverOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IPopoverOptionsNarrowedEvents> & IHtmlOptions & {
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
    titleRender?: (...params: any) => React.ReactNode;
    titleComponent?: React.ComponentType<any>;
    defaultHeight?: number | string;
    defaultPosition?: CommonPosition | PositionConfig;
    defaultVisible?: boolean;
    defaultWidth?: number | string;
    onHeightChange?: (value: number | string) => void;
    onPositionChange?: (value: CommonPosition | PositionConfig) => void;
    onVisibleChange?: (value: boolean) => void;
    onWidthChange?: (value: number | string) => void;
}>;
interface PopoverRef {
    instance: () => dxPopover;
}
declare const Popover: (props: React.PropsWithChildren<IPopoverOptions> & {
    ref?: Ref<PopoverRef>;
}) => ReactElement | null;
type IAnimationProps = React.PropsWithChildren<{
    hide?: AnimationConfig;
    show?: AnimationConfig;
}>;
declare const Animation: ((props: IAnimationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    hide?: AnimationConfig | undefined;
    show?: AnimationConfig | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAtProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const At: ((props: IAtProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBoundaryOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const BoundaryOffset: ((props: IBoundaryOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICollisionProps = React.PropsWithChildren<{
    x?: CollisionResolution;
    y?: CollisionResolution;
}>;
declare const Collision: ((props: ICollisionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: CollisionResolution | undefined;
    y?: CollisionResolution | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFromProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const From: ((props: IFromProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHideProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Hide: ((props: IHideProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHideEventProps = React.PropsWithChildren<{
    delay?: number | undefined;
    name?: string | undefined;
}>;
declare const HideEvent: ((props: IHideEventProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    delay?: number | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMyProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const My: ((props: IMyProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const Offset: ((props: IOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPositionProps = React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    boundary?: any | string;
    boundaryOffset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
    collision?: CollisionResolutionCombination | Record<string, any> | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    of?: any | string;
    offset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
}>;
declare const Position: ((props: IPositionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    boundary?: any | string;
    boundaryOffset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    collision?: Record<string, any> | CollisionResolutionCombination | {
        x?: CollisionResolution | undefined;
        y?: CollisionResolution | undefined;
    } | undefined;
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    of?: any | string;
    offset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShowProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Show: ((props: IShowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShowEventProps = React.PropsWithChildren<{
    delay?: number | undefined;
    name?: string | undefined;
}>;
declare const ShowEvent: ((props: IShowEventProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    delay?: number | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const To: ((props: IToProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    toolbar?: ToolbarLocation;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const ToolbarItem: ((props: IToolbarItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    toolbar?: ToolbarLocation | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Popover;
export { Popover, IPopoverOptions, PopoverRef, Animation, IAnimationProps, At, IAtProps, BoundaryOffset, IBoundaryOffsetProps, Collision, ICollisionProps, From, IFromProps, Hide, IHideProps, HideEvent, IHideEventProps, My, IMyProps, Offset, IOffsetProps, Position, IPositionProps, Show, IShowProps, ShowEvent, IShowEventProps, To, IToProps, ToolbarItem, IToolbarItemProps };
import type * as PopoverTypes from 'devextreme/ui/popover_types';
export { PopoverTypes };
