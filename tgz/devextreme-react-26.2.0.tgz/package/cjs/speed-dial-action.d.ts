/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxSpeedDialAction, { Properties } from "devextreme/ui/speed_dial_action";
import { IHtmlOptions } from "./core/component";
import type { ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent } from "devextreme/ui/speed_dial_action";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ISpeedDialActionOptionsNarrowedEvents = {
    onClick?: ((e: ClickEvent) => void);
    onContentReady?: ((e: ContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
};
type ISpeedDialActionOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, ISpeedDialActionOptionsNarrowedEvents> & IHtmlOptions>;
interface SpeedDialActionRef {
    instance: () => dxSpeedDialAction;
}
declare const SpeedDialAction: (props: React.PropsWithChildren<ISpeedDialActionOptions> & {
    ref?: Ref<SpeedDialActionRef>;
}) => ReactElement | null;
export default SpeedDialAction;
export { SpeedDialAction, ISpeedDialActionOptions, SpeedDialActionRef };
import type * as SpeedDialActionTypes from 'devextreme/ui/speed_dial_action_types';
export { SpeedDialActionTypes };
