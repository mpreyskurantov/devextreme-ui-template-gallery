/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxCalendar, { Properties } from "devextreme/ui/calendar";
import { IHtmlOptions } from "./core/component";
import type { CalendarZoomLevel, DisposingEvent, InitializedEvent, ValueChangedEvent } from "devextreme/ui/calendar";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ICalendarOptionsNarrowedEvents = {
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onValueChanged?: ((e: ValueChangedEvent) => void);
};
type ICalendarOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, ICalendarOptionsNarrowedEvents> & IHtmlOptions & {
    cellRender?: (...params: any) => React.ReactNode;
    cellComponent?: React.ComponentType<any>;
    defaultValue?: Array<Date | null | number | string> | Date | null | number | string;
    defaultZoomLevel?: CalendarZoomLevel;
    onValueChange?: (value: Array<Date | null | number | string> | Date | null | number | string) => void;
    onZoomLevelChange?: (value: CalendarZoomLevel) => void;
}>;
interface CalendarRef {
    instance: () => dxCalendar;
}
declare const Calendar: (props: React.PropsWithChildren<ICalendarOptions> & {
    ref?: Ref<CalendarRef>;
}) => ReactElement | null;
export default Calendar;
export { Calendar, ICalendarOptions, CalendarRef };
import type * as CalendarTypes from 'devextreme/ui/calendar_types';
export { CalendarTypes };
