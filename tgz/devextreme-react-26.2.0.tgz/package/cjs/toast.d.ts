/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxToast, { Properties } from "devextreme/ui/toast";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { PositionConfig, AnimationConfig, CollisionResolution, AnimationState, AnimationType, CollisionResolutionCombination } from "devextreme/common/core/animation";
import type { ContentReadyEvent, DisposingEvent, HiddenEvent, HidingEvent, InitializedEvent, ShowingEvent, ShownEvent } from "devextreme/ui/toast";
import type { HorizontalAlignment, VerticalAlignment, Direction, PositionAlignment } from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IToastOptionsNarrowedEvents = {
    onContentReady?: ((e: ContentReadyEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onHidden?: ((e: HiddenEvent) => void);
    onHiding?: ((e: HidingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onShowing?: ((e: ShowingEvent) => void);
    onShown?: ((e: ShownEvent) => void);
};
type IToastOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IToastOptionsNarrowedEvents> & IHtmlOptions & {
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
    defaultPosition?: PositionConfig | string;
    defaultVisible?: boolean;
    onPositionChange?: (value: PositionConfig | string) => void;
    onVisibleChange?: (value: boolean) => void;
}>;
interface ToastRef {
    instance: () => dxToast;
}
declare const Toast: (props: React.PropsWithChildren<IToastOptions> & {
    ref?: Ref<ToastRef>;
}) => ReactElement | null;
type IAnimationProps = React.PropsWithChildren<{
    hide?: AnimationConfig;
    show?: AnimationConfig;
}>;
declare const Animation: ((props: IAnimationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    hide?: AnimationConfig | undefined;
    show?: AnimationConfig | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAtProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const At: ((props: IAtProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBoundaryOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const BoundaryOffset: ((props: IBoundaryOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICollisionProps = React.PropsWithChildren<{
    x?: CollisionResolution;
    y?: CollisionResolution;
}>;
declare const Collision: ((props: ICollisionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: CollisionResolution | undefined;
    y?: CollisionResolution | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFromProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const From: ((props: IFromProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHideProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Hide: ((props: IHideProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMyProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const My: ((props: IMyProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const Offset: ((props: IOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPositionProps = React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    boundary?: any | string;
    boundaryOffset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
    collision?: CollisionResolutionCombination | Record<string, any> | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    of?: any | string;
    offset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
}>;
declare const Position: ((props: IPositionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    boundary?: any | string;
    boundaryOffset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    collision?: Record<string, any> | CollisionResolutionCombination | {
        x?: CollisionResolution | undefined;
        y?: CollisionResolution | undefined;
    } | undefined;
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    of?: any | string;
    offset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShowProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Show: ((props: IShowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const To: ((props: IToProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Toast;
export { Toast, IToastOptions, ToastRef, Animation, IAnimationProps, At, IAtProps, BoundaryOffset, IBoundaryOffsetProps, Collision, ICollisionProps, From, IFromProps, Hide, IHideProps, My, IMyProps, Offset, IOffsetProps, Position, IPositionProps, Show, IShowProps, To, IToProps };
import type * as ToastTypes from 'devextreme/ui/toast_types';
export { ToastTypes };
