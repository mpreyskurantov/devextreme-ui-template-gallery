/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxValidator, { Properties } from "devextreme/ui/validator";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { DisposingEvent, InitializedEvent, ValidatedEvent } from "devextreme/ui/validator";
import type { ValidationRuleType, ComparisonOperator } from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IValidatorOptionsNarrowedEvents = {
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onValidated?: ((validatedInfo: ValidatedEvent) => void);
};
type IValidatorOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IValidatorOptionsNarrowedEvents> & IHtmlOptions>;
interface ValidatorRef {
    instance: () => dxValidator;
}
declare const Validator: ((props: React.PropsWithChildren<IValidatorOptions> & {
    ref?: Ref<ValidatorRef>;
}) => ReactElement | null) & NestedComponentMeta;
type IAdapterProps = React.PropsWithChildren<{
    applyValidationResults?: (() => void);
    bypass?: (() => void);
    focus?: (() => void);
    getValue?: (() => void);
    reset?: (() => void);
    validationRequestsCallbacks?: Array<(() => void)>;
}>;
declare const Adapter: ((props: IAdapterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    applyValidationResults?: (() => void) | undefined;
    bypass?: (() => void) | undefined;
    focus?: (() => void) | undefined;
    getValue?: (() => void) | undefined;
    reset?: (() => void) | undefined;
    validationRequestsCallbacks?: (() => void)[] | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAsyncRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any);
}>;
declare const AsyncRule: ((props: IAsyncRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICompareRuleProps = React.PropsWithChildren<{
    comparisonTarget?: (() => any);
    comparisonType?: ComparisonOperator;
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const CompareRule: ((props: ICompareRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    comparisonTarget?: (() => any) | undefined;
    comparisonType?: ComparisonOperator | undefined;
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICustomRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
}>;
declare const CustomRule: ((props: ICustomRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEmailRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const EmailRule: ((props: IEmailRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type INumericRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const NumericRule: ((props: INumericRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPatternRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    pattern?: RegExp | string;
    type?: ValidationRuleType;
}>;
declare const PatternRule: ((props: IPatternRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    pattern?: string | RegExp | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRangeRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    max?: Date | number | string;
    message?: string;
    min?: Date | number | string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
}>;
declare const RangeRule: ((props: IRangeRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    max?: string | number | Date | undefined;
    message?: string | undefined;
    min?: string | number | Date | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRequiredRuleProps = React.PropsWithChildren<{
    message?: string;
    trim?: boolean;
    type?: ValidationRuleType;
}>;
declare const RequiredRule: ((props: IRequiredRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    message?: string | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStringLengthRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    max?: number;
    message?: string;
    min?: number;
    trim?: boolean;
    type?: ValidationRuleType;
}>;
declare const StringLengthRule: ((props: IStringLengthRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    max?: number | undefined;
    message?: string | undefined;
    min?: number | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValidationRuleProps = React.PropsWithChildren<{
    message?: string;
    trim?: boolean;
    type?: ValidationRuleType;
    ignoreEmptyValue?: boolean;
    max?: Date | number | string;
    min?: Date | number | string;
    reevaluate?: boolean;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    comparisonTarget?: (() => any);
    comparisonType?: ComparisonOperator;
    pattern?: RegExp | string;
}>;
declare const ValidationRule: ((props: IValidationRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    message?: string | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    ignoreEmptyValue?: boolean | undefined;
    max?: string | number | Date | undefined;
    min?: string | number | Date | undefined;
    reevaluate?: boolean | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean) | undefined;
    comparisonTarget?: (() => any) | undefined;
    comparisonType?: ComparisonOperator | undefined;
    pattern?: string | RegExp | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Validator;
export { Validator, IValidatorOptions, ValidatorRef, Adapter, IAdapterProps, AsyncRule, IAsyncRuleProps, CompareRule, ICompareRuleProps, CustomRule, ICustomRuleProps, EmailRule, IEmailRuleProps, NumericRule, INumericRuleProps, PatternRule, IPatternRuleProps, RangeRule, IRangeRuleProps, RequiredRule, IRequiredRuleProps, StringLengthRule, IStringLengthRuleProps, ValidationRule, IValidationRuleProps };
import type * as ValidatorTypes from 'devextreme/ui/validator_types';
export { ValidatorTypes };
