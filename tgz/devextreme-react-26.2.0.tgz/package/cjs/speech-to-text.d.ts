/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxSpeechToText, { Properties } from "devextreme/ui/speech_to_text";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ContentReadyEvent, DisposingEvent, EndEvent, ErrorEvent, InitializedEvent, ResultEvent, StartClickEvent, StopClickEvent } from "devextreme/ui/speech_to_text";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ISpeechToTextOptionsNarrowedEvents = {
    onContentReady?: ((e: ContentReadyEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onEnd?: ((e: EndEvent) => void) | undefined;
    onError?: ((e: ErrorEvent) => void) | undefined;
    onInitialized?: ((e: InitializedEvent) => void);
    onResult?: ((e: ResultEvent) => void) | undefined;
    onStartClick?: ((e: StartClickEvent) => void) | undefined;
    onStopClick?: ((e: StopClickEvent) => void) | undefined;
};
type ISpeechToTextOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, ISpeechToTextOptionsNarrowedEvents> & IHtmlOptions>;
interface SpeechToTextRef {
    instance: () => dxSpeechToText;
}
declare const SpeechToText: (props: React.PropsWithChildren<ISpeechToTextOptions> & {
    ref?: Ref<SpeechToTextRef>;
}) => ReactElement | null;
type ICustomSpeechRecognizerProps = React.PropsWithChildren<{
    enabled?: boolean;
    isListening?: boolean;
}>;
declare const CustomSpeechRecognizer: ((props: ICustomSpeechRecognizerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | undefined;
    isListening?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISpeechRecognitionConfigProps = React.PropsWithChildren<{
    continuous?: boolean;
    grammars?: Array<string>;
    interimResults?: boolean;
    lang?: string;
    maxAlternatives?: number;
}>;
declare const SpeechRecognitionConfig: ((props: ISpeechRecognitionConfigProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    continuous?: boolean | undefined;
    grammars?: string[] | undefined;
    interimResults?: boolean | undefined;
    lang?: string | undefined;
    maxAlternatives?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default SpeechToText;
export { SpeechToText, ISpeechToTextOptions, SpeechToTextRef, CustomSpeechRecognizer, ICustomSpeechRecognizerProps, SpeechRecognitionConfig, ISpeechRecognitionConfigProps };
import type * as SpeechToTextTypes from 'devextreme/ui/speech_to_text_types';
export { SpeechToTextTypes };
