/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxSortable, { Properties } from "devextreme/ui/sortable";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { AddEvent, DisposingEvent, DragChangeEvent, DragEndEvent, DragMoveEvent, DragStartEvent, InitializedEvent, RemoveEvent, ReorderEvent } from "devextreme/ui/sortable";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ISortableOptionsNarrowedEvents = {
    onAdd?: ((e: AddEvent) => void) | undefined;
    onDisposing?: ((e: DisposingEvent) => void);
    onDragChange?: ((e: DragChangeEvent) => void) | undefined;
    onDragEnd?: ((e: DragEndEvent) => void) | undefined;
    onDragMove?: ((e: DragMoveEvent) => void) | undefined;
    onDragStart?: ((e: DragStartEvent) => void) | undefined;
    onInitialized?: ((e: InitializedEvent) => void);
    onRemove?: ((e: RemoveEvent) => void) | undefined;
    onReorder?: ((e: ReorderEvent) => void) | undefined;
};
type ISortableOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, ISortableOptionsNarrowedEvents> & IHtmlOptions & {
    dragRender?: (...params: any) => React.ReactNode;
    dragComponent?: React.ComponentType<any>;
}>;
interface SortableRef {
    instance: () => dxSortable;
}
declare const Sortable: (props: React.PropsWithChildren<ISortableOptions> & {
    ref?: Ref<SortableRef>;
}) => ReactElement | null;
type ICursorOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const CursorOffset: ((props: ICursorOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Sortable;
export { Sortable, ISortableOptions, SortableRef, CursorOffset, ICursorOffsetProps };
import type * as SortableTypes from 'devextreme/ui/sortable_types';
export { SortableTypes };
