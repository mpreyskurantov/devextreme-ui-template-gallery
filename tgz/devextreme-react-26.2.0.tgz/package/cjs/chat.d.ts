/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxChat, { Properties } from "devextreme/ui/chat";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { Message, AttachmentDownloadClickEvent, DisposingEvent, InitializedEvent, MessageDeletedEvent, MessageDeletingEvent, MessageEditCanceledEvent, MessageEditingStartEvent, MessageEnteredEvent, MessageUpdatedEvent, MessageUpdatingEvent, TypingEndEvent, TypingStartEvent, Attachment as ChatAttachment, User as ChatUser, MessageType, SendButtonAction, SendButtonClickEvent } from "devextreme/ui/chat";
import type { DisposingEvent as FileUploaderDisposingEvent, InitializedEvent as FileUploaderInitializedEvent, BeforeSendEvent, ContentReadyEvent, DropZoneEnterEvent, DropZoneLeaveEvent, FilesUploadedEvent, OptionChangedEvent, ProgressEvent, UploadAbortedEvent, UploadedEvent, UploadErrorEvent, UploadStartedEvent, ValueChangedEvent, UploadHttpMethod, FileUploadMode } from "devextreme/ui/file_uploader";
import type { DisposingEvent as SpeechToTextDisposingEvent, InitializedEvent as SpeechToTextInitializedEvent, ContentReadyEvent as SpeechToTextContentReadyEvent, OptionChangedEvent as SpeechToTextOptionChangedEvent, CustomSpeechRecognizer as SpeechToTextCustomSpeechRecognizer, EndEvent, ErrorEvent, ResultEvent, StartClickEvent, StopClickEvent, SpeechRecognitionConfig as SpeechToTextSpeechRecognitionConfig } from "devextreme/ui/speech_to_text";
import type { DisposingEvent as ButtonGroupDisposingEvent, InitializedEvent as ButtonGroupInitializedEvent, ContentReadyEvent as ButtonGroupContentReadyEvent, OptionChangedEvent as ButtonGroupOptionChangedEvent, dxButtonGroupItem, ItemClickEvent, SelectionChangedEvent } from "devextreme/ui/button_group";
import type { Format, ValidationStatus, ButtonType, template, ButtonStyle, SingleMultipleOrNone } from "devextreme/common";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
import type UploadInfo from "devextreme/file_management/upload_info";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IChatOptionsNarrowedEvents = {
    onAttachmentDownloadClick?: ((e: AttachmentDownloadClickEvent) => void) | undefined;
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onMessageDeleted?: ((e: MessageDeletedEvent) => void) | undefined;
    onMessageDeleting?: ((e: MessageDeletingEvent) => void) | undefined;
    onMessageEditCanceled?: ((e: MessageEditCanceledEvent) => void) | undefined;
    onMessageEditingStart?: ((e: MessageEditingStartEvent) => void) | undefined;
    onMessageEntered?: ((e: MessageEnteredEvent) => void) | undefined;
    onMessageUpdated?: ((e: MessageUpdatedEvent) => void) | undefined;
    onMessageUpdating?: ((e: MessageUpdatingEvent) => void) | undefined;
    onTypingEnd?: ((e: TypingEndEvent) => void) | undefined;
    onTypingStart?: ((e: TypingStartEvent) => void) | undefined;
};
type IChatOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IChatOptionsNarrowedEvents> & IHtmlOptions & {
    emptyViewRender?: (...params: any) => React.ReactNode;
    emptyViewComponent?: React.ComponentType<any>;
    messageRender?: (...params: any) => React.ReactNode;
    messageComponent?: React.ComponentType<any>;
    defaultItems?: Array<Message>;
    onItemsChange?: (value: Array<Message>) => void;
}>;
interface ChatRef {
    instance: () => dxChat;
}
declare const Chat: (props: React.PropsWithChildren<IChatOptions> & {
    ref?: Ref<ChatRef>;
}) => ReactElement | null;
type IAlertProps = React.PropsWithChildren<{
    id?: number | string;
    message?: string;
}>;
declare const Alert: ((props: IAlertProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    id?: string | number | undefined;
    message?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAttachmentProps = React.PropsWithChildren<{
    name?: string;
    size?: number;
}>;
declare const Attachment: ((props: IAttachmentProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    name?: string | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAuthorProps = React.PropsWithChildren<{
    avatarAlt?: string;
    avatarUrl?: string;
    id?: number | string;
    name?: string;
}>;
declare const Author: ((props: IAuthorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    avatarAlt?: string | undefined;
    avatarUrl?: string | undefined;
    id?: string | number | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IChatItemProps = React.PropsWithChildren<{
    alt?: string;
    attachments?: Array<ChatAttachment>;
    author?: ChatUser;
    id?: number | string;
    isDeleted?: boolean;
    isEdited?: boolean;
    src?: string;
    text?: string;
    timestamp?: Date | number | string;
    type?: MessageType;
}>;
declare const ChatItem: ((props: IChatItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alt?: string | undefined;
    attachments?: ChatAttachment[] | undefined;
    author?: ChatUser | undefined;
    id?: string | number | undefined;
    isDeleted?: boolean | undefined;
    isEdited?: boolean | undefined;
    src?: string | undefined;
    text?: string | undefined;
    timestamp?: string | number | Date | undefined;
    type?: MessageType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICustomSpeechRecognizerProps = React.PropsWithChildren<{
    enabled?: boolean;
    isListening?: boolean;
}>;
declare const CustomSpeechRecognizer: ((props: ICustomSpeechRecognizerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | undefined;
    isListening?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDayHeaderFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: Format | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const DayHeaderFormat: ((props: IDayHeaderFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEditingProps = React.PropsWithChildren<{
    allowDeleting?: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean);
    allowUpdating?: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean);
}>;
declare const Editing: ((props: IEditingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDeleting?: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean) | undefined;
    allowUpdating?: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFileUploaderOptionsProps = React.PropsWithChildren<{
    abortUpload?: ((file: any, uploadInfo?: UploadInfo) => any);
    accept?: string;
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    allowCanceling?: boolean;
    allowedFileExtensions?: Array<string>;
    chunkSize?: number;
    dialogTrigger?: any | string | undefined;
    disabled?: boolean;
    dropZone?: any | string | undefined;
    elementAttr?: Record<string, any>;
    focusStateEnabled?: boolean;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    inputAttr?: any;
    invalidFileExtensionMessage?: string;
    invalidMaxFileSizeMessage?: string;
    invalidMinFileSizeMessage?: string;
    isDirty?: boolean;
    isValid?: boolean;
    labelText?: string;
    maxFileSize?: number;
    minFileSize?: number;
    multiple?: boolean;
    name?: string;
    onBeforeSend?: ((e: BeforeSendEvent) => void) | undefined;
    onContentReady?: ((e: ContentReadyEvent) => void);
    onDisposing?: ((e: FileUploaderDisposingEvent) => void);
    onDropZoneEnter?: ((e: DropZoneEnterEvent) => void) | undefined;
    onDropZoneLeave?: ((e: DropZoneLeaveEvent) => void) | undefined;
    onFilesUploaded?: ((e: FilesUploadedEvent) => void) | undefined;
    onInitialized?: ((e: FileUploaderInitializedEvent) => void);
    onOptionChanged?: ((e: OptionChangedEvent) => void);
    onProgress?: ((e: ProgressEvent) => void) | undefined;
    onUploadAborted?: ((e: UploadAbortedEvent) => void) | undefined;
    onUploaded?: ((e: UploadedEvent) => void) | undefined;
    onUploadError?: ((e: UploadErrorEvent) => void) | undefined;
    onUploadStarted?: ((e: UploadStartedEvent) => void) | undefined;
    onValueChanged?: ((e: ValueChangedEvent) => void) | undefined;
    progress?: number;
    readOnly?: boolean;
    readyToUploadMessage?: string;
    rtlEnabled?: boolean;
    selectButtonText?: string;
    showFileList?: boolean;
    tabIndex?: number;
    uploadAbortedMessage?: string;
    uploadButtonText?: string;
    uploadChunk?: ((file: any, uploadInfo: UploadInfo) => any);
    uploadCustomData?: any;
    uploadedMessage?: string;
    uploadFailedMessage?: string;
    uploadFile?: ((file: any, progressCallback: (() => void)) => any);
    uploadHeaders?: any;
    uploadMethod?: UploadHttpMethod;
    uploadMode?: FileUploadMode;
    uploadUrl?: string;
    validationError?: any | null;
    validationErrors?: Array<any> | null;
    validationStatus?: ValidationStatus;
    value?: Array<any>;
    visible?: boolean;
    width?: number | string | undefined;
    defaultValue?: Array<any>;
    onValueChange?: (value: Array<any>) => void;
}>;
declare const FileUploaderOptions: ((props: IFileUploaderOptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    abortUpload?: ((file: any, uploadInfo?: UploadInfo) => any) | undefined;
    accept?: string | undefined;
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    allowCanceling?: boolean | undefined;
    allowedFileExtensions?: string[] | undefined;
    chunkSize?: number | undefined;
    dialogTrigger?: any | string | undefined;
    disabled?: boolean | undefined;
    dropZone?: any | string | undefined;
    elementAttr?: Record<string, any> | undefined;
    focusStateEnabled?: boolean | undefined;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    inputAttr?: any;
    invalidFileExtensionMessage?: string | undefined;
    invalidMaxFileSizeMessage?: string | undefined;
    invalidMinFileSizeMessage?: string | undefined;
    isDirty?: boolean | undefined;
    isValid?: boolean | undefined;
    labelText?: string | undefined;
    maxFileSize?: number | undefined;
    minFileSize?: number | undefined;
    multiple?: boolean | undefined;
    name?: string | undefined;
    onBeforeSend?: ((e: BeforeSendEvent) => void) | undefined;
    onContentReady?: ((e: ContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: FileUploaderDisposingEvent) => void) | undefined;
    onDropZoneEnter?: ((e: DropZoneEnterEvent) => void) | undefined;
    onDropZoneLeave?: ((e: DropZoneLeaveEvent) => void) | undefined;
    onFilesUploaded?: ((e: FilesUploadedEvent) => void) | undefined;
    onInitialized?: ((e: FileUploaderInitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: OptionChangedEvent) => void) | undefined;
    onProgress?: ((e: ProgressEvent) => void) | undefined;
    onUploadAborted?: ((e: UploadAbortedEvent) => void) | undefined;
    onUploaded?: ((e: UploadedEvent) => void) | undefined;
    onUploadError?: ((e: UploadErrorEvent) => void) | undefined;
    onUploadStarted?: ((e: UploadStartedEvent) => void) | undefined;
    onValueChanged?: ((e: ValueChangedEvent) => void) | undefined;
    progress?: number | undefined;
    readOnly?: boolean | undefined;
    readyToUploadMessage?: string | undefined;
    rtlEnabled?: boolean | undefined;
    selectButtonText?: string | undefined;
    showFileList?: boolean | undefined;
    tabIndex?: number | undefined;
    uploadAbortedMessage?: string | undefined;
    uploadButtonText?: string | undefined;
    uploadChunk?: ((file: any, uploadInfo: UploadInfo) => any) | undefined;
    uploadCustomData?: any;
    uploadedMessage?: string | undefined;
    uploadFailedMessage?: string | undefined;
    uploadFile?: ((file: any, progressCallback: (() => void)) => any) | undefined;
    uploadHeaders?: any;
    uploadMethod?: UploadHttpMethod | undefined;
    uploadMode?: FileUploadMode | undefined;
    uploadUrl?: string | undefined;
    validationError?: any | null;
    validationErrors?: any[] | null | undefined;
    validationStatus?: ValidationStatus | undefined;
    value?: any[] | undefined;
    visible?: boolean | undefined;
    width?: number | string | undefined;
    defaultValue?: any[] | undefined;
    onValueChange?: ((value: Array<any>) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    alt?: string;
    attachments?: Array<ChatAttachment>;
    author?: ChatUser;
    id?: number | string;
    isDeleted?: boolean;
    isEdited?: boolean;
    src?: string;
    text?: string;
    timestamp?: Date | number | string;
    type?: MessageType | ButtonType | string;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    hint?: string;
    icon?: string;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alt?: string | undefined;
    attachments?: ChatAttachment[] | undefined;
    author?: ChatUser | undefined;
    id?: string | number | undefined;
    isDeleted?: boolean | undefined;
    isEdited?: boolean | undefined;
    src?: string | undefined;
    text?: string | undefined;
    timestamp?: string | number | Date | undefined;
    type?: string | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    hint?: string | undefined;
    icon?: string | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMessageTimestampFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: Format | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const MessageTimestampFormat: ((props: IMessageTimestampFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISendButtonOptionsProps = React.PropsWithChildren<{
    action?: SendButtonAction;
    icon?: string;
    onClick?: ((e: SendButtonClickEvent) => void);
}>;
declare const SendButtonOptions: ((props: ISendButtonOptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    action?: SendButtonAction | undefined;
    icon?: string | undefined;
    onClick?: ((e: SendButtonClickEvent) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISpeechRecognitionConfigProps = React.PropsWithChildren<{
    continuous?: boolean;
    grammars?: Array<string>;
    interimResults?: boolean;
    lang?: string;
    maxAlternatives?: number;
}>;
declare const SpeechRecognitionConfig: ((props: ISpeechRecognitionConfigProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    continuous?: boolean | undefined;
    grammars?: string[] | undefined;
    interimResults?: boolean | undefined;
    lang?: string | undefined;
    maxAlternatives?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISpeechToTextOptionsProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    customSpeechRecognizer?: SpeechToTextCustomSpeechRecognizer;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    focusStateEnabled?: boolean;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    onContentReady?: ((e: SpeechToTextContentReadyEvent) => void);
    onDisposing?: ((e: SpeechToTextDisposingEvent) => void);
    onEnd?: ((e: EndEvent) => void) | undefined;
    onError?: ((e: ErrorEvent) => void) | undefined;
    onInitialized?: ((e: SpeechToTextInitializedEvent) => void);
    onOptionChanged?: ((e: SpeechToTextOptionChangedEvent) => void);
    onResult?: ((e: ResultEvent) => void) | undefined;
    onStartClick?: ((e: StartClickEvent) => void) | undefined;
    onStopClick?: ((e: StopClickEvent) => void) | undefined;
    rtlEnabled?: boolean;
    speechRecognitionConfig?: Record<string, any> | SpeechToTextSpeechRecognitionConfig;
    startIcon?: string;
    startText?: string;
    stopIcon?: string;
    stopText?: string;
    stylingMode?: ButtonStyle;
    tabIndex?: number;
    type?: ButtonType | string;
    visible?: boolean;
    width?: number | string | undefined;
}>;
declare const SpeechToTextOptions: ((props: ISpeechToTextOptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    customSpeechRecognizer?: SpeechToTextCustomSpeechRecognizer | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    focusStateEnabled?: boolean | undefined;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    onContentReady?: ((e: SpeechToTextContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: SpeechToTextDisposingEvent) => void) | undefined;
    onEnd?: ((e: EndEvent) => void) | undefined;
    onError?: ((e: ErrorEvent) => void) | undefined;
    onInitialized?: ((e: SpeechToTextInitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: SpeechToTextOptionChangedEvent) => void) | undefined;
    onResult?: ((e: ResultEvent) => void) | undefined;
    onStartClick?: ((e: StartClickEvent) => void) | undefined;
    onStopClick?: ((e: StopClickEvent) => void) | undefined;
    rtlEnabled?: boolean | undefined;
    speechRecognitionConfig?: Record<string, any> | SpeechToTextSpeechRecognitionConfig | undefined;
    startIcon?: string | undefined;
    startText?: string | undefined;
    stopIcon?: string | undefined;
    stopText?: string | undefined;
    stylingMode?: ButtonStyle | undefined;
    tabIndex?: number | undefined;
    type?: string | undefined;
    visible?: boolean | undefined;
    width?: number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISuggestionsProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    buttonTemplate?: ((buttonData: any, buttonContent: any) => string | any) | template;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    focusStateEnabled?: boolean;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    items?: Array<dxButtonGroupItem>;
    keyExpr?: ((item: any) => any) | string;
    onContentReady?: ((e: ButtonGroupContentReadyEvent) => void);
    onDisposing?: ((e: ButtonGroupDisposingEvent) => void);
    onInitialized?: ((e: ButtonGroupInitializedEvent) => void);
    onItemClick?: ((e: ItemClickEvent) => void) | undefined;
    onOptionChanged?: ((e: ButtonGroupOptionChangedEvent) => void);
    onSelectionChanged?: ((e: SelectionChangedEvent) => void) | undefined;
    rtlEnabled?: boolean;
    selectedItemKeys?: Array<any>;
    selectedItems?: Array<any>;
    selectionMode?: SingleMultipleOrNone;
    stylingMode?: ButtonStyle;
    tabIndex?: number;
    visible?: boolean;
    width?: number | string | undefined;
    defaultSelectedItemKeys?: Array<any>;
    onSelectedItemKeysChange?: (value: Array<any>) => void;
    defaultSelectedItems?: Array<any>;
    onSelectedItemsChange?: (value: Array<any>) => void;
    buttonRender?: (...params: any) => React.ReactNode;
    buttonComponent?: React.ComponentType<any>;
}>;
declare const Suggestions: ((props: ISuggestionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    buttonTemplate?: template | ((buttonData: any, buttonContent: any) => string | any) | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    focusStateEnabled?: boolean | undefined;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    items?: dxButtonGroupItem[] | undefined;
    keyExpr?: string | ((item: any) => any) | undefined;
    onContentReady?: ((e: ButtonGroupContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: ButtonGroupDisposingEvent) => void) | undefined;
    onInitialized?: ((e: ButtonGroupInitializedEvent) => void) | undefined;
    onItemClick?: ((e: ItemClickEvent) => void) | undefined;
    onOptionChanged?: ((e: ButtonGroupOptionChangedEvent) => void) | undefined;
    onSelectionChanged?: ((e: SelectionChangedEvent) => void) | undefined;
    rtlEnabled?: boolean | undefined;
    selectedItemKeys?: any[] | undefined;
    selectedItems?: any[] | undefined;
    selectionMode?: SingleMultipleOrNone | undefined;
    stylingMode?: ButtonStyle | undefined;
    tabIndex?: number | undefined;
    visible?: boolean | undefined;
    width?: number | string | undefined;
    defaultSelectedItemKeys?: any[] | undefined;
    onSelectedItemKeysChange?: ((value: Array<any>) => void) | undefined;
    defaultSelectedItems?: any[] | undefined;
    onSelectedItemsChange?: ((value: Array<any>) => void) | undefined;
    buttonRender?: ((...params: any) => React.ReactNode) | undefined;
    buttonComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISuggestionsItemProps = React.PropsWithChildren<{
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    hint?: string;
    icon?: string;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    type?: ButtonType | string;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const SuggestionsItem: ((props: ISuggestionsItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    hint?: string | undefined;
    icon?: string | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    type?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITypingUserProps = React.PropsWithChildren<{
    avatarAlt?: string;
    avatarUrl?: string;
    id?: number | string;
    name?: string;
}>;
declare const TypingUser: ((props: ITypingUserProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    avatarAlt?: string | undefined;
    avatarUrl?: string | undefined;
    id?: string | number | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IUserProps = React.PropsWithChildren<{
    avatarAlt?: string;
    avatarUrl?: string;
    id?: number | string;
    name?: string;
}>;
declare const User: ((props: IUserProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    avatarAlt?: string | undefined;
    avatarUrl?: string | undefined;
    id?: string | number | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Chat;
export { Chat, IChatOptions, ChatRef, Alert, IAlertProps, Attachment, IAttachmentProps, Author, IAuthorProps, ChatItem, IChatItemProps, CustomSpeechRecognizer, ICustomSpeechRecognizerProps, DayHeaderFormat, IDayHeaderFormatProps, Editing, IEditingProps, FileUploaderOptions, IFileUploaderOptionsProps, Item, IItemProps, MessageTimestampFormat, IMessageTimestampFormatProps, SendButtonOptions, ISendButtonOptionsProps, SpeechRecognitionConfig, ISpeechRecognitionConfigProps, SpeechToTextOptions, ISpeechToTextOptionsProps, Suggestions, ISuggestionsProps, SuggestionsItem, ISuggestionsItemProps, TypingUser, ITypingUserProps, User, IUserProps };
import type * as ChatTypes from 'devextreme/ui/chat_types';
export { ChatTypes };
