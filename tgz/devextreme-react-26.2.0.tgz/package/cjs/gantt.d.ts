/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxGantt, { Properties } from "devextreme/ui/gantt";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ContentReadyEvent, ContextMenuPreparingEvent, CustomCommandEvent, DependencyDeletedEvent, DependencyDeletingEvent, DependencyInsertedEvent, DependencyInsertingEvent, DisposingEvent, InitializedEvent, ResourceAssignedEvent, ResourceAssigningEvent, ResourceDeletedEvent, ResourceDeletingEvent, ResourceInsertedEvent, ResourceInsertingEvent, ResourceManagerDialogShowingEvent, ResourceUnassignedEvent, ResourceUnassigningEvent, ScaleCellPreparedEvent, TaskClickEvent, TaskDblClickEvent, TaskDeletedEvent, TaskDeletingEvent, TaskEditDialogShowingEvent, TaskInsertedEvent, TaskInsertingEvent, TaskMovingEvent, TaskUpdatedEvent, TaskUpdatingEvent, dxGanttContextMenuItem, GanttPredefinedContextMenuItem, dxGanttFilterRowOperationDescriptions, dxGanttHeaderFilterTexts, GanttPredefinedToolbarItem, GanttScaleType, dxGanttToolbarItem } from "devextreme/ui/gantt";
import type { HorizontalAlignment, template, DataType, Format as CommonFormat, SortOrder, SearchMode, ToolbarItemLocation, ToolbarItemComponent, SingleMultipleOrNone } from "devextreme/common";
import type { dxTreeListColumn, dxTreeListRowObject } from "devextreme/ui/tree_list";
import type { FilterOperation, FilterType, ColumnHeaderFilter as GridsColumnHeaderFilter, SelectedFilterOperation, HeaderFilterGroupInterval, ColumnHeaderFilterSearchConfig, HeaderFilterSearchConfig } from "devextreme/common/grids";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
import type { DataSourceOptions } from "devextreme/data/data_source";
import type { Store } from "devextreme/data/store";
import type { dxContextMenuItem } from "devextreme/ui/context_menu";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
import type { LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
import type dxTreeList from "devextreme/ui/tree_list";
import type DataSource from "devextreme/data/data_source";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IGanttOptionsNarrowedEvents = {
    onContentReady?: ((e: ContentReadyEvent) => void);
    onContextMenuPreparing?: ((e: ContextMenuPreparingEvent) => void) | undefined;
    onCustomCommand?: ((e: CustomCommandEvent) => void) | undefined;
    onDependencyDeleted?: ((e: DependencyDeletedEvent) => void) | undefined;
    onDependencyDeleting?: ((e: DependencyDeletingEvent) => void) | undefined;
    onDependencyInserted?: ((e: DependencyInsertedEvent) => void) | undefined;
    onDependencyInserting?: ((e: DependencyInsertingEvent) => void) | undefined;
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onResourceAssigned?: ((e: ResourceAssignedEvent) => void) | undefined;
    onResourceAssigning?: ((e: ResourceAssigningEvent) => void) | undefined;
    onResourceDeleted?: ((e: ResourceDeletedEvent) => void) | undefined;
    onResourceDeleting?: ((e: ResourceDeletingEvent) => void) | undefined;
    onResourceInserted?: ((e: ResourceInsertedEvent) => void) | undefined;
    onResourceInserting?: ((e: ResourceInsertingEvent) => void) | undefined;
    onResourceManagerDialogShowing?: ((e: ResourceManagerDialogShowingEvent) => void) | undefined;
    onResourceUnassigned?: ((e: ResourceUnassignedEvent) => void) | undefined;
    onResourceUnassigning?: ((e: ResourceUnassigningEvent) => void) | undefined;
    onScaleCellPrepared?: ((e: ScaleCellPreparedEvent) => void) | undefined;
    onTaskClick?: ((e: TaskClickEvent) => void) | undefined;
    onTaskDblClick?: ((e: TaskDblClickEvent) => void) | undefined;
    onTaskDeleted?: ((e: TaskDeletedEvent) => void) | undefined;
    onTaskDeleting?: ((e: TaskDeletingEvent) => void) | undefined;
    onTaskEditDialogShowing?: ((e: TaskEditDialogShowingEvent) => void) | undefined;
    onTaskInserted?: ((e: TaskInsertedEvent) => void) | undefined;
    onTaskInserting?: ((e: TaskInsertingEvent) => void) | undefined;
    onTaskMoving?: ((e: TaskMovingEvent) => void) | undefined;
    onTaskUpdated?: ((e: TaskUpdatedEvent) => void) | undefined;
    onTaskUpdating?: ((e: TaskUpdatingEvent) => void) | undefined;
};
type IGanttOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IGanttOptionsNarrowedEvents> & IHtmlOptions & {
    taskContentRender?: (...params: any) => React.ReactNode;
    taskContentComponent?: React.ComponentType<any>;
    taskProgressTooltipContentRender?: (...params: any) => React.ReactNode;
    taskProgressTooltipContentComponent?: React.ComponentType<any>;
    taskTimeTooltipContentRender?: (...params: any) => React.ReactNode;
    taskTimeTooltipContentComponent?: React.ComponentType<any>;
    taskTooltipContentRender?: (...params: any) => React.ReactNode;
    taskTooltipContentComponent?: React.ComponentType<any>;
}>;
interface GanttRef {
    instance: () => dxGantt;
}
declare const Gantt: (props: React.PropsWithChildren<IGanttOptions> & {
    ref?: Ref<GanttRef>;
}) => ReactElement | null;
type IColumnProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    allowFiltering?: boolean;
    allowHeaderFiltering?: boolean;
    allowSorting?: boolean;
    calculateCellValue?: ((rowData: any) => any);
    calculateDisplayValue?: ((rowData: any) => any) | string;
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | (() => any) | Array<any>);
    calculateSortValue?: ((rowData: any) => any) | string;
    caption?: string | undefined;
    cellTemplate?: ((cellElement: any, cellInfo: {
        column: dxTreeListColumn;
        columnIndex: number;
        component: dxTreeList;
        data: Record<string, any>;
        displayValue: any;
        oldValue: any;
        row: dxTreeListRowObject;
        rowIndex: number;
        rowType: string;
        text: string;
        value: any;
        watch: (() => void);
    }) => any) | template;
    cssClass?: string | undefined;
    customizeText?: ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string);
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    encodeHtml?: boolean;
    falseText?: string;
    filterOperations?: Array<FilterOperation | string>;
    filterType?: FilterType;
    filterValue?: any | undefined;
    filterValues?: Array<any>;
    format?: LocalizationFormat;
    headerCellTemplate?: ((columnHeader: any, headerInfo: {
        column: dxTreeListColumn;
        columnIndex: number;
        component: dxTreeList;
    }) => any) | template;
    headerFilter?: GridsColumnHeaderFilter | undefined;
    minWidth?: number | undefined;
    selectedFilterOperation?: SelectedFilterOperation | undefined;
    sortIndex?: number | undefined;
    sortingMethod?: ((value1: any, value2: any) => number) | undefined;
    sortOrder?: SortOrder | undefined;
    trueText?: string;
    visible?: boolean;
    visibleIndex?: number | undefined;
    width?: number | string | undefined;
    defaultFilterValue?: any | undefined;
    onFilterValueChange?: (value: any | undefined) => void;
    defaultFilterValues?: Array<any>;
    onFilterValuesChange?: (value: Array<any>) => void;
    defaultSelectedFilterOperation?: SelectedFilterOperation | undefined;
    onSelectedFilterOperationChange?: (value: SelectedFilterOperation | undefined) => void;
    defaultSortIndex?: number | undefined;
    onSortIndexChange?: (value: number | undefined) => void;
    defaultSortOrder?: SortOrder | undefined;
    onSortOrderChange?: (value: SortOrder | undefined) => void;
    defaultVisible?: boolean;
    onVisibleChange?: (value: boolean) => void;
    defaultVisibleIndex?: number | undefined;
    onVisibleIndexChange?: (value: number | undefined) => void;
    cellRender?: (...params: any) => React.ReactNode;
    cellComponent?: React.ComponentType<any>;
    headerCellRender?: (...params: any) => React.ReactNode;
    headerCellComponent?: React.ComponentType<any>;
}>;
declare const Column: ((props: IColumnProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    allowFiltering?: boolean | undefined;
    allowHeaderFiltering?: boolean | undefined;
    allowSorting?: boolean | undefined;
    calculateCellValue?: ((rowData: any) => any) | undefined;
    calculateDisplayValue?: string | ((rowData: any) => any) | undefined;
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | (() => any) | Array<any>) | undefined;
    calculateSortValue?: string | ((rowData: any) => any) | undefined;
    caption?: string | undefined;
    cellTemplate?: template | ((cellElement: any, cellInfo: {
        column: dxTreeListColumn;
        columnIndex: number;
        component: dxTreeList;
        data: Record<string, any>;
        displayValue: any;
        oldValue: any;
        row: dxTreeListRowObject;
        rowIndex: number;
        rowType: string;
        text: string;
        value: any;
        watch: (() => void);
    }) => any) | undefined;
    cssClass?: string | undefined;
    customizeText?: ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string) | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    encodeHtml?: boolean | undefined;
    falseText?: string | undefined;
    filterOperations?: string[] | undefined;
    filterType?: FilterType | undefined;
    filterValue?: any | undefined;
    filterValues?: any[] | undefined;
    format?: LocalizationFormat;
    headerCellTemplate?: template | ((columnHeader: any, headerInfo: {
        column: dxTreeListColumn;
        columnIndex: number;
        component: dxTreeList;
    }) => any) | undefined;
    headerFilter?: GridsColumnHeaderFilter | undefined;
    minWidth?: number | undefined;
    selectedFilterOperation?: SelectedFilterOperation | undefined;
    sortIndex?: number | undefined;
    sortingMethod?: ((value1: any, value2: any) => number) | undefined;
    sortOrder?: SortOrder | undefined;
    trueText?: string | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    width?: number | string | undefined;
    defaultFilterValue?: any | undefined;
    onFilterValueChange?: ((value: any | undefined) => void) | undefined;
    defaultFilterValues?: any[] | undefined;
    onFilterValuesChange?: ((value: Array<any>) => void) | undefined;
    defaultSelectedFilterOperation?: SelectedFilterOperation | undefined;
    onSelectedFilterOperationChange?: ((value: SelectedFilterOperation | undefined) => void) | undefined;
    defaultSortIndex?: number | undefined;
    onSortIndexChange?: ((value: number | undefined) => void) | undefined;
    defaultSortOrder?: SortOrder | undefined;
    onSortOrderChange?: ((value: SortOrder | undefined) => void) | undefined;
    defaultVisible?: boolean | undefined;
    onVisibleChange?: ((value: boolean) => void) | undefined;
    defaultVisibleIndex?: number | undefined;
    onVisibleIndexChange?: ((value: number | undefined) => void) | undefined;
    cellRender?: ((...params: any) => React.ReactNode) | undefined;
    cellComponent?: React.ComponentType<any> | undefined;
    headerCellRender?: ((...params: any) => React.ReactNode) | undefined;
    headerCellComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    dataSource?: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    groupInterval?: Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: ColumnHeaderFilterSearchConfig;
    searchMode?: SearchMode;
    width?: number | string | undefined;
}>;
declare const ColumnHeaderFilter: ((props: IColumnHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | undefined;
    groupInterval?: Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: ColumnHeaderFilterSearchConfig | undefined;
    searchMode?: SearchMode | undefined;
    width?: number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnHeaderFilterSearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number;
}>;
declare const ColumnHeaderFilterSearch: ((props: IColumnHeaderFilterSearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IContextMenuProps = React.PropsWithChildren<{
    enabled?: boolean;
    items?: Array<dxGanttContextMenuItem | GanttPredefinedContextMenuItem>;
}>;
declare const ContextMenu: ((props: IContextMenuProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | undefined;
    items?: (dxGanttContextMenuItem | GanttPredefinedContextMenuItem)[] | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IContextMenuItemProps = React.PropsWithChildren<{
    beginGroup?: boolean;
    closeMenuOnClick?: boolean;
    disabled?: boolean;
    icon?: string;
    items?: Array<dxContextMenuItem>;
    name?: GanttPredefinedContextMenuItem | string;
    selectable?: boolean;
    selected?: boolean;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const ContextMenuItem: ((props: IContextMenuItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    beginGroup?: boolean | undefined;
    closeMenuOnClick?: boolean | undefined;
    disabled?: boolean | undefined;
    icon?: string | undefined;
    items?: dxContextMenuItem[] | undefined;
    name?: string | undefined;
    selectable?: boolean | undefined;
    selected?: boolean | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IContextMenuItemItemProps = React.PropsWithChildren<{
    beginGroup?: boolean;
    closeMenuOnClick?: boolean;
    disabled?: boolean;
    icon?: string;
    items?: Array<dxContextMenuItem>;
    selectable?: boolean;
    selected?: boolean;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const ContextMenuItemItem: ((props: IContextMenuItemItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    beginGroup?: boolean | undefined;
    closeMenuOnClick?: boolean | undefined;
    disabled?: boolean | undefined;
    icon?: string | undefined;
    items?: dxContextMenuItem[] | undefined;
    selectable?: boolean | undefined;
    selected?: boolean | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDependenciesProps = React.PropsWithChildren<{
    dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
    keyExpr?: ((dependency: any) => any) | string;
    predecessorIdExpr?: ((dependency: any, value: any) => any) | string;
    successorIdExpr?: ((dependency: any, value: any) => any) | string;
    typeExpr?: ((dependency: any, value: any) => any) | string;
}>;
declare const Dependencies: ((props: IDependenciesProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    dataSource?: string | any[] | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null | undefined;
    keyExpr?: string | ((dependency: any) => any) | undefined;
    predecessorIdExpr?: string | ((dependency: any, value: any) => any) | undefined;
    successorIdExpr?: string | ((dependency: any, value: any) => any) | undefined;
    typeExpr?: string | ((dependency: any, value: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEditingProps = React.PropsWithChildren<{
    allowDependencyAdding?: boolean;
    allowDependencyDeleting?: boolean;
    allowResourceAdding?: boolean;
    allowResourceDeleting?: boolean;
    allowResourceUpdating?: boolean;
    allowTaskAdding?: boolean;
    allowTaskDeleting?: boolean;
    allowTaskResourceUpdating?: boolean;
    allowTaskUpdating?: boolean;
    enabled?: boolean;
}>;
declare const Editing: ((props: IEditingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDependencyAdding?: boolean | undefined;
    allowDependencyDeleting?: boolean | undefined;
    allowResourceAdding?: boolean | undefined;
    allowResourceDeleting?: boolean | undefined;
    allowResourceUpdating?: boolean | undefined;
    allowTaskAdding?: boolean | undefined;
    allowTaskDeleting?: boolean | undefined;
    allowTaskResourceUpdating?: boolean | undefined;
    allowTaskUpdating?: boolean | undefined;
    enabled?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterRowProps = React.PropsWithChildren<{
    betweenEndText?: string;
    betweenStartText?: string;
    operationDescriptions?: dxGanttFilterRowOperationDescriptions;
    resetOperationText?: string;
    showAllText?: string;
    showOperationChooser?: boolean;
    visible?: boolean;
}>;
declare const FilterRow: ((props: IFilterRowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    betweenEndText?: string | undefined;
    betweenStartText?: string | undefined;
    operationDescriptions?: dxGanttFilterRowOperationDescriptions | undefined;
    resetOperationText?: string | undefined;
    showAllText?: string | undefined;
    showOperationChooser?: boolean | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGanttHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    height?: number;
    search?: HeaderFilterSearchConfig;
    searchTimeout?: number;
    texts?: dxGanttHeaderFilterTexts;
    visible?: boolean;
    width?: number;
}>;
declare const GanttHeaderFilter: ((props: IGanttHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    height?: number | undefined;
    search?: HeaderFilterSearchConfig | undefined;
    searchTimeout?: number | undefined;
    texts?: dxGanttHeaderFilterTexts | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGanttHeaderFilterSearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    timeout?: number;
}>;
declare const GanttHeaderFilterSearch: ((props: IGanttHeaderFilterSearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    dataSource?: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    groupInterval?: Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig;
    searchMode?: SearchMode;
    width?: number | string | undefined;
    searchTimeout?: number;
    texts?: dxGanttHeaderFilterTexts;
    visible?: boolean;
}>;
declare const HeaderFilter: ((props: IHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | undefined;
    groupInterval?: Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: HeaderFilterSearchConfig | ColumnHeaderFilterSearchConfig | undefined;
    searchMode?: SearchMode | undefined;
    width?: number | string | undefined;
    searchTimeout?: number | undefined;
    texts?: dxGanttHeaderFilterTexts | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    beginGroup?: boolean;
    closeMenuOnClick?: boolean;
    disabled?: boolean;
    icon?: string;
    items?: Array<dxContextMenuItem>;
    name?: GanttPredefinedContextMenuItem | string | GanttPredefinedToolbarItem;
    selectable?: boolean;
    selected?: boolean;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    cssClass?: string | undefined;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    options?: any;
    showText?: ShowTextMode;
    widget?: ToolbarItemComponent;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    beginGroup?: boolean | undefined;
    closeMenuOnClick?: boolean | undefined;
    disabled?: boolean | undefined;
    icon?: string | undefined;
    items?: dxContextMenuItem[] | undefined;
    name?: string | undefined;
    selectable?: boolean | undefined;
    selected?: boolean | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    cssClass?: string | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    widget?: ToolbarItemComponent | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IOperationDescriptionsProps = React.PropsWithChildren<{
    between?: string;
    contains?: string;
    endsWith?: string;
    equal?: string;
    greaterThan?: string;
    greaterThanOrEqual?: string;
    lessThan?: string;
    lessThanOrEqual?: string;
    notContains?: string;
    notEqual?: string;
    startsWith?: string;
}>;
declare const OperationDescriptions: ((props: IOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    between?: string | undefined;
    contains?: string | undefined;
    endsWith?: string | undefined;
    equal?: string | undefined;
    greaterThan?: string | undefined;
    greaterThanOrEqual?: string | undefined;
    lessThan?: string | undefined;
    lessThanOrEqual?: string | undefined;
    notContains?: string | undefined;
    notEqual?: string | undefined;
    startsWith?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IResourceAssignmentsProps = React.PropsWithChildren<{
    dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
    keyExpr?: ((resourceAssignment: any) => any) | string;
    resourceIdExpr?: ((resourceAssignment: any, value: any) => any) | string;
    taskIdExpr?: ((resourceAssignment: any, value: any) => any) | string;
}>;
declare const ResourceAssignments: ((props: IResourceAssignmentsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    dataSource?: string | any[] | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null | undefined;
    keyExpr?: string | ((resourceAssignment: any) => any) | undefined;
    resourceIdExpr?: string | ((resourceAssignment: any, value: any) => any) | undefined;
    taskIdExpr?: string | ((resourceAssignment: any, value: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IResourcesProps = React.PropsWithChildren<{
    colorExpr?: ((resource: any, value: any) => any) | string;
    dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
    keyExpr?: ((resource: any) => any) | string;
    textExpr?: ((resource: any, value: any) => string) | string;
}>;
declare const Resources: ((props: IResourcesProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    colorExpr?: string | ((resource: any, value: any) => any) | undefined;
    dataSource?: string | any[] | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null | undefined;
    keyExpr?: string | ((resource: any) => any) | undefined;
    textExpr?: string | ((resource: any, value: any) => string) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IScaleTypeRangeProps = React.PropsWithChildren<{
    max?: GanttScaleType;
    min?: GanttScaleType;
}>;
declare const ScaleTypeRange: ((props: IScaleTypeRangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    max?: GanttScaleType | undefined;
    min?: GanttScaleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number;
}>;
declare const Search: ((props: ISearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISortingProps = React.PropsWithChildren<{
    ascendingText?: string;
    clearText?: string;
    descendingText?: string;
    mode?: SingleMultipleOrNone | string;
    showSortIndexes?: boolean;
}>;
declare const Sorting: ((props: ISortingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ascendingText?: string | undefined;
    clearText?: string | undefined;
    descendingText?: string | undefined;
    mode?: string | undefined;
    showSortIndexes?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStripLineProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    end?: Date | (() => Date | number | string) | number | string | undefined;
    start?: Date | (() => Date | number | string) | number | string | undefined;
    title?: string | undefined;
}>;
declare const StripLine: ((props: IStripLineProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    end?: Date | (() => Date | number | string) | number | string | undefined;
    start?: Date | (() => Date | number | string) | number | string | undefined;
    title?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITasksProps = React.PropsWithChildren<{
    colorExpr?: ((task: any, value: any) => any) | string;
    dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
    endExpr?: ((task: any, value: any) => any) | string;
    keyExpr?: ((task: any) => any) | string;
    parentIdExpr?: ((task: any, value: any) => any) | string;
    progressExpr?: ((task: any, value: any) => any) | string;
    startExpr?: ((task: any, value: any) => any) | string;
    titleExpr?: ((task: any, value: any) => any) | string;
}>;
declare const Tasks: ((props: ITasksProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    colorExpr?: string | ((task: any, value: any) => any) | undefined;
    dataSource?: string | any[] | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null | undefined;
    endExpr?: string | ((task: any, value: any) => any) | undefined;
    keyExpr?: string | ((task: any) => any) | undefined;
    parentIdExpr?: string | ((task: any, value: any) => any) | undefined;
    progressExpr?: string | ((task: any, value: any) => any) | undefined;
    startExpr?: string | ((task: any, value: any) => any) | undefined;
    titleExpr?: string | ((task: any, value: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITextsProps = React.PropsWithChildren<{
    cancel?: string;
    emptyValue?: string;
    ok?: string;
}>;
declare const Texts: ((props: ITextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cancel?: string | undefined;
    emptyValue?: string | undefined;
    ok?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarProps = React.PropsWithChildren<{
    items?: Array<dxGanttToolbarItem | GanttPredefinedToolbarItem>;
}>;
declare const Toolbar: ((props: IToolbarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    items?: (GanttPredefinedToolbarItem | dxGanttToolbarItem)[] | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    name?: GanttPredefinedToolbarItem | string;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const ToolbarItem: ((props: IToolbarItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    name?: string | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValidationProps = React.PropsWithChildren<{
    autoUpdateParentTasks?: boolean;
    enablePredecessorGap?: boolean;
    validateDependencies?: boolean;
}>;
declare const Validation: ((props: IValidationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    autoUpdateParentTasks?: boolean | undefined;
    enablePredecessorGap?: boolean | undefined;
    validateDependencies?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Gantt;
export { Gantt, IGanttOptions, GanttRef, Column, IColumnProps, ColumnHeaderFilter, IColumnHeaderFilterProps, ColumnHeaderFilterSearch, IColumnHeaderFilterSearchProps, ContextMenu, IContextMenuProps, ContextMenuItem, IContextMenuItemProps, ContextMenuItemItem, IContextMenuItemItemProps, Dependencies, IDependenciesProps, Editing, IEditingProps, FilterRow, IFilterRowProps, Format, IFormatProps, GanttHeaderFilter, IGanttHeaderFilterProps, GanttHeaderFilterSearch, IGanttHeaderFilterSearchProps, HeaderFilter, IHeaderFilterProps, Item, IItemProps, OperationDescriptions, IOperationDescriptionsProps, ResourceAssignments, IResourceAssignmentsProps, Resources, IResourcesProps, ScaleTypeRange, IScaleTypeRangeProps, Search, ISearchProps, Sorting, ISortingProps, StripLine, IStripLineProps, Tasks, ITasksProps, Texts, ITextsProps, Toolbar, IToolbarProps, ToolbarItem, IToolbarItemProps, Validation, IValidationProps };
import type * as GanttTypes from 'devextreme/ui/gantt_types';
export { GanttTypes };
