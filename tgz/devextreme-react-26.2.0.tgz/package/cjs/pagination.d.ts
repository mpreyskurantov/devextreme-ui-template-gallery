/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxPagination, { Properties } from "devextreme/ui/pagination";
import { IHtmlOptions } from "./core/component";
type IPaginationOptions = React.PropsWithChildren<Properties & IHtmlOptions & {
    defaultPageIndex?: number;
    defaultPageSize?: number;
    onPageIndexChange?: (value: number) => void;
    onPageSizeChange?: (value: number) => void;
}>;
interface PaginationRef {
    instance: () => dxPagination;
}
declare const Pagination: (props: React.PropsWithChildren<IPaginationOptions> & {
    ref?: Ref<PaginationRef>;
}) => ReactElement | null;
export default Pagination;
export { Pagination, IPaginationOptions, PaginationRef };
import type * as PaginationTypes from 'devextreme/ui/pagination_types';
export { PaginationTypes };
