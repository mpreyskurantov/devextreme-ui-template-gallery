/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxPivotGrid, { Properties } from "devextreme/ui/pivot_grid";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { CellClickEvent, CellPreparedEvent, ContentReadyEvent, ContextMenuPreparingEvent, DisposingEvent, ExportingEvent, InitializedEvent } from "devextreme/ui/pivot_grid";
import type { ApplyChangesMode, HeaderFilterSearchConfig, StateStoreType } from "devextreme/common/grids";
import type { FieldChooserLayout, ScrollMode, Mode, SearchMode } from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IPivotGridOptionsNarrowedEvents = {
    onCellClick?: ((e: CellClickEvent) => void) | undefined;
    onCellPrepared?: ((e: CellPreparedEvent) => void) | undefined;
    onContentReady?: ((e: ContentReadyEvent) => void);
    onContextMenuPreparing?: ((e: ContextMenuPreparingEvent) => void) | undefined;
    onDisposing?: ((e: DisposingEvent) => void);
    onExporting?: ((e: ExportingEvent) => void) | undefined;
    onInitialized?: ((e: InitializedEvent) => void);
};
type IPivotGridOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IPivotGridOptionsNarrowedEvents> & IHtmlOptions>;
interface PivotGridRef {
    instance: () => dxPivotGrid;
}
declare const PivotGrid: (props: React.PropsWithChildren<IPivotGridOptions> & {
    ref?: Ref<PivotGridRef>;
}) => ReactElement | null;
type IExportProps = React.PropsWithChildren<{
    enabled?: boolean;
}>;
declare const Export: ((props: IExportProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFieldChooserProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    applyChangesMode?: ApplyChangesMode;
    enabled?: boolean;
    height?: number | string;
    layout?: FieldChooserLayout;
    searchTimeout?: number;
    texts?: Record<string, any> | {
        allFields?: string;
        columnFields?: string;
        dataFields?: string;
        filterFields?: string;
        rowFields?: string;
    };
    title?: string;
    width?: number | string;
}>;
declare const FieldChooser: ((props: IFieldChooserProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    applyChangesMode?: ApplyChangesMode | undefined;
    enabled?: boolean | undefined;
    height?: string | number | undefined;
    layout?: FieldChooserLayout | undefined;
    searchTimeout?: number | undefined;
    texts?: Record<string, any> | {
        allFields?: string | undefined;
        columnFields?: string | undefined;
        dataFields?: string | undefined;
        filterFields?: string | undefined;
        rowFields?: string | undefined;
    } | undefined;
    title?: string | undefined;
    width?: string | number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFieldChooserTextsProps = React.PropsWithChildren<{
    allFields?: string;
    columnFields?: string;
    dataFields?: string;
    filterFields?: string;
    rowFields?: string;
}>;
declare const FieldChooserTexts: ((props: IFieldChooserTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allFields?: string | undefined;
    columnFields?: string | undefined;
    dataFields?: string | undefined;
    filterFields?: string | undefined;
    rowFields?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFieldPanelProps = React.PropsWithChildren<{
    allowFieldDragging?: boolean;
    showColumnFields?: boolean;
    showDataFields?: boolean;
    showFilterFields?: boolean;
    showRowFields?: boolean;
    texts?: Record<string, any> | {
        columnFieldArea?: string;
        dataFieldArea?: string;
        filterFieldArea?: string;
        rowFieldArea?: string;
    };
    visible?: boolean;
}>;
declare const FieldPanel: ((props: IFieldPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowFieldDragging?: boolean | undefined;
    showColumnFields?: boolean | undefined;
    showDataFields?: boolean | undefined;
    showFilterFields?: boolean | undefined;
    showRowFields?: boolean | undefined;
    texts?: Record<string, any> | {
        columnFieldArea?: string | undefined;
        dataFieldArea?: string | undefined;
        filterFieldArea?: string | undefined;
        rowFieldArea?: string | undefined;
    } | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFieldPanelTextsProps = React.PropsWithChildren<{
    columnFieldArea?: string;
    dataFieldArea?: string;
    filterFieldArea?: string;
    rowFieldArea?: string;
}>;
declare const FieldPanelTexts: ((props: IFieldPanelTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    columnFieldArea?: string | undefined;
    dataFieldArea?: string | undefined;
    filterFieldArea?: string | undefined;
    rowFieldArea?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    height?: number;
    search?: HeaderFilterSearchConfig;
    searchTimeout?: number;
    showRelevantValues?: boolean;
    texts?: Record<string, any> | {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    };
    width?: number;
}>;
declare const HeaderFilter: ((props: IHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    height?: number | undefined;
    search?: HeaderFilterSearchConfig | undefined;
    searchTimeout?: number | undefined;
    showRelevantValues?: boolean | undefined;
    texts?: Record<string, any> | {
        cancel?: string | undefined;
        emptyValue?: string | undefined;
        ok?: string | undefined;
    } | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeaderFilterTextsProps = React.PropsWithChildren<{
    cancel?: string;
    emptyValue?: string;
    ok?: string;
}>;
declare const HeaderFilterTexts: ((props: IHeaderFilterTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cancel?: string | undefined;
    emptyValue?: string | undefined;
    ok?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadPanelProps = React.PropsWithChildren<{
    enabled?: boolean;
    height?: number;
    indicatorSrc?: string;
    shading?: boolean;
    shadingColor?: string;
    showIndicator?: boolean;
    showPane?: boolean;
    text?: string;
    width?: number;
}>;
declare const LoadPanel: ((props: ILoadPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | undefined;
    height?: number | undefined;
    indicatorSrc?: string | undefined;
    shading?: boolean | undefined;
    shadingColor?: string | undefined;
    showIndicator?: boolean | undefined;
    showPane?: boolean | undefined;
    text?: string | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPivotGridTextsProps = React.PropsWithChildren<{
    collapseAll?: string;
    dataNotAvailable?: string;
    expandAll?: string;
    exportToExcel?: string;
    grandTotal?: string;
    noData?: string;
    removeAllSorting?: string;
    showFieldChooser?: string;
    sortColumnBySummary?: string;
    sortRowBySummary?: string;
    total?: string;
}>;
declare const PivotGridTexts: ((props: IPivotGridTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    collapseAll?: string | undefined;
    dataNotAvailable?: string | undefined;
    expandAll?: string | undefined;
    exportToExcel?: string | undefined;
    grandTotal?: string | undefined;
    noData?: string | undefined;
    removeAllSorting?: string | undefined;
    showFieldChooser?: string | undefined;
    sortColumnBySummary?: string | undefined;
    sortRowBySummary?: string | undefined;
    total?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IScrollingProps = React.PropsWithChildren<{
    mode?: ScrollMode;
    useNative?: boolean | Mode;
}>;
declare const Scrolling: ((props: IScrollingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    mode?: ScrollMode | undefined;
    useNative?: boolean | "auto" | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    timeout?: number;
}>;
declare const Search: ((props: ISearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStateStoringProps = React.PropsWithChildren<{
    customLoad?: (() => any);
    customSave?: ((state: any) => void);
    enabled?: boolean;
    savingTimeout?: number;
    storageKey?: string | undefined;
    type?: StateStoreType;
}>;
declare const StateStoring: ((props: IStateStoringProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customLoad?: (() => any) | undefined;
    customSave?: ((state: any) => void) | undefined;
    enabled?: boolean | undefined;
    savingTimeout?: number | undefined;
    storageKey?: string | undefined;
    type?: StateStoreType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITextsProps = React.PropsWithChildren<{
    allFields?: string;
    columnFields?: string;
    dataFields?: string;
    filterFields?: string;
    rowFields?: string;
    columnFieldArea?: string;
    dataFieldArea?: string;
    filterFieldArea?: string;
    rowFieldArea?: string;
    cancel?: string;
    emptyValue?: string;
    ok?: string;
    collapseAll?: string;
    dataNotAvailable?: string;
    expandAll?: string;
    exportToExcel?: string;
    grandTotal?: string;
    noData?: string;
    removeAllSorting?: string;
    showFieldChooser?: string;
    sortColumnBySummary?: string;
    sortRowBySummary?: string;
    total?: string;
}>;
declare const Texts: ((props: ITextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allFields?: string | undefined;
    columnFields?: string | undefined;
    dataFields?: string | undefined;
    filterFields?: string | undefined;
    rowFields?: string | undefined;
    columnFieldArea?: string | undefined;
    dataFieldArea?: string | undefined;
    filterFieldArea?: string | undefined;
    rowFieldArea?: string | undefined;
    cancel?: string | undefined;
    emptyValue?: string | undefined;
    ok?: string | undefined;
    collapseAll?: string | undefined;
    dataNotAvailable?: string | undefined;
    expandAll?: string | undefined;
    exportToExcel?: string | undefined;
    grandTotal?: string | undefined;
    noData?: string | undefined;
    removeAllSorting?: string | undefined;
    showFieldChooser?: string | undefined;
    sortColumnBySummary?: string | undefined;
    sortRowBySummary?: string | undefined;
    total?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default PivotGrid;
export { PivotGrid, IPivotGridOptions, PivotGridRef, Export, IExportProps, FieldChooser, IFieldChooserProps, FieldChooserTexts, IFieldChooserTextsProps, FieldPanel, IFieldPanelProps, FieldPanelTexts, IFieldPanelTextsProps, HeaderFilter, IHeaderFilterProps, HeaderFilterTexts, IHeaderFilterTextsProps, LoadPanel, ILoadPanelProps, PivotGridTexts, IPivotGridTextsProps, Scrolling, IScrollingProps, Search, ISearchProps, StateStoring, IStateStoringProps, Texts, ITextsProps };
import type * as PivotGridTypes from 'devextreme/ui/pivot_grid_types';
export { PivotGridTypes };
