/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxDraggable, { Properties } from "devextreme/ui/draggable";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { DisposingEvent, DragEndEvent, DragMoveEvent, DragStartEvent, InitializedEvent } from "devextreme/ui/draggable";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IDraggableOptionsNarrowedEvents = {
    onDisposing?: ((e: DisposingEvent) => void);
    onDragEnd?: ((e: DragEndEvent) => void) | undefined;
    onDragMove?: ((e: DragMoveEvent) => void) | undefined;
    onDragStart?: ((e: DragStartEvent) => void) | undefined;
    onInitialized?: ((e: InitializedEvent) => void);
};
type IDraggableOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IDraggableOptionsNarrowedEvents> & IHtmlOptions & {
    dragRender?: (...params: any) => React.ReactNode;
    dragComponent?: React.ComponentType<any>;
}>;
interface DraggableRef {
    instance: () => dxDraggable;
}
declare const Draggable: (props: React.PropsWithChildren<IDraggableOptions> & {
    ref?: Ref<DraggableRef>;
}) => ReactElement | null;
type ICursorOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const CursorOffset: ((props: ICursorOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Draggable;
export { Draggable, IDraggableOptions, DraggableRef, CursorOffset, ICursorOffsetProps };
import type * as DraggableTypes from 'devextreme/ui/draggable_types';
export { DraggableTypes };
