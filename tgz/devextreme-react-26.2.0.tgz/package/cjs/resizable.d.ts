/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxResizable, { Properties } from "devextreme/ui/resizable";
import { IHtmlOptions } from "./core/component";
import type { DisposingEvent, InitializedEvent, ResizeEvent, ResizeEndEvent, ResizeStartEvent } from "devextreme/ui/resizable";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IResizableOptionsNarrowedEvents = {
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onResize?: ((e: ResizeEvent) => void) | undefined;
    onResizeEnd?: ((e: ResizeEndEvent) => void) | undefined;
    onResizeStart?: ((e: ResizeStartEvent) => void) | undefined;
};
type IResizableOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IResizableOptionsNarrowedEvents> & IHtmlOptions & {
    defaultHeight?: number | string;
    defaultWidth?: number | string;
    onHeightChange?: (value: number | string) => void;
    onWidthChange?: (value: number | string) => void;
}>;
interface ResizableRef {
    instance: () => dxResizable;
}
declare const Resizable: (props: React.PropsWithChildren<IResizableOptions> & {
    ref?: Ref<ResizableRef>;
}) => ReactElement | null;
export default Resizable;
export { Resizable, IResizableOptions, ResizableRef };
import type * as ResizableTypes from 'devextreme/ui/resizable_types';
export { ResizableTypes };
