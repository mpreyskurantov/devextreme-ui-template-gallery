/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as AiIntegrationModule from "devextreme/common/ai-integration";
import * as ChartsModule from "devextreme/common/charts";
import * as CoreAnimationModule from "devextreme/common/core/animation";
import * as CoreEnvironmentModule from "devextreme/common/core/environment";
import * as CoreEventsModule from "devextreme/common/core/events";
import * as CoreLocalizationModule from "devextreme/common/core/localization";
import * as DataModule from "devextreme/common/data";
import * as ExportExcelModule from "devextreme/common/export/excel";
import * as ExportPdfModule from "devextreme/common/export/pdf";
import * as GridsModule from "devextreme/common/grids";
export { config, Guid, setTemplateEngine, } from "devextreme/common";
export type { ApplyValueMode, AsyncRule, ButtonStyle, ButtonType, CompareRule, ComparisonOperator, CustomRule, DataStructure, DataType, DateLike, DayOfWeek, DefaultOptionsRule, Direction, DisplayMode, DragDirection, Draggable, DragHighlight, EditorStyle, EmailRule, ExportFormat, FieldChooserLayout, FirstDayOfWeek, FloatingActionButtonDirection, Format, GlobalConfig, HorizontalAlignment, HorizontalEdge, LabelMode, MaskMode, Mode, NumericRule, Orientation, PageLoadMode, PageOrientation, PatternRule, Position, PositionAlignment, RangeRule, RequiredRule, Scrollable, ScrollbarMode, ScrollDirection, ScrollMode, SearchMode, SelectAllMode, SimplifiedSearchMode, SingleMultipleAllOrNone, SingleMultipleOrNone, SingleOrMultiple, SingleOrNone, SliderValueChangeMode, Sortable, SortOrder, StoreType, StringLengthRule, SubmenuShowMode, TabsIconPosition, TabsStyle, template, TextBoxPredefinedButton, TextEditorButton, TextEditorButtonLocation, ToolbarItemComponent, ToolbarItemLocation, TooltipShowMode, ValidationCallbackData, ValidationMessageMode, ValidationRule, ValidationRuleType, ValidationStatus, VerticalAlignment, VerticalEdge, } from "devextreme/common";
export declare namespace AiIntegration {
    const AIIntegration: typeof AiIntegrationModule.AIIntegration;
    type AIIntegration = AiIntegrationModule.AIIntegration;
    type AIIntegrationOptions = AiIntegrationModule.AIIntegrationOptions;
    type AIProvider = AiIntegrationModule.AIProvider;
    type AIResponse = AiIntegrationModule.AIResponse;
    type ExecuteGridAssistantCommandResponse = AiIntegrationModule.ExecuteGridAssistantCommandResponse;
    type GenerateGridColumnCommandResponse = AiIntegrationModule.GenerateGridColumnCommandResponse;
    type Prompt = AiIntegrationModule.Prompt;
    type RequestParams = AiIntegrationModule.RequestParams;
    type RequestParamsData = AiIntegrationModule.RequestParamsData;
    type Response = AiIntegrationModule.Response;
}
export declare namespace Charts {
    type AnimationEaseMode = ChartsModule.AnimationEaseMode;
    type AnnotationType = ChartsModule.AnnotationType;
    type ArgumentAxisHoverMode = ChartsModule.ArgumentAxisHoverMode;
    type AxisScaleType = ChartsModule.AxisScaleType;
    type ChartsAxisLabelOverlap = ChartsModule.ChartsAxisLabelOverlap;
    type ChartsColor = ChartsModule.ChartsColor;
    type ChartsDataType = ChartsModule.ChartsDataType;
    type ChartsLabelOverlap = ChartsModule.ChartsLabelOverlap;
    type DashStyle = ChartsModule.DashStyle;
    type DiscreteAxisDivisionMode = ChartsModule.DiscreteAxisDivisionMode;
    type Font = ChartsModule.Font;
    type GradientColor = ChartsModule.GradientColor;
    type HatchDirection = ChartsModule.HatchDirection;
    type LabelOverlap = ChartsModule.LabelOverlap;
    type LabelPosition = ChartsModule.LabelPosition;
    type LegendHoverMode = ChartsModule.LegendHoverMode;
    type LegendItem = ChartsModule.LegendItem;
    type LegendMarkerState = ChartsModule.LegendMarkerState;
    type Palette = ChartsModule.Palette;
    type PaletteColorSet = ChartsModule.PaletteColorSet;
    type PaletteExtensionMode = ChartsModule.PaletteExtensionMode;
    type PointInteractionMode = ChartsModule.PointInteractionMode;
    type PointSymbol = ChartsModule.PointSymbol;
    const registerGradient: typeof ChartsModule.registerGradient;
    const registerPattern: typeof ChartsModule.registerPattern;
    type RelativePosition = ChartsModule.RelativePosition;
    type ScaleBreak = ChartsModule.ScaleBreak;
    type ScaleBreakLineStyle = ChartsModule.ScaleBreakLineStyle;
    type SeriesHoverMode = ChartsModule.SeriesHoverMode;
    type SeriesLabel = ChartsModule.SeriesLabel;
    type SeriesPoint = ChartsModule.SeriesPoint;
    type SeriesSelectionMode = ChartsModule.SeriesSelectionMode;
    type SeriesType = ChartsModule.SeriesType;
    type ShiftLabelOverlap = ChartsModule.ShiftLabelOverlap;
    type TextOverflow = ChartsModule.TextOverflow;
    type Theme = ChartsModule.Theme;
    type TimeInterval = ChartsModule.TimeInterval;
    type TimeIntervalConfig = ChartsModule.TimeIntervalConfig;
    type ValueAxisVisualRangeUpdateMode = ChartsModule.ValueAxisVisualRangeUpdateMode;
    type ValueErrorBarDisplayMode = ChartsModule.ValueErrorBarDisplayMode;
    type ValueErrorBarType = ChartsModule.ValueErrorBarType;
    type VisualRange = ChartsModule.VisualRange;
    type VisualRangeUpdateMode = ChartsModule.VisualRangeUpdateMode;
    type WordWrap = ChartsModule.WordWrap;
    type ZoomPanAction = ChartsModule.ZoomPanAction;
}
export declare namespace Core {
    namespace Animation {
        type AnimationConfig = CoreAnimationModule.AnimationConfig;
        const animationPresets: {
            applyChanges(): void;
            clear(): void;
            clear(name: string): void;
            getPreset(name: string): CoreAnimationModule.AnimationConfig;
            registerDefaultPresets(): void;
            registerPreset(name: string, config: {
                animation: CoreAnimationModule.AnimationConfig;
                device?: CoreEnvironmentModule.Device | undefined;
            }): void;
            resetToDefaults(): void;
        };
        type AnimationState = CoreAnimationModule.AnimationState;
        const cancelAnimationFrame: typeof CoreAnimationModule.cancelAnimationFrame;
        type CollisionResolution = CoreAnimationModule.CollisionResolution;
        type CollisionResolutionCombination = CoreAnimationModule.CollisionResolutionCombination;
        const fx: {
            animate(element: Element, config: CoreAnimationModule.AnimationConfig): Promise<void>;
            isAnimating(element: Element): boolean;
            stop(element: Element, jumpToEnd: boolean): void;
        };
        type PositionConfig = CoreAnimationModule.PositionConfig;
        const requestAnimationFrame: typeof CoreAnimationModule.requestAnimationFrame;
        const TransitionExecutor: typeof CoreAnimationModule.TransitionExecutor;
        type TransitionExecutor = CoreAnimationModule.TransitionExecutor;
    }
    namespace Environment {
        type Device = CoreEnvironmentModule.Device;
        const getTimeZones: typeof CoreEnvironmentModule.getTimeZones;
        const hideTopOverlay: typeof CoreEnvironmentModule.hideTopOverlay;
        const initMobileViewport: typeof CoreEnvironmentModule.initMobileViewport;
        type SchedulerTimeZone = CoreEnvironmentModule.SchedulerTimeZone;
    }
    namespace Events {
        type AsyncCancelable = CoreEventsModule.AsyncCancelable;
        type Cancelable = CoreEventsModule.Cancelable;
        type ChangedOptionInfo = CoreEventsModule.ChangedOptionInfo;
        type EventInfo<TComponent> = CoreEventsModule.EventInfo<TComponent>;
        type EventObject = CoreEventsModule.EventObject;
        type InitializedEventInfo<TComponent> = CoreEventsModule.InitializedEventInfo<TComponent>;
        type ItemInfo<TItemData = any> = CoreEventsModule.ItemInfo<TItemData>;
        type NativeEventInfo<TComponent, TNativeEvent = Event> = CoreEventsModule.NativeEventInfo<TComponent, TNativeEvent>;
        const off: typeof CoreEventsModule.off;
        const on: typeof CoreEventsModule.on;
        const one: typeof CoreEventsModule.one;
        const trigger: typeof CoreEventsModule.trigger;
    }
    namespace Localization {
        type Format = CoreLocalizationModule.Format;
        const formatDate: typeof CoreLocalizationModule.formatDate;
        const formatMessage: typeof CoreLocalizationModule.formatMessage;
        const formatNumber: typeof CoreLocalizationModule.formatNumber;
        const loadMessages: typeof CoreLocalizationModule.loadMessages;
        const locale: typeof CoreLocalizationModule.locale;
        const parseDate: typeof CoreLocalizationModule.parseDate;
        const parseNumber: typeof CoreLocalizationModule.parseNumber;
    }
}
export declare namespace Data {
    const applyChanges: typeof DataModule.applyChanges;
    const ArrayStore: typeof DataModule.ArrayStore;
    type ArrayStore<TItem = any, TKey = any> = DataModule.ArrayStore<TItem, TKey>;
    type ArrayStoreOptions<TItem = any, TKey = any> = DataModule.ArrayStoreOptions<TItem, TKey>;
    const base64_encode: typeof DataModule.base64_encode;
    const compileGetter: typeof DataModule.compileGetter;
    const compileSetter: typeof DataModule.compileSetter;
    const CustomStore: typeof DataModule.CustomStore;
    type CustomStore<TItem = any, TKey = any> = DataModule.CustomStore<TItem, TKey>;
    type CustomStoreOptions<TItem = any, TKey = any> = DataModule.CustomStoreOptions<TItem, TKey>;
    const DataSource: typeof DataModule.DataSource;
    type DataSource<TItem = any, TKey = any> = DataModule.DataSource<TItem, TKey>;
    type DataSourceOptions<TStoreItem = any, TMappedItem = TStoreItem, TItem = TMappedItem, TKey = any> = DataModule.DataSourceOptions<TStoreItem, TMappedItem, TItem, TKey>;
    const EdmLiteral: typeof DataModule.EdmLiteral;
    type EdmLiteral = DataModule.EdmLiteral;
    const EndpointSelector: typeof DataModule.EndpointSelector;
    type EndpointSelector = DataModule.EndpointSelector;
    const errorHandler: typeof DataModule.errorHandler;
    type FilterDescriptor = DataModule.FilterDescriptor;
    type GroupDescriptor<T> = DataModule.GroupDescriptor<T>;
    type GroupingInterval = DataModule.GroupingInterval;
    type GroupItem<TItem = any> = DataModule.GroupItem<TItem>;
    const isGroupItemsArray: typeof DataModule.isGroupItemsArray;
    const isItemsArray: typeof DataModule.isItemsArray;
    const isLoadResultObject: typeof DataModule.isLoadResultObject;
    const keyConverters: any;
    type LangParams = DataModule.LangParams;
    type LoadOptions<T = any> = DataModule.LoadOptions<T>;
    type LoadResult<TItem = any> = DataModule.LoadResult<TItem>;
    type LoadResultObject<TItem = any> = DataModule.LoadResultObject<TItem>;
    const LocalStore: typeof DataModule.LocalStore;
    type LocalStore<TItem = any, TKey = any> = DataModule.LocalStore<TItem, TKey>;
    type LocalStoreOptions<TItem = any, TKey = any> = DataModule.LocalStoreOptions<TItem, TKey>;
    type MultiValueSearchOperation = DataModule.MultiValueSearchOperation;
    const ODataContext: typeof DataModule.ODataContext;
    type ODataContext = DataModule.ODataContext;
    type ODataContextOptions = DataModule.ODataContextOptions;
    const ODataStore: typeof DataModule.ODataStore;
    type ODataStore<TItem = any, TKey = any> = DataModule.ODataStore<TItem, TKey>;
    type ODataStoreOptions<TItem = any, TKey = any> = DataModule.ODataStoreOptions<TItem, TKey>;
    const query: typeof DataModule.query;
    type Query = DataModule.Query;
    type ResolvedData<TItem = any> = DataModule.ResolvedData<TItem>;
    type SearchOperation = DataModule.SearchOperation;
    type SelectDescriptor<T> = DataModule.SelectDescriptor<T>;
    const setErrorHandler: typeof DataModule.setErrorHandler;
    type SortDescriptor<T> = DataModule.SortDescriptor<T>;
    type Store<TItem = any, TKey = any> = DataModule.Store<TItem, TKey>;
    type StoreOptions<TItem = any, TKey = any> = DataModule.StoreOptions<TItem, TKey>;
    type SummaryDescriptor<T> = DataModule.SummaryDescriptor<T>;
}
export declare namespace Export {
    namespace Excel {
        type CellAddress = ExportExcelModule.CellAddress;
        type CellRange = ExportExcelModule.CellRange;
        type DataGridCell = ExportExcelModule.DataGridCell;
        type DataGridExportOptions = ExportExcelModule.DataGridExportOptions;
        const exportDataGrid: typeof ExportExcelModule.exportDataGrid;
        const exportPivotGrid: typeof ExportExcelModule.exportPivotGrid;
        type PivotGridCell = ExportExcelModule.PivotGridCell;
        type PivotGridExportOptions = ExportExcelModule.PivotGridExportOptions;
    }
    namespace Pdf {
        type Cell = ExportPdfModule.Cell;
        type DataGridCell = ExportPdfModule.DataGridCell;
        type DataGridExportOptions = ExportPdfModule.DataGridExportOptions;
        const exportDataGrid: typeof ExportPdfModule.exportDataGrid;
        const exportGantt: typeof ExportPdfModule.exportGantt;
        type GanttExportFont = ExportPdfModule.GanttExportFont;
        type GanttExportOptions = ExportPdfModule.GanttExportOptions;
    }
}
export declare function Grids(): void;
export declare namespace Grids {
    type AdaptiveDetailRowPreparingInfo = GridsModule.AdaptiveDetailRowPreparingInfo;
    type AIAssistant<TCommands extends PredefinedCommands = PredefinedCommands> = GridsModule.AIAssistant<TCommands>;
    type AIAssistantRequestCreatingInfo = GridsModule.AIAssistantRequestCreatingInfo;
    type AIColumnMode = GridsModule.AIColumnMode;
    type AIColumnRequestCreatingInfo<TRowData = any> = GridsModule.AIColumnRequestCreatingInfo<TRowData>;
    type ApplyChangesMode = GridsModule.ApplyChangesMode;
    type ApplyFilterMode = GridsModule.ApplyFilterMode;
    type BasicFilterExpr = GridsModule.BasicFilterExpr;
    type ColumnAIOptions = GridsModule.ColumnAIOptions;
    type ColumnBase<TRowData = any> = GridsModule.ColumnBase<TRowData>;
    type ColumnButtonBase = GridsModule.ColumnButtonBase;
    type ColumnChooser = GridsModule.ColumnChooser;
    type ColumnChooserMode = GridsModule.ColumnChooserMode;
    type ColumnChooserSearchConfig = GridsModule.ColumnChooserSearchConfig;
    type ColumnChooserSelectionConfig = GridsModule.ColumnChooserSelectionConfig;
    type ColumnCustomizeTextArg = GridsModule.ColumnCustomizeTextArg;
    type ColumnFixing = GridsModule.ColumnFixing;
    type ColumnFixingIcons = GridsModule.ColumnFixingIcons;
    type ColumnFixingTexts = GridsModule.ColumnFixingTexts;
    type ColumnHeaderFilter = GridsModule.ColumnHeaderFilter;
    type ColumnHeaderFilterSearchConfig = GridsModule.ColumnHeaderFilterSearchConfig;
    type ColumnLookup = GridsModule.ColumnLookup;
    type ColumnResizeMode = GridsModule.ColumnResizeMode;
    type CombinedFilterExpr = GridsModule.CombinedFilterExpr;
    type CommandInfo<TCommands extends PredefinedCommands = PredefinedCommands> = GridsModule.CommandInfo<TCommands>;
    type CompositeKeyPair = GridsModule.CompositeKeyPair;
    type DataChange<TRowData = any, TKey = any> = GridsModule.DataChange<TRowData, TKey>;
    type DataChangeInfo<TRowData = any, TKey = any> = GridsModule.DataChangeInfo<TRowData, TKey>;
    type DataChangeType = GridsModule.DataChangeType;
    type DataErrorOccurredInfo = GridsModule.DataErrorOccurredInfo;
    type DataRenderMode = GridsModule.DataRenderMode;
    type DragDropInfo = GridsModule.DragDropInfo;
    type DragReorderInfo = GridsModule.DragReorderInfo;
    type DragStartEventInfo<TRowData = any> = GridsModule.DragStartEventInfo<TRowData>;
    type EditingBase<TRowData = any, TKey = any> = GridsModule.EditingBase<TRowData, TKey>;
    type EditingTextsBase = GridsModule.EditingTextsBase;
    type EnterKeyAction = GridsModule.EnterKeyAction;
    type EnterKeyDirection = GridsModule.EnterKeyDirection;
    type FilterExpr = GridsModule.FilterExpr;
    type FilterExprNode = GridsModule.FilterExprNode;
    type FilterExprTree = GridsModule.FilterExprTree;
    type FilterOperation = GridsModule.FilterOperation;
    type FilterPanel<TComponent = any, TRowData = any, TKey = any> = GridsModule.FilterPanel<TComponent, TRowData, TKey>;
    type FilterPanelTexts = GridsModule.FilterPanelTexts;
    type FilterRow = GridsModule.FilterRow;
    type FilterRowOperationDescriptions = GridsModule.FilterRowOperationDescriptions;
    type FilterType = GridsModule.FilterType;
    type FixedPosition = GridsModule.FixedPosition;
    type GridBase<TRowData = any, TKey = any> = GridsModule.GridBase<TRowData, TKey>;
    type GridBaseOptions<TComponent extends GridBase<TRowData, TKey>, TRowData = any, TKey = any> = GridsModule.GridBaseOptions<TComponent, TRowData, TKey>;
    type GridsContextMenuTarget = GridsModule.GridsContextMenuTarget;
    type GridsEditMode = GridsModule.GridsEditMode;
    type GridsEditRefreshMode = GridsModule.GridsEditRefreshMode;
    type GroupExpandMode = GridsModule.GroupExpandMode;
    type HeaderFilter = GridsModule.HeaderFilter;
    type HeaderFilterGroupInterval = GridsModule.HeaderFilterGroupInterval;
    type HeaderFilterSearchConfig = GridsModule.HeaderFilterSearchConfig;
    type HeaderFilterTexts = GridsModule.HeaderFilterTexts;
    type KeyboardNavigation = GridsModule.KeyboardNavigation;
    type KeyDownInfo = GridsModule.KeyDownInfo;
    type LoadPanel = GridsModule.LoadPanel;
    type MultiValueFilterExpr = GridsModule.MultiValueFilterExpr;
    type NegatedFilterExpr = GridsModule.NegatedFilterExpr;
    type NewRowInfo<TRowData = any> = GridsModule.NewRowInfo<TRowData>;
    type NewRowPosition = GridsModule.NewRowPosition;
    type Pager = GridsModule.Pager;
    type PagerPageSize = GridsModule.PagerPageSize;
    type PagingBase = GridsModule.PagingBase;
    type PredefinedCommandNames = GridsModule.PredefinedCommandNames;
    type PredefinedCommands = GridsModule.PredefinedCommands;
    type ResponseStatus = GridsModule.ResponseStatus;
    type ResponseStatusTexts = GridsModule.ResponseStatusTexts;
    type RowDragging<TComponent extends GridBase<TRowData, TKey>, TRowData = any, TKey = any> = GridsModule.RowDragging<TComponent, TRowData, TKey>;
    type RowDraggingEventInfo<TRowData = any> = GridsModule.RowDraggingEventInfo<TRowData>;
    type RowDraggingTemplateData<TRowData = any> = GridsModule.RowDraggingTemplateData<TRowData>;
    type RowInsertedInfo<TRowData = any, TKey = any> = GridsModule.RowInsertedInfo<TRowData, TKey>;
    type RowInsertingInfo<TRowData = any> = GridsModule.RowInsertingInfo<TRowData>;
    type RowKeyInfo<TKey = any> = GridsModule.RowKeyInfo<TKey>;
    type RowRemovedInfo<TRowData = any, TKey = any> = GridsModule.RowRemovedInfo<TRowData, TKey>;
    type RowRemovingInfo<TRowData = any, TKey = any> = GridsModule.RowRemovingInfo<TRowData, TKey>;
    type RowUpdatedInfo<TRowData = any, TKey = any> = GridsModule.RowUpdatedInfo<TRowData, TKey>;
    type RowUpdatingInfo<TRowData = any, TKey = any> = GridsModule.RowUpdatingInfo<TRowData, TKey>;
    type RowValidatingInfo<TRowData = any, TKey = any> = GridsModule.RowValidatingInfo<TRowData, TKey>;
    type SavingInfo<TRowData = any, TKey = any> = GridsModule.SavingInfo<TRowData, TKey>;
    type ScalarFilterValue = GridsModule.ScalarFilterValue;
    type ScrollingBase = GridsModule.ScrollingBase;
    type SearchPanel = GridsModule.SearchPanel;
    type SelectedFilterOperation = GridsModule.SelectedFilterOperation;
    type SelectionBase = GridsModule.SelectionBase;
    type SelectionChangedInfo<TRowData = any, TKey = any> = GridsModule.SelectionChangedInfo<TRowData, TKey>;
    type SelectionColumnDisplayMode = GridsModule.SelectionColumnDisplayMode;
    type Sorting = GridsModule.Sorting;
    type StartEditAction = GridsModule.StartEditAction;
    type StateStoreType = GridsModule.StateStoreType;
    type StateStoring = GridsModule.StateStoring;
    type SummaryType = GridsModule.SummaryType;
    type ToolbarPreparingInfo = GridsModule.ToolbarPreparingInfo;
}
