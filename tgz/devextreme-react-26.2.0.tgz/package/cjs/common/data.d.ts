/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { applyChanges, ArrayStore, base64_encode, compileGetter, compileSetter, CustomStore, DataSource, EdmLiteral, EndpointSelector, errorHandler, isGroupItemsArray, isItemsArray, isLoadResultObject, keyConverters, LocalStore, ODataContext, ODataStore, query, setErrorHandler, } from "devextreme/common/data";
export type { ArrayStoreOptions, CustomStoreOptions, DataSourceOptions, FilterDescriptor, GroupDescriptor, GroupingInterval, GroupItem, LangParams, LoadOptions, LoadResult, LoadResultObject, LocalStoreOptions, MultiValueSearchOperation, ODataContextOptions, ODataStoreOptions, Query, ResolvedData, SearchOperation, SelectDescriptor, SortDescriptor, Store, StoreOptions, SummaryDescriptor, } from "devextreme/common/data";
