/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxPivotGridFieldChooser, { Properties } from "devextreme/ui/pivot_grid_field_chooser";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ContentReadyEvent, ContextMenuPreparingEvent, DisposingEvent, InitializedEvent } from "devextreme/ui/pivot_grid_field_chooser";
import type { HeaderFilterSearchConfig } from "devextreme/common/grids";
import type { SearchMode } from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IPivotGridFieldChooserOptionsNarrowedEvents = {
    onContentReady?: ((e: ContentReadyEvent) => void);
    onContextMenuPreparing?: ((e: ContextMenuPreparingEvent) => void) | undefined;
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
};
type IPivotGridFieldChooserOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IPivotGridFieldChooserOptionsNarrowedEvents> & IHtmlOptions>;
interface PivotGridFieldChooserRef {
    instance: () => dxPivotGridFieldChooser;
}
declare const PivotGridFieldChooser: (props: React.PropsWithChildren<IPivotGridFieldChooserOptions> & {
    ref?: Ref<PivotGridFieldChooserRef>;
}) => ReactElement | null;
type IHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    height?: number;
    search?: HeaderFilterSearchConfig;
    searchTimeout?: number;
    showRelevantValues?: boolean;
    texts?: Record<string, any> | {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    };
    width?: number;
}>;
declare const HeaderFilter: ((props: IHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    height?: number | undefined;
    search?: HeaderFilterSearchConfig | undefined;
    searchTimeout?: number | undefined;
    showRelevantValues?: boolean | undefined;
    texts?: Record<string, any> | {
        cancel?: string | undefined;
        emptyValue?: string | undefined;
        ok?: string | undefined;
    } | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeaderFilterTextsProps = React.PropsWithChildren<{
    cancel?: string;
    emptyValue?: string;
    ok?: string;
}>;
declare const HeaderFilterTexts: ((props: IHeaderFilterTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cancel?: string | undefined;
    emptyValue?: string | undefined;
    ok?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPivotGridFieldChooserTextsProps = React.PropsWithChildren<{
    allFields?: string;
    columnFields?: string;
    dataFields?: string;
    filterFields?: string;
    rowFields?: string;
}>;
declare const PivotGridFieldChooserTexts: ((props: IPivotGridFieldChooserTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allFields?: string | undefined;
    columnFields?: string | undefined;
    dataFields?: string | undefined;
    filterFields?: string | undefined;
    rowFields?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    timeout?: number;
}>;
declare const Search: ((props: ISearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITextsProps = React.PropsWithChildren<{
    cancel?: string;
    emptyValue?: string;
    ok?: string;
    allFields?: string;
    columnFields?: string;
    dataFields?: string;
    filterFields?: string;
    rowFields?: string;
}>;
declare const Texts: ((props: ITextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cancel?: string | undefined;
    emptyValue?: string | undefined;
    ok?: string | undefined;
    allFields?: string | undefined;
    columnFields?: string | undefined;
    dataFields?: string | undefined;
    filterFields?: string | undefined;
    rowFields?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default PivotGridFieldChooser;
export { PivotGridFieldChooser, IPivotGridFieldChooserOptions, PivotGridFieldChooserRef, HeaderFilter, IHeaderFilterProps, HeaderFilterTexts, IHeaderFilterTextsProps, PivotGridFieldChooserTexts, IPivotGridFieldChooserTextsProps, Search, ISearchProps, Texts, ITextsProps };
import type * as PivotGridFieldChooserTypes from 'devextreme/ui/pivot_grid_field_chooser_types';
export { PivotGridFieldChooserTypes };
