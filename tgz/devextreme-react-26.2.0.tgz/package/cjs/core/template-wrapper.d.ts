/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from 'react';
import { TemplateWrapperProps } from './types';
export declare const TemplateWrapper: React.NamedExoticComponent<TemplateWrapperProps>;
