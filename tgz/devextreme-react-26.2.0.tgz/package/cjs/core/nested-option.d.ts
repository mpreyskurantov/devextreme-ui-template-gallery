/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from 'react';
import { IElementDescriptor } from './configuration/react/element';
interface INestedOptionMeta {
    optionName: string;
    registerNestedOption: (component: React.ReactElement) => any;
    updateFunc: (newProps: any, prevProps: any) => void;
    makeDirty: () => void;
}
declare const NestedOption: <P>(props: React.PropsWithChildren<P & {
    elementDescriptor: IElementDescriptor;
}>) => React.ReactElement | null;
export default NestedOption;
export { INestedOptionMeta, };
