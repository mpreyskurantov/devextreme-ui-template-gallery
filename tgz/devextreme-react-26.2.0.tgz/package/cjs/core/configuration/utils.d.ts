/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export declare function mergeNameParts(...args: string[]): string;
export declare function parseOptionName(name: string): IOptionInfo | ICollectionOptionInfo;
interface IOptionInfo {
    isCollectionItem: false;
    name: string;
}
interface ICollectionOptionInfo {
    isCollectionItem: true;
    name: string;
    index: number;
}
export declare const isIE: () => boolean;
export declare const shallowEquals: (first: Record<string, unknown>, second: Record<string, unknown>) => boolean;
export {};
