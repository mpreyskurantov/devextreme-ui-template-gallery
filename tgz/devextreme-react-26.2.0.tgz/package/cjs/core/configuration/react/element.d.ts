/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { ITemplateMeta } from '../../template';
declare enum ElementType {
    Option = 0,
    Template = 1,
    Unknown = 2
}
interface IExpectedChild {
    optionName: string;
    isCollectionItem: boolean;
}
interface IOptionDescriptor {
    isCollection: boolean;
    name: string;
    templates: ITemplateMeta[];
    initialValuesProps: Record<string, string>;
    predefinedValuesProps: Record<string, any>;
    expectedChildren: Record<string, IExpectedChild>;
}
interface IOptionElement {
    type: ElementType.Option;
    descriptor: IOptionDescriptor;
    props: Record<string, any>;
}
declare function getOptionInfo(elementDescriptor: IElementDescriptor, props: Record<string, any>, parentExpectedChildren?: Record<string, IExpectedChild>): IOptionElement;
declare function getElementType(element: React.ReactNode): ElementType;
interface IElementDescriptor {
    OptionName: string;
    IsCollectionItem?: boolean;
    DefaultsProps?: Record<string, string>;
    TemplateProps?: ITemplateMeta[];
    PredefinedProps?: Record<string, any>;
    ExpectedChildren?: Record<string, IExpectedChild>;
}
export { getElementType, getOptionInfo, ElementType, IOptionElement, IExpectedChild, IElementDescriptor, IOptionDescriptor, };
