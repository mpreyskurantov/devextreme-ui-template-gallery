/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { IOptionElement } from './react/element';
import { IConfigNode, ITemplate } from '../types';
interface NodeConfigBuilder {
    node: IConfigNode;
    configCollectionMaps: Record<string, Record<string, number>>;
    addChildNode: (name: string, childNode: IConfigNode) => void;
    addTemplate: (template: ITemplate) => void;
    getConfigCollectionData: (name: string) => [IConfigNode[], Record<string, number>];
    updateAnonymousTemplates: (hasTemplateRendered: boolean) => void;
    addCollectionNode: (name: string, collectionNode: IConfigNode, collectionNodeKey: number) => void;
    wrapTemplate: (template: ITemplate) => ITemplate;
}
declare function buildNodeFullName(node: IConfigNode): string;
declare const createConfigBuilder: (optionElement: IOptionElement, parentFullName: string) => NodeConfigBuilder;
export { buildNodeFullName, createConfigBuilder, };
