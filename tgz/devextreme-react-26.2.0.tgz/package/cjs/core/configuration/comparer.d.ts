/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { IConfigNode, ITemplate } from '../types';
interface IConfigChanges {
    options: Record<string, any>;
    removedOptions: string[];
    templates: Record<string, ITemplate>;
    addRemovedValues: (currentOptions: Record<string, any>, prevOptions: Record<string, any>, path: string) => void;
}
declare function compareValues(value1: unknown, value2: unknown): boolean;
declare function getChanges(current: IConfigNode, prev: IConfigNode): IConfigChanges;
export { getChanges, compareValues, };
