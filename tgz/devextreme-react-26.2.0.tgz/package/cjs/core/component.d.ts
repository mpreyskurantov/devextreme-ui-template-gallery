/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from 'react';
import { ReactElement } from 'react';
import type { NestedComponentMeta } from './types';
import { IHtmlOptions, ComponentBaseRef } from './component-base';
import { IElementDescriptor, IExpectedChild } from './configuration/react/element';
import { ITemplateMeta } from './template';
type ComponentProps = React.PropsWithChildren<{
    WidgetClass?: any;
    isPortalComponent?: boolean;
    defaults?: Record<string, string>;
    templateProps?: ITemplateMeta[];
    expectedChildren?: Record<string, IExpectedChild>;
    subscribableOptions?: string[];
    independentEvents?: string[];
    useRequestAnimationFrameFlag?: boolean;
    clearExtensions?: () => void;
    beforeCreateWidget?: (element?: Element) => void;
    afterCreateWidget?: (element?: Element) => void;
}>;
type ComponentRef = ComponentBaseRef & {
    clearExtensions: () => void;
};
declare const Component: <P extends IHtmlOptions>(props: P & {
    WidgetClass?: any;
    isPortalComponent?: boolean | undefined;
    defaults?: Record<string, string> | undefined;
    templateProps?: ITemplateMeta[] | undefined;
    expectedChildren?: Record<string, IExpectedChild> | undefined;
    subscribableOptions?: string[] | undefined;
    independentEvents?: string[] | undefined;
    useRequestAnimationFrameFlag?: boolean | undefined;
    clearExtensions?: (() => void) | undefined;
    beforeCreateWidget?: ((element?: Element) => void) | undefined;
    afterCreateWidget?: ((element?: Element) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<ComponentRef> | undefined;
}) => ReactElement | null;
export { Component, ComponentProps, IHtmlOptions, IElementDescriptor, ComponentRef, NestedComponentMeta, };
