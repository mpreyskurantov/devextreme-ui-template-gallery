/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import * as React from 'react';
import { ReactElement } from 'react';
import { IHtmlOptions, ComponentBaseRef } from './component-base';
import { ComponentProps, NestedComponentMeta } from './component';
type NestedOptionElement = ReactElement<any, React.JSXElementConstructor<any> & NestedComponentMeta>;
declare function elementIsExtension(el: any): el is NestedOptionElement;
declare const ExtensionComponent: <P extends IHtmlOptions>(props: P & {
    WidgetClass?: any;
    isPortalComponent?: boolean | undefined;
    defaults?: Record<string, string> | undefined;
    templateProps?: import("./template").ITemplateMeta[] | undefined;
    expectedChildren?: Record<string, import("./configuration/react/element").IExpectedChild> | undefined;
    subscribableOptions?: string[] | undefined;
    independentEvents?: string[] | undefined;
    useRequestAnimationFrameFlag?: boolean | undefined;
    clearExtensions?: (() => void) | undefined;
    beforeCreateWidget?: ((element?: Element | undefined) => void) | undefined;
    afterCreateWidget?: ((element?: Element | undefined) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<ComponentBaseRef> | undefined;
}) => ReactElement | null;
export { ExtensionComponent, elementIsExtension, };
