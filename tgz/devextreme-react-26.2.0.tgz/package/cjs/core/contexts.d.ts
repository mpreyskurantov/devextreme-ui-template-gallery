/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { Context } from 'react';
import { IExpectedChild, IOptionDescriptor } from './configuration/react/element';
import { IConfigNode, ITemplate } from './types';
export interface UpdateLocker {
    lock: () => void;
    unlock: () => void;
}
export declare const RemovalLockerContext: Context<UpdateLocker | undefined>;
export declare const RestoreTreeContext: Context<(() => void) | undefined>;
export interface NestedOptionContextContent {
    parentExpectedChildren: Record<string, IExpectedChild> | undefined;
    parentFullName: string;
    parentType: 'component' | 'option';
    onChildOptionsReady: (configNode: IConfigNode, optionDescriptor: IOptionDescriptor, childUpdateToken: symbol, optionComponentKey: number) => void;
    onNamedTemplateReady: (template: ITemplate | null, childUpdateToken: symbol) => void;
    getOptionComponentKey: () => number;
    treeUpdateToken: symbol;
}
export declare const NestedOptionContext: Context<NestedOptionContextContent>;
export interface TemplateRenderContextContent {
    isTemplateRendering?: boolean;
}
export declare const TemplateRenderingContext: Context<TemplateRenderContextContent>;
