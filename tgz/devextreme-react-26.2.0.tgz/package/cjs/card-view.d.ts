/*!
 * devextreme-react
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { ExplicitTypes } from "devextreme/ui/card_view";
import * as React from "react";
import { Ref, ReactElement } from "react";
import dxCardView, { Properties } from "devextreme/ui/card_view";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { CardClickEvent, CardDblClickEvent, CardInsertedEvent, CardInsertingEvent, CardPreparedEvent, CardRemovedEvent, CardRemovingEvent, CardUpdatedEvent, CardUpdatingEvent, ContextMenuPreparingEvent, EditCanceledEvent, EditCancelingEvent, EditingStartEvent, FieldCaptionClickEvent, FieldCaptionDblClickEvent, FieldCaptionPreparedEvent, FieldValueClickEvent, FieldValueDblClickEvent, FieldValuePreparedEvent, InitNewCardEvent, SavedEvent, SavingEvent, CardTemplateData, CardHeaderItem as CardViewCardHeaderItem, CardHeaderPredefinedItem, FieldTemplateData, ColumnTemplateData, EditingTexts as CardViewEditingTexts, PredefinedToolbarItem, dxCardViewToolbarItem } from "devextreme/ui/card_view";
import type { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from "devextreme/common/core/animation";
import type { ValidationRuleType, HorizontalAlignment, VerticalAlignment, ButtonStyle, template, ButtonType, ToolbarItemLocation, ToolbarItemComponent, SearchMode, SingleMultipleOrNone, SelectAllMode, DataType, Format as CommonFormat, SortOrder, ComparisonOperator, DragHighlight, Mode, Direction, PositionAlignment, DisplayMode, ScrollbarMode, TabsIconPosition, TabsStyle, Position as CommonPosition } from "devextreme/common";
import type { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from "devextreme/ui/button";
import type { FormItemType, FormPredefinedButtonItem, ContentReadyEvent as FormContentReadyEvent, DisposingEvent as FormDisposingEvent, InitializedEvent as FormInitializedEvent, OptionChangedEvent as FormOptionChangedEvent, dxFormSimpleItem, dxFormOptions, dxFormGroupItem, dxFormTabbedItem, dxFormEmptyItem, dxFormButtonItem, LabelLocation, FormLabelMode, EditorEnterKeyEvent, FieldDataChangedEvent, SmartPastedEvent, SmartPastingEvent, FormItemComponent } from "devextreme/ui/form";
import type { ContentReadyEvent as FilterBuilderContentReadyEvent, DisposingEvent as FilterBuilderDisposingEvent, InitializedEvent as FilterBuilderInitializedEvent, OptionChangedEvent as FilterBuilderOptionChangedEvent, dxFilterBuilderField, FieldInfo, FilterBuilderOperation, dxFilterBuilderCustomOperation, GroupOperation, EditorPreparedEvent, EditorPreparingEvent, ValueChangedEvent } from "devextreme/ui/filter_builder";
import type { ContentReadyEvent as LoadPanelContentReadyEvent, DisposingEvent as LoadPanelDisposingEvent, InitializedEvent as LoadPanelInitializedEvent, OptionChangedEvent as LoadPanelOptionChangedEvent, LoadPanelIndicatorProperties, HiddenEvent, HidingEvent, ShowingEvent, ShownEvent } from "devextreme/ui/load_panel";
import type { ContentReadyEvent as TabPanelContentReadyEvent, DisposingEvent as TabPanelDisposingEvent, InitializedEvent as TabPanelInitializedEvent, OptionChangedEvent as TabPanelOptionChangedEvent, dxTabPanelOptions, dxTabPanelItem, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, SelectionChangedEvent, SelectionChangingEvent, TitleClickEvent, TitleHoldEvent, TitleRenderedEvent } from "devextreme/ui/tab_panel";
import type { LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
import type { HeaderFilterSearchConfig, HeaderFilterTexts, SelectionColumnDisplayMode, DataChangeType, FilterType, ColumnHeaderFilter as GridsColumnHeaderFilter, ColumnChooserMode, ColumnChooserSearchConfig, ColumnChooserSelectionConfig, HeaderFilterGroupInterval, ColumnHeaderFilterSearchConfig, DataChange, FilterPanel as GridsFilterPanel, FilterPanelTexts as GridsFilterPanelTexts, PagerPageSize } from "devextreme/common/grids";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
import type { DataSourceOptions } from "devextreme/data/data_source";
import type { Store } from "devextreme/data/store";
import type { AIIntegration } from "devextreme/common/ai-integration";
import type { LoadingAnimationType } from "devextreme/ui/load_indicator";
import type { event } from "devextreme/events/events.types";
import type dxForm from "devextreme/ui/form";
import type DataSource from "devextreme/data/data_source";
import type * as CommonTypes from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ICardViewOptionsNarrowedEvents<TCardData = any, TKey = any> = {
    onCardClick?: ((e: CardClickEvent) => void);
    onCardDblClick?: ((e: CardDblClickEvent) => void);
    onCardInserted?: ((e: CardInsertedEvent<TCardData>) => void);
    onCardInserting?: ((e: CardInsertingEvent<TCardData>) => void);
    onCardPrepared?: ((e: CardPreparedEvent) => void);
    onCardRemoved?: ((e: CardRemovedEvent<TCardData, TKey>) => void);
    onCardRemoving?: ((e: CardRemovingEvent<TCardData, TKey>) => void);
    onCardUpdated?: ((e: CardUpdatedEvent<TCardData, TKey>) => void);
    onCardUpdating?: ((e: CardUpdatingEvent<TCardData, TKey>) => void);
    onContextMenuPreparing?: ((e: ContextMenuPreparingEvent<TCardData>) => void);
    onEditCanceled?: ((e: EditCanceledEvent) => void);
    onEditCanceling?: ((e: EditCancelingEvent) => void);
    onEditingStart?: ((e: EditingStartEvent<TCardData, TKey>) => void);
    onFieldCaptionClick?: ((e: FieldCaptionClickEvent) => void);
    onFieldCaptionDblClick?: ((e: FieldCaptionDblClickEvent) => void);
    onFieldCaptionPrepared?: ((e: FieldCaptionPreparedEvent) => void);
    onFieldValueClick?: ((e: FieldValueClickEvent) => void);
    onFieldValueDblClick?: ((e: FieldValueDblClickEvent) => void);
    onFieldValuePrepared?: ((e: FieldValuePreparedEvent) => void);
    onInitNewCard?: ((e: InitNewCardEvent<TCardData>) => void);
    onSaved?: ((e: SavedEvent) => void);
    onSaving?: ((e: SavingEvent) => void);
};
type ICardViewOptions<TCardData = any, TKey = any> = React.PropsWithChildren<ReplaceFieldTypes<Properties<TCardData, TKey>, ICardViewOptionsNarrowedEvents<TCardData, TKey>> & IHtmlOptions & {
    dataSource?: Properties<TCardData, TKey>["dataSource"];
    cardContentRender?: (...params: any) => React.ReactNode;
    cardContentComponent?: React.ComponentType<any>;
    cardFooterRender?: (...params: any) => React.ReactNode;
    cardFooterComponent?: React.ComponentType<any>;
    cardRender?: (...params: any) => React.ReactNode;
    cardComponent?: React.ComponentType<any>;
    noDataRender?: (...params: any) => React.ReactNode;
    noDataComponent?: React.ComponentType<any>;
    defaultFilterValue?: Array<any> | (() => any) | string;
    defaultSelectedCardKeys?: Array<any>;
    onFilterValueChange?: (value: Array<any> | (() => any) | string) => void;
    onSelectedCardKeysChange?: (value: Array<any>) => void;
}>;
interface CardViewRef<TCardData = any, TKey = any> {
    instance: () => dxCardView<TCardData, TKey>;
}
declare const CardView: <TCardData = any, TKey = any>(props: ReplaceFieldTypes<Properties<TCardData, TKey>, ICardViewOptionsNarrowedEvents<TCardData, TKey>> & IHtmlOptions & {
    dataSource?: import("devextreme/data/data_source").DataSourceLike<TCardData, TKey> | undefined;
    cardContentRender?: ((...params: any) => React.ReactNode) | undefined;
    cardContentComponent?: React.ComponentType<any> | undefined;
    cardFooterRender?: ((...params: any) => React.ReactNode) | undefined;
    cardFooterComponent?: React.ComponentType<any> | undefined;
    cardRender?: ((...params: any) => React.ReactNode) | undefined;
    cardComponent?: React.ComponentType<any> | undefined;
    noDataRender?: ((...params: any) => React.ReactNode) | undefined;
    noDataComponent?: React.ComponentType<any> | undefined;
    defaultFilterValue?: string | any[] | (() => any) | undefined;
    defaultSelectedCardKeys?: any[] | undefined;
    onFilterValueChange?: ((value: Array<any> | (() => any) | string) => void) | undefined;
    onSelectedCardKeysChange?: ((value: Array<any>) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<CardViewRef<TCardData, TKey>> | undefined;
}) => ReactElement | null;
type IAIOptionsProps = React.PropsWithChildren<{
    disabled?: boolean;
    instruction?: string | undefined;
}>;
declare const AIOptions: ((props: IAIOptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    disabled?: boolean | undefined;
    instruction?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnimationProps = React.PropsWithChildren<{
    hide?: AnimationConfig;
    show?: AnimationConfig;
}>;
declare const Animation: ((props: IAnimationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    hide?: AnimationConfig | undefined;
    show?: AnimationConfig | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAsyncRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any);
}>;
declare const AsyncRule: ((props: IAsyncRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAtProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const At: ((props: IAtProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBoundaryOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const BoundaryOffset: ((props: IBoundaryOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IButtonItemProps = React.PropsWithChildren<{
    buttonOptions?: dxButtonOptions | undefined;
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    horizontalAlignment?: HorizontalAlignment;
    itemType?: FormItemType;
    name?: FormPredefinedButtonItem | string | undefined;
    verticalAlignment?: VerticalAlignment;
    visible?: boolean;
    visibleIndex?: number | undefined;
}>;
declare const ButtonItem: ((props: IButtonItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    buttonOptions?: dxButtonOptions | undefined;
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    itemType?: FormItemType | undefined;
    name?: FormPredefinedButtonItem | string | undefined;
    verticalAlignment?: VerticalAlignment | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IButtonOptionsProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    focusStateEnabled?: boolean;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    icon?: string;
    onClick?: ((e: ClickEvent) => void) | undefined;
    onContentReady?: ((e: ContentReadyEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onOptionChanged?: ((e: OptionChangedEvent) => void);
    rtlEnabled?: boolean;
    stylingMode?: ButtonStyle;
    tabIndex?: number;
    template?: ((buttonData: {
        icon: string;
        text: string;
    }, contentElement: any) => string | any) | template;
    text?: string;
    type?: ButtonType | string;
    useSubmitBehavior?: boolean;
    validationGroup?: string | undefined;
    visible?: boolean;
    width?: number | string | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const ButtonOptions: ((props: IButtonOptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    focusStateEnabled?: boolean | undefined;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    icon?: string | undefined;
    onClick?: ((e: ClickEvent) => void) | undefined;
    onContentReady?: ((e: ContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: DisposingEvent) => void) | undefined;
    onInitialized?: ((e: InitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: OptionChangedEvent) => void) | undefined;
    rtlEnabled?: boolean | undefined;
    stylingMode?: ButtonStyle | undefined;
    tabIndex?: number | undefined;
    template?: template | ((buttonData: {
        icon: string;
        text: string;
    }, contentElement: any) => string | any) | undefined;
    text?: string | undefined;
    type?: string | undefined;
    useSubmitBehavior?: boolean | undefined;
    validationGroup?: string | undefined;
    visible?: boolean | undefined;
    width?: number | string | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardCoverProps = React.PropsWithChildren<{
    altExpr?: ((data: any) => string) | string;
    aspectRatio?: string;
    imageExpr?: ((data: any) => string) | string;
    maxHeight?: number;
    template?: ((data: CardTemplateData, container: any) => string | any) | template;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const CardCover: ((props: ICardCoverProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    altExpr?: string | ((data: any) => string) | undefined;
    aspectRatio?: string | undefined;
    imageExpr?: string | ((data: any) => string) | undefined;
    maxHeight?: number | undefined;
    template?: template | ((data: CardTemplateData, container: any) => string | any) | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardHeaderProps = React.PropsWithChildren<{
    items?: Array<CardViewCardHeaderItem | CardHeaderPredefinedItem>;
    template?: ((data: CardTemplateData) => string | any) | template;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const CardHeader: ((props: ICardHeaderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    items?: (CardViewCardHeaderItem | CardHeaderPredefinedItem)[] | undefined;
    template?: template | ((data: CardTemplateData) => string | any) | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardHeaderItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    name?: CardHeaderPredefinedItem | string;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const CardHeaderItem: ((props: ICardHeaderItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    name?: string | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardViewHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    height?: number | string;
    search?: HeaderFilterSearchConfig;
    searchTimeout?: number;
    texts?: HeaderFilterTexts;
    visible?: boolean;
    width?: number | string;
}>;
declare const CardViewHeaderFilter: ((props: ICardViewHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    height?: string | number | undefined;
    search?: HeaderFilterSearchConfig | undefined;
    searchTimeout?: number | undefined;
    texts?: HeaderFilterTexts | undefined;
    visible?: boolean | undefined;
    width?: string | number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardViewHeaderFilterSearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    timeout?: number;
}>;
declare const CardViewHeaderFilterSearch: ((props: ICardViewHeaderFilterSearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardViewHeaderFilterTextsProps = React.PropsWithChildren<{
    cancel?: string;
    emptyValue?: string;
    ok?: string;
}>;
declare const CardViewHeaderFilterTexts: ((props: ICardViewHeaderFilterTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cancel?: string | undefined;
    emptyValue?: string | undefined;
    ok?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardViewSelectionProps = React.PropsWithChildren<{
    allowSelectAll?: boolean;
    mode?: SingleMultipleOrNone;
    selectAllMode?: SelectAllMode;
    showCheckBoxesMode?: SelectionColumnDisplayMode;
}>;
declare const CardViewSelection: ((props: ICardViewSelectionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSelectAll?: boolean | undefined;
    mode?: SingleMultipleOrNone | undefined;
    selectAllMode?: SelectAllMode | undefined;
    showCheckBoxesMode?: SelectionColumnDisplayMode | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IChangeProps = React.PropsWithChildren<{
    data?: any;
    insertAfterKey?: any;
    insertBeforeKey?: any;
    key?: any;
    type?: DataChangeType;
}>;
declare const Change: ((props: IChangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    data?: any;
    insertAfterKey?: any;
    insertBeforeKey?: any;
    key?: any;
    type?: DataChangeType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColCountByScreenProps = React.PropsWithChildren<{
    lg?: number | undefined;
    md?: number | undefined;
    sm?: number | undefined;
    xs?: number | undefined;
}>;
declare const ColCountByScreen: ((props: IColCountByScreenProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    lg?: number | undefined;
    md?: number | undefined;
    sm?: number | undefined;
    xs?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICollisionProps = React.PropsWithChildren<{
    x?: CollisionResolution;
    y?: CollisionResolution;
}>;
declare const Collision: ((props: ICollisionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: CollisionResolution | undefined;
    y?: CollisionResolution | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    allowEditing?: boolean;
    allowFiltering?: boolean;
    allowHeaderFiltering?: boolean;
    allowHiding?: boolean;
    allowReordering?: boolean;
    allowSearch?: boolean;
    allowSorting?: boolean;
    calculateDisplayValue?: ((cardData: any) => any);
    calculateFieldValue?: ((cardData: any) => any);
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Array<any> | (() => void));
    calculateSortValue?: ((cardData: any) => any) | string;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string);
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editorOptions?: any;
    falseText?: string;
    fieldCaptionTemplate?: ((data: FieldTemplateData, container: any) => string | any) | template;
    fieldTemplate?: ((data: FieldTemplateData, container: any) => string | any) | template;
    fieldValueTemplate?: ((data: FieldTemplateData, container: any) => string | any) | template;
    filterType?: FilterType;
    filterValue?: any | undefined;
    filterValues?: Array<any>;
    format?: LocalizationFormat;
    formItem?: dxFormSimpleItem;
    headerFilter?: GridsColumnHeaderFilter | undefined;
    headerItemCssClass?: string;
    headerItemTemplate?: ((data: ColumnTemplateData, container: any) => string | any) | template;
    name?: string | undefined;
    setFieldValue?: ((newData: any, value: any, currentCardData: any) => any);
    showInColumnChooser?: boolean;
    sortIndex?: number | undefined;
    sortingMethod?: ((value1: any, value2: any) => number) | undefined;
    sortOrder?: SortOrder | undefined;
    trueText?: string;
    validationRules?: Array<CommonTypes.ValidationRule>;
    visible?: boolean;
    visibleIndex?: number | undefined;
    defaultFilterValue?: any | undefined;
    onFilterValueChange?: (value: any | undefined) => void;
    defaultFilterValues?: Array<any>;
    onFilterValuesChange?: (value: Array<any>) => void;
    defaultSortIndex?: number | undefined;
    onSortIndexChange?: (value: number | undefined) => void;
    defaultSortOrder?: SortOrder | undefined;
    onSortOrderChange?: (value: SortOrder | undefined) => void;
    defaultVisible?: boolean;
    onVisibleChange?: (value: boolean) => void;
    defaultVisibleIndex?: number | undefined;
    onVisibleIndexChange?: (value: number | undefined) => void;
    fieldCaptionRender?: (...params: any) => React.ReactNode;
    fieldCaptionComponent?: React.ComponentType<any>;
    fieldRender?: (...params: any) => React.ReactNode;
    fieldComponent?: React.ComponentType<any>;
    fieldValueRender?: (...params: any) => React.ReactNode;
    fieldValueComponent?: React.ComponentType<any>;
    headerItemRender?: (...params: any) => React.ReactNode;
    headerItemComponent?: React.ComponentType<any>;
}>;
declare const Column: ((props: IColumnProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    allowEditing?: boolean | undefined;
    allowFiltering?: boolean | undefined;
    allowHeaderFiltering?: boolean | undefined;
    allowHiding?: boolean | undefined;
    allowReordering?: boolean | undefined;
    allowSearch?: boolean | undefined;
    allowSorting?: boolean | undefined;
    calculateDisplayValue?: ((cardData: any) => any) | undefined;
    calculateFieldValue?: ((cardData: any) => any) | undefined;
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Array<any> | (() => void)) | undefined;
    calculateSortValue?: string | ((cardData: any) => any) | undefined;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string) | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editorOptions?: any;
    falseText?: string | undefined;
    fieldCaptionTemplate?: template | ((data: FieldTemplateData, container: any) => string | any) | undefined;
    fieldTemplate?: template | ((data: FieldTemplateData, container: any) => string | any) | undefined;
    fieldValueTemplate?: template | ((data: FieldTemplateData, container: any) => string | any) | undefined;
    filterType?: FilterType | undefined;
    filterValue?: any | undefined;
    filterValues?: any[] | undefined;
    format?: LocalizationFormat;
    formItem?: dxFormSimpleItem | undefined;
    headerFilter?: GridsColumnHeaderFilter | undefined;
    headerItemCssClass?: string | undefined;
    headerItemTemplate?: template | ((data: ColumnTemplateData, container: any) => string | any) | undefined;
    name?: string | undefined;
    setFieldValue?: ((newData: any, value: any, currentCardData: any) => any) | undefined;
    showInColumnChooser?: boolean | undefined;
    sortIndex?: number | undefined;
    sortingMethod?: ((value1: any, value2: any) => number) | undefined;
    sortOrder?: SortOrder | undefined;
    trueText?: string | undefined;
    validationRules?: CommonTypes.ValidationRule[] | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    defaultFilterValue?: any | undefined;
    onFilterValueChange?: ((value: any | undefined) => void) | undefined;
    defaultFilterValues?: any[] | undefined;
    onFilterValuesChange?: ((value: Array<any>) => void) | undefined;
    defaultSortIndex?: number | undefined;
    onSortIndexChange?: ((value: number | undefined) => void) | undefined;
    defaultSortOrder?: SortOrder | undefined;
    onSortOrderChange?: ((value: SortOrder | undefined) => void) | undefined;
    defaultVisible?: boolean | undefined;
    onVisibleChange?: ((value: boolean) => void) | undefined;
    defaultVisibleIndex?: number | undefined;
    onVisibleIndexChange?: ((value: number | undefined) => void) | undefined;
    fieldCaptionRender?: ((...params: any) => React.ReactNode) | undefined;
    fieldCaptionComponent?: React.ComponentType<any> | undefined;
    fieldRender?: ((...params: any) => React.ReactNode) | undefined;
    fieldComponent?: React.ComponentType<any> | undefined;
    fieldValueRender?: ((...params: any) => React.ReactNode) | undefined;
    fieldValueComponent?: React.ComponentType<any> | undefined;
    headerItemRender?: ((...params: any) => React.ReactNode) | undefined;
    headerItemComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnChooserProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    container?: any | string | undefined;
    emptyPanelText?: string;
    enabled?: boolean;
    height?: number | string;
    mode?: ColumnChooserMode;
    position?: PositionConfig | undefined;
    search?: ColumnChooserSearchConfig;
    searchTimeout?: number;
    selection?: ColumnChooserSelectionConfig;
    sortOrder?: SortOrder | undefined;
    title?: string;
    width?: number | string;
}>;
declare const ColumnChooser: ((props: IColumnChooserProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    container?: any | string | undefined;
    emptyPanelText?: string | undefined;
    enabled?: boolean | undefined;
    height?: string | number | undefined;
    mode?: ColumnChooserMode | undefined;
    position?: PositionConfig | undefined;
    search?: ColumnChooserSearchConfig | undefined;
    searchTimeout?: number | undefined;
    selection?: ColumnChooserSelectionConfig | undefined;
    sortOrder?: SortOrder | undefined;
    title?: string | undefined;
    width?: string | number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnChooserSearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    timeout?: number;
}>;
declare const ColumnChooserSearch: ((props: IColumnChooserSearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnChooserSelectionProps = React.PropsWithChildren<{
    allowSelectAll?: boolean;
    recursive?: boolean;
    selectByClick?: boolean;
}>;
declare const ColumnChooserSelection: ((props: IColumnChooserSelectionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSelectAll?: boolean | undefined;
    recursive?: boolean | undefined;
    selectByClick?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    dataSource?: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    groupInterval?: Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: ColumnHeaderFilterSearchConfig;
    searchMode?: SearchMode;
    width?: number | string | undefined;
}>;
declare const ColumnHeaderFilter: ((props: IColumnHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | undefined;
    groupInterval?: Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: ColumnHeaderFilterSearchConfig | undefined;
    searchMode?: SearchMode | undefined;
    width?: number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnHeaderFilterSearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number;
}>;
declare const ColumnHeaderFilterSearch: ((props: IColumnHeaderFilterSearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICompareRuleProps = React.PropsWithChildren<{
    comparisonTarget?: (() => any);
    comparisonType?: ComparisonOperator;
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const CompareRule: ((props: ICompareRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    comparisonTarget?: (() => any) | undefined;
    comparisonType?: ComparisonOperator | undefined;
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICustomOperationProps = React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>);
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string);
    dataTypes?: Array<DataType> | undefined;
    editorTemplate?: ((conditionInfo: {
        field: dxFilterBuilderField;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | template;
    hasValue?: boolean;
    icon?: string | undefined;
    name?: string | undefined;
    editorRender?: (...params: any) => React.ReactNode;
    editorComponent?: React.ComponentType<any>;
}>;
declare const CustomOperation: ((props: ICustomOperationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>) | undefined;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string) | undefined;
    dataTypes?: Array<DataType> | undefined;
    editorTemplate?: template | ((conditionInfo: {
        field: dxFilterBuilderField;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | undefined;
    hasValue?: boolean | undefined;
    icon?: string | undefined;
    name?: string | undefined;
    editorRender?: ((...params: any) => React.ReactNode) | undefined;
    editorComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICustomRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
}>;
declare const CustomRule: ((props: ICustomRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDraggingProps = React.PropsWithChildren<{
    dropFeedbackMode?: DragHighlight;
    onDragChange?: ((e: any) => void);
    onDragEnd?: ((e: any) => void);
    onDragMove?: ((e: any) => void);
    onDragStart?: ((e: any) => void);
    onRemove?: ((e: any) => void);
    onReorder?: ((e: any) => void);
    scrollSensitivity?: number;
    scrollSpeed?: number;
}>;
declare const Dragging: ((props: IDraggingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    dropFeedbackMode?: DragHighlight | undefined;
    onDragChange?: ((e: any) => void) | undefined;
    onDragEnd?: ((e: any) => void) | undefined;
    onDragMove?: ((e: any) => void) | undefined;
    onDragStart?: ((e: any) => void) | undefined;
    onRemove?: ((e: any) => void) | undefined;
    onReorder?: ((e: any) => void) | undefined;
    scrollSensitivity?: number | undefined;
    scrollSpeed?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEditingProps = React.PropsWithChildren<{
    allowAdding?: boolean;
    allowDeleting?: boolean;
    allowUpdating?: boolean;
    changes?: Array<DataChange>;
    confirmDelete?: boolean;
    editCardKey?: any;
    form?: dxFormOptions;
    popup?: Record<string, any>;
    texts?: CardViewEditingTexts;
}>;
declare const Editing: ((props: IEditingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowAdding?: boolean | undefined;
    allowDeleting?: boolean | undefined;
    allowUpdating?: boolean | undefined;
    changes?: DataChange<any, any>[] | undefined;
    confirmDelete?: boolean | undefined;
    editCardKey?: any;
    form?: dxFormOptions | undefined;
    popup?: Record<string, any> | undefined;
    texts?: CardViewEditingTexts | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEditingTextsProps = React.PropsWithChildren<{
    addCard?: string;
    confirmDeleteMessage?: string;
    confirmDeleteTitle?: string;
    deleteCard?: string;
    editCard?: string;
    saveCard?: string;
}>;
declare const EditingTexts: ((props: IEditingTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    addCard?: string | undefined;
    confirmDeleteMessage?: string | undefined;
    confirmDeleteTitle?: string | undefined;
    deleteCard?: string | undefined;
    editCard?: string | undefined;
    saveCard?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEmailRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const EmailRule: ((props: IEmailRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEmptyItemProps = React.PropsWithChildren<{
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    itemType?: FormItemType;
    name?: string | undefined;
    visible?: boolean;
    visibleIndex?: number | undefined;
}>;
declare const EmptyItem: ((props: IEmptyItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    itemType?: FormItemType | undefined;
    name?: string | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFieldProps = React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>);
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string);
    dataField?: string | undefined;
    dataType?: DataType;
    editorOptions?: any;
    editorTemplate?: ((conditionInfo: {
        field: dxFilterBuilderField;
        filterOperation: string;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | template;
    falseText?: string;
    filterOperations?: Array<FilterBuilderOperation | string>;
    format?: LocalizationFormat;
    lookup?: Record<string, any> | {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    };
    name?: string | undefined;
    trueText?: string;
    editorRender?: (...params: any) => React.ReactNode;
    editorComponent?: React.ComponentType<any>;
}>;
declare const Field: ((props: IFieldProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>) | undefined;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string) | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editorOptions?: any;
    editorTemplate?: template | ((conditionInfo: {
        field: dxFilterBuilderField;
        filterOperation: string;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | undefined;
    falseText?: string | undefined;
    filterOperations?: string[] | undefined;
    format?: LocalizationFormat;
    lookup?: Record<string, any> | {
        allowClearing?: boolean | undefined;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: string | ((data: any) => string) | undefined;
        valueExpr?: string | ((data: any) => string | number | boolean) | undefined;
    } | undefined;
    name?: string | undefined;
    trueText?: string | undefined;
    editorRender?: ((...params: any) => React.ReactNode) | undefined;
    editorComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterBuilderProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    allowHierarchicalFields?: boolean;
    customOperations?: Array<dxFilterBuilderCustomOperation>;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    fields?: Array<dxFilterBuilderField>;
    filterOperationDescriptions?: Record<string, any> | {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    focusStateEnabled?: boolean;
    groupOperationDescriptions?: Record<string, any> | {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    };
    groupOperations?: Array<GroupOperation>;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    maxGroupLevel?: number | undefined;
    onContentReady?: ((e: FilterBuilderContentReadyEvent) => void);
    onDisposing?: ((e: FilterBuilderDisposingEvent) => void);
    onEditorPrepared?: ((e: EditorPreparedEvent) => void) | undefined;
    onEditorPreparing?: ((e: EditorPreparingEvent) => void) | undefined;
    onInitialized?: ((e: FilterBuilderInitializedEvent) => void);
    onOptionChanged?: ((e: FilterBuilderOptionChangedEvent) => void);
    onValueChanged?: ((e: ValueChangedEvent) => void) | undefined;
    rtlEnabled?: boolean;
    tabIndex?: number;
    value?: Array<any> | (() => any) | string;
    visible?: boolean;
    width?: number | string | undefined;
    defaultValue?: Array<any> | (() => any) | string;
    onValueChange?: (value: Array<any> | (() => any) | string) => void;
}>;
declare const FilterBuilder: ((props: IFilterBuilderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    allowHierarchicalFields?: boolean | undefined;
    customOperations?: dxFilterBuilderCustomOperation[] | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    fields?: dxFilterBuilderField[] | undefined;
    filterOperationDescriptions?: Record<string, any> | {
        between?: string | undefined;
        contains?: string | undefined;
        endsWith?: string | undefined;
        equal?: string | undefined;
        greaterThan?: string | undefined;
        greaterThanOrEqual?: string | undefined;
        isBlank?: string | undefined;
        isNotBlank?: string | undefined;
        lessThan?: string | undefined;
        lessThanOrEqual?: string | undefined;
        notContains?: string | undefined;
        notEqual?: string | undefined;
        startsWith?: string | undefined;
    } | undefined;
    focusStateEnabled?: boolean | undefined;
    groupOperationDescriptions?: Record<string, any> | {
        and?: string | undefined;
        notAnd?: string | undefined;
        notOr?: string | undefined;
        or?: string | undefined;
    } | undefined;
    groupOperations?: GroupOperation[] | undefined;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    maxGroupLevel?: number | undefined;
    onContentReady?: ((e: FilterBuilderContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: FilterBuilderDisposingEvent) => void) | undefined;
    onEditorPrepared?: ((e: EditorPreparedEvent) => void) | undefined;
    onEditorPreparing?: ((e: EditorPreparingEvent) => void) | undefined;
    onInitialized?: ((e: FilterBuilderInitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: FilterBuilderOptionChangedEvent) => void) | undefined;
    onValueChanged?: ((e: ValueChangedEvent) => void) | undefined;
    rtlEnabled?: boolean | undefined;
    tabIndex?: number | undefined;
    value?: string | any[] | (() => any) | undefined;
    visible?: boolean | undefined;
    width?: number | string | undefined;
    defaultValue?: string | any[] | (() => any) | undefined;
    onValueChange?: ((value: Array<any> | (() => any) | string) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterOperationDescriptionsProps = React.PropsWithChildren<{
    between?: string;
    contains?: string;
    endsWith?: string;
    equal?: string;
    greaterThan?: string;
    greaterThanOrEqual?: string;
    isBlank?: string;
    isNotBlank?: string;
    lessThan?: string;
    lessThanOrEqual?: string;
    notContains?: string;
    notEqual?: string;
    startsWith?: string;
}>;
declare const FilterOperationDescriptions: ((props: IFilterOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    between?: string | undefined;
    contains?: string | undefined;
    endsWith?: string | undefined;
    equal?: string | undefined;
    greaterThan?: string | undefined;
    greaterThanOrEqual?: string | undefined;
    isBlank?: string | undefined;
    isNotBlank?: string | undefined;
    lessThan?: string | undefined;
    lessThanOrEqual?: string | undefined;
    notContains?: string | undefined;
    notEqual?: string | undefined;
    startsWith?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterPanelProps = React.PropsWithChildren<{
    customizeText?: ((e: {
        component: GridsFilterPanel;
        filterValue: Record<string, any>;
        text: string;
    }) => string);
    filterEnabled?: boolean;
    texts?: GridsFilterPanelTexts;
    visible?: boolean;
    defaultFilterEnabled?: boolean;
    onFilterEnabledChange?: (value: boolean) => void;
}>;
declare const FilterPanel: ((props: IFilterPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customizeText?: ((e: {
        component: GridsFilterPanel;
        filterValue: Record<string, any>;
        text: string;
    }) => string) | undefined;
    filterEnabled?: boolean | undefined;
    texts?: GridsFilterPanelTexts | undefined;
    visible?: boolean | undefined;
    defaultFilterEnabled?: boolean | undefined;
    onFilterEnabledChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterPanelTextsProps = React.PropsWithChildren<{
    clearFilter?: string;
    createFilter?: string;
    filterEnabledHint?: string;
}>;
declare const FilterPanelTexts: ((props: IFilterPanelTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    clearFilter?: string | undefined;
    createFilter?: string | undefined;
    filterEnabledHint?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    aiIntegration?: AIIntegration | undefined;
    alignItemLabels?: boolean;
    alignItemLabelsInAllGroups?: boolean;
    colCount?: Mode | number;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    customizeItem?: ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void);
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    focusStateEnabled?: boolean;
    formData?: any;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    isDirty?: boolean;
    items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    labelLocation?: LabelLocation;
    labelMode?: FormLabelMode;
    minColWidth?: number;
    onContentReady?: ((e: FormContentReadyEvent) => void);
    onDisposing?: ((e: FormDisposingEvent) => void);
    onEditorEnterKey?: ((e: EditorEnterKeyEvent) => void) | undefined;
    onFieldDataChanged?: ((e: FieldDataChangedEvent) => void) | undefined;
    onInitialized?: ((e: FormInitializedEvent) => void);
    onOptionChanged?: ((e: FormOptionChangedEvent) => void);
    onSmartPasted?: ((e: SmartPastedEvent) => void) | undefined;
    onSmartPasting?: ((e: SmartPastingEvent) => void) | undefined;
    optionalMark?: string;
    readOnly?: boolean;
    requiredMark?: string;
    requiredMessage?: string;
    rtlEnabled?: boolean;
    screenByWidth?: (() => void);
    scrollingEnabled?: boolean;
    showColonAfterLabel?: boolean;
    showOptionalMark?: boolean;
    showRequiredMark?: boolean;
    showValidationSummary?: boolean;
    tabIndex?: number;
    validationGroup?: string | undefined;
    visible?: boolean;
    width?: number | string | undefined;
    defaultFormData?: any;
    onFormDataChange?: (value: any) => void;
}>;
declare const Form: ((props: IFormProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    aiIntegration?: AIIntegration | undefined;
    alignItemLabels?: boolean | undefined;
    alignItemLabelsInAllGroups?: boolean | undefined;
    colCount?: number | "auto" | undefined;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    } | undefined;
    customizeItem?: ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void) | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    focusStateEnabled?: boolean | undefined;
    formData?: any;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    isDirty?: boolean | undefined;
    items?: (dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem)[] | undefined;
    labelLocation?: LabelLocation | undefined;
    labelMode?: FormLabelMode | undefined;
    minColWidth?: number | undefined;
    onContentReady?: ((e: FormContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: FormDisposingEvent) => void) | undefined;
    onEditorEnterKey?: ((e: EditorEnterKeyEvent) => void) | undefined;
    onFieldDataChanged?: ((e: FieldDataChangedEvent) => void) | undefined;
    onInitialized?: ((e: FormInitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: FormOptionChangedEvent) => void) | undefined;
    onSmartPasted?: ((e: SmartPastedEvent) => void) | undefined;
    onSmartPasting?: ((e: SmartPastingEvent) => void) | undefined;
    optionalMark?: string | undefined;
    readOnly?: boolean | undefined;
    requiredMark?: string | undefined;
    requiredMessage?: string | undefined;
    rtlEnabled?: boolean | undefined;
    screenByWidth?: (() => void) | undefined;
    scrollingEnabled?: boolean | undefined;
    showColonAfterLabel?: boolean | undefined;
    showOptionalMark?: boolean | undefined;
    showRequiredMark?: boolean | undefined;
    showValidationSummary?: boolean | undefined;
    tabIndex?: number | undefined;
    validationGroup?: string | undefined;
    visible?: boolean | undefined;
    width?: number | string | undefined;
    defaultFormData?: any;
    onFormDataChange?: ((value: any) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormItemProps = React.PropsWithChildren<{
    aiOptions?: Record<string, any> | {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | template;
        text?: string | undefined;
        visible?: boolean;
    };
    name?: string | undefined;
    template?: ((data: {
        component: dxForm;
        dataField: string;
        editorOptions: Record<string, any>;
        editorType: string;
        name: string;
    }, itemElement: any) => string | any) | template;
    validationRules?: Array<CommonTypes.ValidationRule>;
    visible?: boolean;
    visibleIndex?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const FormItem: ((props: IFormItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aiOptions?: Record<string, any> | {
        disabled?: boolean | undefined;
        instruction?: string | undefined;
    } | undefined;
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent | undefined;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        location?: LabelLocation | undefined;
        showColon?: boolean | undefined;
        template?: template | ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | undefined;
        text?: string | undefined;
        visible?: boolean | undefined;
    } | undefined;
    name?: string | undefined;
    template?: template | ((data: {
        component: dxForm;
        dataField: string;
        editorOptions: Record<string, any>;
        editorType: string;
        name: string;
    }, itemElement: any) => string | any) | undefined;
    validationRules?: CommonTypes.ValidationRule[] | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFromProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const From: ((props: IFromProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupItemProps = React.PropsWithChildren<{
    alignItemLabels?: boolean;
    caption?: string | undefined;
    captionTemplate?: ((data: {
        caption: string;
        component: dxForm;
        name: string;
    }, itemElement: any) => string | any) | template;
    colCount?: number;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    itemType?: FormItemType;
    name?: string | undefined;
    template?: ((data: {
        component: dxForm;
        formData: Record<string, any>;
    }, itemElement: any) => string | any) | template;
    visible?: boolean;
    visibleIndex?: number | undefined;
    captionRender?: (...params: any) => React.ReactNode;
    captionComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const GroupItem: ((props: IGroupItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignItemLabels?: boolean | undefined;
    caption?: string | undefined;
    captionTemplate?: template | ((data: {
        caption: string;
        component: dxForm;
        name: string;
    }, itemElement: any) => string | any) | undefined;
    colCount?: number | undefined;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    } | undefined;
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    items?: (dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem)[] | undefined;
    itemType?: FormItemType | undefined;
    name?: string | undefined;
    template?: template | ((data: {
        component: dxForm;
        formData: Record<string, any>;
    }, itemElement: any) => string | any) | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    captionRender?: ((...params: any) => React.ReactNode) | undefined;
    captionComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupOperationDescriptionsProps = React.PropsWithChildren<{
    and?: string;
    notAnd?: string;
    notOr?: string;
    or?: string;
}>;
declare const GroupOperationDescriptions: ((props: IGroupOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    and?: string | undefined;
    notAnd?: string | undefined;
    notOr?: string | undefined;
    or?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    dataSource?: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    groupInterval?: Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig;
    searchMode?: SearchMode;
    width?: number | string | undefined;
    searchTimeout?: number;
    texts?: HeaderFilterTexts;
    visible?: boolean;
}>;
declare const HeaderFilter: ((props: IHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | undefined;
    groupInterval?: Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: HeaderFilterSearchConfig | ColumnHeaderFilterSearchConfig | undefined;
    searchMode?: SearchMode | undefined;
    width?: number | string | undefined;
    searchTimeout?: number | undefined;
    texts?: HeaderFilterTexts | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeaderPanelProps = React.PropsWithChildren<{
    dragging?: Record<string, any> | {
        dropFeedbackMode?: DragHighlight;
        onDragChange?: ((e: any) => void);
        onDragEnd?: ((e: any) => void);
        onDragMove?: ((e: any) => void);
        onDragStart?: ((e: any) => void);
        onRemove?: ((e: any) => void);
        onReorder?: ((e: any) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
    };
    itemCssClass?: string;
    itemTemplate?: ((data: ColumnTemplateData, container: any) => string | any) | template;
    visible?: boolean;
    itemRender?: (...params: any) => React.ReactNode;
    itemComponent?: React.ComponentType<any>;
}>;
declare const HeaderPanel: ((props: IHeaderPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    dragging?: Record<string, any> | {
        dropFeedbackMode?: DragHighlight | undefined;
        onDragChange?: ((e: any) => void) | undefined;
        onDragEnd?: ((e: any) => void) | undefined;
        onDragMove?: ((e: any) => void) | undefined;
        onDragStart?: ((e: any) => void) | undefined;
        onRemove?: ((e: any) => void) | undefined;
        onReorder?: ((e: any) => void) | undefined;
        scrollSensitivity?: number | undefined;
        scrollSpeed?: number | undefined;
    } | undefined;
    itemCssClass?: string | undefined;
    itemTemplate?: template | ((data: ColumnTemplateData, container: any) => string | any) | undefined;
    visible?: boolean | undefined;
    itemRender?: ((...params: any) => React.ReactNode) | undefined;
    itemComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHideProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Hide: ((props: IHideProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IIndicatorOptionsProps = React.PropsWithChildren<{
    animationType?: LoadingAnimationType;
    height?: number | string | undefined;
    src?: string;
    width?: number | string | undefined;
}>;
declare const IndicatorOptions: ((props: IIndicatorOptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    animationType?: LoadingAnimationType | undefined;
    height?: number | string | undefined;
    src?: string | undefined;
    width?: number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    name?: CardHeaderPredefinedItem | string | undefined | FormPredefinedButtonItem | PredefinedToolbarItem;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    badge?: string;
    icon?: string;
    tabTemplate?: (() => string | any) | template;
    title?: string;
    aiOptions?: Record<string, any> | {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    colSpan?: number | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | template;
        text?: string | undefined;
        visible?: boolean;
    };
    validationRules?: Array<CommonTypes.ValidationRule>;
    visibleIndex?: number | undefined;
    alignItemLabels?: boolean;
    caption?: string | undefined;
    captionTemplate?: ((data: {
        caption: string;
        component: dxForm;
        name: string;
    }, itemElement: any) => string | any) | template;
    colCount?: number;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    tabPanelOptions?: dxTabPanelOptions | undefined;
    tabs?: Array<Record<string, any>> | {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: Record<string, any> | {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: ((tabData: any, tabIndex: number, tabElement: any) => any) | template | undefined;
        template?: ((tabData: any, tabIndex: number, tabElement: any) => any) | template | undefined;
        title?: string | undefined;
    }[];
    buttonOptions?: dxButtonOptions | undefined;
    horizontalAlignment?: HorizontalAlignment;
    verticalAlignment?: VerticalAlignment;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    tabRender?: (...params: any) => React.ReactNode;
    tabComponent?: React.ComponentType<any>;
    captionRender?: (...params: any) => React.ReactNode;
    captionComponent?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    name?: CardHeaderPredefinedItem | string | undefined | FormPredefinedButtonItem | PredefinedToolbarItem;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    badge?: string | undefined;
    icon?: string | undefined;
    tabTemplate?: template | (() => string | any) | undefined;
    title?: string | undefined;
    aiOptions?: Record<string, any> | {
        disabled?: boolean | undefined;
        instruction?: string | undefined;
    } | undefined;
    colSpan?: number | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent | undefined;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        location?: LabelLocation | undefined;
        showColon?: boolean | undefined;
        template?: template | ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | undefined;
        text?: string | undefined;
        visible?: boolean | undefined;
    } | undefined;
    validationRules?: CommonTypes.ValidationRule[] | undefined;
    visibleIndex?: number | undefined;
    alignItemLabels?: boolean | undefined;
    caption?: string | undefined;
    captionTemplate?: template | ((data: {
        caption: string;
        component: dxForm;
        name: string;
    }, itemElement: any) => string | any) | undefined;
    colCount?: number | undefined;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    } | undefined;
    items?: (dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem)[] | undefined;
    tabPanelOptions?: dxTabPanelOptions | undefined;
    tabs?: Record<string, any>[] | {
        alignItemLabels?: boolean | undefined;
        badge?: string | undefined;
        colCount?: number | undefined;
        colCountByScreen?: Record<string, any> | {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        } | undefined;
        disabled?: boolean | undefined;
        icon?: string | undefined;
        items?: (dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem)[] | undefined;
        tabTemplate?: template | ((tabData: any, tabIndex: number, tabElement: any) => any) | undefined;
        template?: template | ((tabData: any, tabIndex: number, tabElement: any) => any) | undefined;
        title?: string | undefined;
    }[] | undefined;
    buttonOptions?: dxButtonOptions | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    verticalAlignment?: VerticalAlignment | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    tabRender?: ((...params: any) => React.ReactNode) | undefined;
    tabComponent?: React.ComponentType<any> | undefined;
    captionRender?: ((...params: any) => React.ReactNode) | undefined;
    captionComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment;
    location?: LabelLocation;
    showColon?: boolean;
    template?: ((itemData: {
        component: dxForm;
        dataField: string;
        editorOptions: any;
        editorType: string;
        name: string;
        text: string;
    }, itemElement: any) => string | any) | template;
    text?: string | undefined;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    location?: LabelLocation | undefined;
    showColon?: boolean | undefined;
    template?: template | ((itemData: {
        component: dxForm;
        dataField: string;
        editorOptions: any;
        editorType: string;
        name: string;
        text: string;
    }, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadPanelProps = React.PropsWithChildren<{
    animation?: Record<string, any> | {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    container?: any | string | undefined;
    deferRendering?: boolean;
    delay?: number;
    focusStateEnabled?: boolean;
    height?: number | string;
    hideOnOutsideClick?: boolean | ((event: event) => boolean);
    hideOnParentScroll?: boolean;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    indicatorOptions?: LoadPanelIndicatorProperties;
    indicatorSrc?: string;
    maxHeight?: number | string;
    maxWidth?: number | string;
    message?: string;
    minHeight?: number | string;
    minWidth?: number | string;
    onContentReady?: ((e: LoadPanelContentReadyEvent) => void);
    onDisposing?: ((e: LoadPanelDisposingEvent) => void);
    onHidden?: ((e: HiddenEvent) => void);
    onHiding?: ((e: HidingEvent) => void);
    onInitialized?: ((e: LoadPanelInitializedEvent) => void);
    onOptionChanged?: ((e: LoadPanelOptionChangedEvent) => void);
    onShowing?: ((e: ShowingEvent) => void);
    onShown?: ((e: ShownEvent) => void);
    position?: (() => void) | PositionAlignment | PositionConfig;
    rtlEnabled?: boolean;
    shading?: boolean;
    shadingColor?: string;
    showIndicator?: boolean;
    showPane?: boolean;
    visible?: boolean;
    width?: number | string;
    wrapperAttr?: any;
    defaultPosition?: (() => void) | PositionAlignment | PositionConfig;
    onPositionChange?: (value: (() => void) | PositionAlignment | PositionConfig) => void;
    defaultVisible?: boolean;
    onVisibleChange?: (value: boolean) => void;
}>;
declare const LoadPanel: ((props: ILoadPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    animation?: Record<string, any> | {
        hide?: AnimationConfig | undefined;
        show?: AnimationConfig | undefined;
    } | undefined;
    container?: any | string | undefined;
    deferRendering?: boolean | undefined;
    delay?: number | undefined;
    focusStateEnabled?: boolean | undefined;
    height?: string | number | undefined;
    hideOnOutsideClick?: boolean | ((event: event) => boolean) | undefined;
    hideOnParentScroll?: boolean | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    indicatorOptions?: LoadPanelIndicatorProperties | undefined;
    indicatorSrc?: string | undefined;
    maxHeight?: string | number | undefined;
    maxWidth?: string | number | undefined;
    message?: string | undefined;
    minHeight?: string | number | undefined;
    minWidth?: string | number | undefined;
    onContentReady?: ((e: LoadPanelContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: LoadPanelDisposingEvent) => void) | undefined;
    onHidden?: ((e: HiddenEvent) => void) | undefined;
    onHiding?: ((e: HidingEvent) => void) | undefined;
    onInitialized?: ((e: LoadPanelInitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: LoadPanelOptionChangedEvent) => void) | undefined;
    onShowing?: ((e: ShowingEvent) => void) | undefined;
    onShown?: ((e: ShownEvent) => void) | undefined;
    position?: PositionConfig | PositionAlignment | (() => void) | undefined;
    rtlEnabled?: boolean | undefined;
    shading?: boolean | undefined;
    shadingColor?: string | undefined;
    showIndicator?: boolean | undefined;
    showPane?: boolean | undefined;
    visible?: boolean | undefined;
    width?: string | number | undefined;
    wrapperAttr?: any;
    defaultPosition?: PositionConfig | PositionAlignment | (() => void) | undefined;
    onPositionChange?: ((value: (() => void) | PositionAlignment | PositionConfig) => void) | undefined;
    defaultVisible?: boolean | undefined;
    onVisibleChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILookupProps = React.PropsWithChildren<{
    allowClearing?: boolean;
    dataSource?: Array<any> | DataSourceOptions | Store | undefined;
    displayExpr?: ((data: any) => string) | string | undefined;
    valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
}>;
declare const Lookup: ((props: ILookupProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowClearing?: boolean | undefined;
    dataSource?: Array<any> | DataSourceOptions | Store | undefined;
    displayExpr?: string | ((data: any) => string) | undefined;
    valueExpr?: string | ((data: any) => string | number | boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMyProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const My: ((props: IMyProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type INumericRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const NumericRule: ((props: INumericRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const Offset: ((props: IOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPagerProps = React.PropsWithChildren<{
    allowedPageSizes?: Array<number | PagerPageSize> | Mode;
    displayMode?: DisplayMode;
    infoText?: string;
    label?: string;
    showInfo?: boolean;
    showNavigationButtons?: boolean;
    showPageSizeSelector?: boolean | Mode;
    visible?: boolean | Mode;
}>;
declare const Pager: ((props: IPagerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowedPageSizes?: "auto" | (number | PagerPageSize)[] | undefined;
    displayMode?: DisplayMode | undefined;
    infoText?: string | undefined;
    label?: string | undefined;
    showInfo?: boolean | undefined;
    showNavigationButtons?: boolean | undefined;
    showPageSizeSelector?: boolean | "auto" | undefined;
    visible?: boolean | "auto" | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPagingProps = React.PropsWithChildren<{
    enabled?: boolean;
    pageIndex?: number;
    pageSize?: number;
    defaultPageIndex?: number;
    onPageIndexChange?: (value: number) => void;
    defaultPageSize?: number;
    onPageSizeChange?: (value: number) => void;
}>;
declare const Paging: ((props: IPagingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | undefined;
    pageIndex?: number | undefined;
    pageSize?: number | undefined;
    defaultPageIndex?: number | undefined;
    onPageIndexChange?: ((value: number) => void) | undefined;
    defaultPageSize?: number | undefined;
    onPageSizeChange?: ((value: number) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPatternRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    pattern?: RegExp | string;
    type?: ValidationRuleType;
}>;
declare const PatternRule: ((props: IPatternRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    pattern?: string | RegExp | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPositionProps = React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    boundary?: any | string;
    boundaryOffset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
    collision?: CollisionResolutionCombination | Record<string, any> | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    of?: any | string;
    offset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
}>;
declare const Position: ((props: IPositionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    boundary?: any | string;
    boundaryOffset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    collision?: Record<string, any> | CollisionResolutionCombination | {
        x?: CollisionResolution | undefined;
        y?: CollisionResolution | undefined;
    } | undefined;
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    of?: any | string;
    offset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRangeRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    max?: Date | number | string;
    message?: string;
    min?: Date | number | string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
}>;
declare const RangeRule: ((props: IRangeRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    max?: string | number | Date | undefined;
    message?: string | undefined;
    min?: string | number | Date | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRemoteOperationsProps = React.PropsWithChildren<{
    filtering?: boolean;
    grouping?: boolean;
    paging?: boolean;
    sorting?: boolean;
}>;
declare const RemoteOperations: ((props: IRemoteOperationsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    filtering?: boolean | undefined;
    grouping?: boolean | undefined;
    paging?: boolean | undefined;
    sorting?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRequiredRuleProps = React.PropsWithChildren<{
    message?: string;
    trim?: boolean;
    type?: ValidationRuleType;
}>;
declare const RequiredRule: ((props: IRequiredRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    message?: string | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IScrollingProps = React.PropsWithChildren<{
    scrollByContent?: boolean;
    scrollByThumb?: boolean;
    showScrollbar?: ScrollbarMode;
    useNative?: boolean | Mode;
}>;
declare const Scrolling: ((props: IScrollingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    scrollByContent?: boolean | undefined;
    scrollByThumb?: boolean | undefined;
    showScrollbar?: ScrollbarMode | undefined;
    useNative?: boolean | "auto" | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    timeout?: number;
    mode?: SearchMode;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
}>;
declare const Search: ((props: ISearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    timeout?: number | undefined;
    mode?: SearchMode | undefined;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISearchPanelProps = React.PropsWithChildren<{
    highlightCaseSensitive?: boolean;
    highlightSearchText?: boolean;
    placeholder?: string;
    searchVisibleColumnsOnly?: boolean;
    text?: string;
    visible?: boolean;
    width?: number | string;
    defaultText?: string;
    onTextChange?: (value: string) => void;
}>;
declare const SearchPanel: ((props: ISearchPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    highlightCaseSensitive?: boolean | undefined;
    highlightSearchText?: boolean | undefined;
    placeholder?: string | undefined;
    searchVisibleColumnsOnly?: boolean | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    width?: string | number | undefined;
    defaultText?: string | undefined;
    onTextChange?: ((value: string) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISelectionProps = React.PropsWithChildren<{
    allowSelectAll?: boolean;
    recursive?: boolean;
    selectByClick?: boolean;
    mode?: SingleMultipleOrNone;
    selectAllMode?: SelectAllMode;
    showCheckBoxesMode?: SelectionColumnDisplayMode;
}>;
declare const Selection: ((props: ISelectionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSelectAll?: boolean | undefined;
    recursive?: boolean | undefined;
    selectByClick?: boolean | undefined;
    mode?: SingleMultipleOrNone | undefined;
    selectAllMode?: SelectAllMode | undefined;
    showCheckBoxesMode?: SelectionColumnDisplayMode | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShowProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Show: ((props: IShowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISimpleItemProps = React.PropsWithChildren<{
    aiOptions?: Record<string, any> | {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | template;
        text?: string | undefined;
        visible?: boolean;
    };
    name?: string | undefined;
    template?: ((data: {
        component: dxForm;
        dataField: string;
        editorOptions: Record<string, any>;
        editorType: string;
        name: string;
    }, itemElement: any) => string | any) | template;
    validationRules?: Array<CommonTypes.ValidationRule>;
    visible?: boolean;
    visibleIndex?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const SimpleItem: ((props: ISimpleItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aiOptions?: Record<string, any> | {
        disabled?: boolean | undefined;
        instruction?: string | undefined;
    } | undefined;
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent | undefined;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        location?: LabelLocation | undefined;
        showColon?: boolean | undefined;
        template?: template | ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | undefined;
        text?: string | undefined;
        visible?: boolean | undefined;
    } | undefined;
    name?: string | undefined;
    template?: template | ((data: {
        component: dxForm;
        dataField: string;
        editorOptions: Record<string, any>;
        editorType: string;
        name: string;
    }, itemElement: any) => string | any) | undefined;
    validationRules?: CommonTypes.ValidationRule[] | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISortingProps = React.PropsWithChildren<{
    ascendingText?: string;
    clearText?: string;
    descendingText?: string;
    mode?: SingleMultipleOrNone;
    showSortIndexes?: boolean;
}>;
declare const Sorting: ((props: ISortingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ascendingText?: string | undefined;
    clearText?: string | undefined;
    descendingText?: string | undefined;
    mode?: SingleMultipleOrNone | undefined;
    showSortIndexes?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStringLengthRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    max?: number;
    message?: string;
    min?: number;
    trim?: boolean;
    type?: ValidationRuleType;
}>;
declare const StringLengthRule: ((props: IStringLengthRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    max?: number | undefined;
    message?: string | undefined;
    min?: number | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITabProps = React.PropsWithChildren<{
    alignItemLabels?: boolean;
    badge?: string | undefined;
    colCount?: number;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    disabled?: boolean;
    icon?: string | undefined;
    items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    tabTemplate?: ((tabData: any, tabIndex: number, tabElement: any) => any) | template | undefined;
    template?: ((tabData: any, tabIndex: number, tabElement: any) => any) | template | undefined;
    title?: string | undefined;
    tabRender?: (...params: any) => React.ReactNode;
    tabComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Tab: ((props: ITabProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignItemLabels?: boolean | undefined;
    badge?: string | undefined;
    colCount?: number | undefined;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    } | undefined;
    disabled?: boolean | undefined;
    icon?: string | undefined;
    items?: (dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem)[] | undefined;
    tabTemplate?: template | ((tabData: any, tabIndex: number, tabElement: any) => any) | undefined;
    template?: template | ((tabData: any, tabIndex: number, tabElement: any) => any) | undefined;
    title?: string | undefined;
    tabRender?: ((...params: any) => React.ReactNode) | undefined;
    tabComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITabbedItemProps = React.PropsWithChildren<{
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    itemType?: FormItemType;
    name?: string | undefined;
    tabPanelOptions?: dxTabPanelOptions | undefined;
    tabs?: Array<Record<string, any>> | {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: Record<string, any> | {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: ((tabData: any, tabIndex: number, tabElement: any) => any) | template | undefined;
        template?: ((tabData: any, tabIndex: number, tabElement: any) => any) | template | undefined;
        title?: string | undefined;
    }[];
    visible?: boolean;
    visibleIndex?: number | undefined;
}>;
declare const TabbedItem: ((props: ITabbedItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    itemType?: FormItemType | undefined;
    name?: string | undefined;
    tabPanelOptions?: dxTabPanelOptions | undefined;
    tabs?: Record<string, any>[] | {
        alignItemLabels?: boolean | undefined;
        badge?: string | undefined;
        colCount?: number | undefined;
        colCountByScreen?: Record<string, any> | {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        } | undefined;
        disabled?: boolean | undefined;
        icon?: string | undefined;
        items?: (dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem)[] | undefined;
        tabTemplate?: template | ((tabData: any, tabIndex: number, tabElement: any) => any) | undefined;
        template?: template | ((tabData: any, tabIndex: number, tabElement: any) => any) | undefined;
        title?: string | undefined;
    }[] | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITabPanelOptionsProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    animationEnabled?: boolean;
    dataSource?: Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string;
    deferRendering?: boolean;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    focusStateEnabled?: boolean;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    iconPosition?: TabsIconPosition;
    itemHoldTimeout?: number;
    items?: Array<any | dxTabPanelItem | string>;
    itemTemplate?: ((itemData: any, itemIndex: number, itemElement: any) => string | any) | template;
    itemTitleTemplate?: ((itemData: any, itemIndex: number, itemElement: any) => string | any) | template;
    keyExpr?: ((item: any) => any) | string;
    loop?: boolean;
    noDataText?: string;
    onContentReady?: ((e: TabPanelContentReadyEvent) => void);
    onDisposing?: ((e: TabPanelDisposingEvent) => void);
    onInitialized?: ((e: TabPanelInitializedEvent) => void);
    onItemClick?: ((e: ItemClickEvent) => void);
    onItemContextMenu?: ((e: ItemContextMenuEvent) => void);
    onItemHold?: ((e: ItemHoldEvent) => void);
    onItemRendered?: ((e: ItemRenderedEvent) => void);
    onOptionChanged?: ((e: TabPanelOptionChangedEvent) => void);
    onSelectionChanged?: ((e: SelectionChangedEvent) => void);
    onSelectionChanging?: ((e: SelectionChangingEvent) => void);
    onTitleClick?: ((e: TitleClickEvent) => void);
    onTitleHold?: ((e: TitleHoldEvent) => void) | undefined;
    onTitleRendered?: ((e: TitleRenderedEvent) => void) | undefined;
    repaintChangesOnly?: boolean;
    rtlEnabled?: boolean;
    scrollByContent?: boolean;
    scrollingEnabled?: boolean;
    selectedIndex?: number;
    selectedItem?: any | null;
    showNavButtons?: boolean;
    stylingMode?: TabsStyle;
    swipeEnabled?: boolean;
    tabIndex?: number;
    tabsPosition?: CommonPosition;
    visible?: boolean;
    width?: number | string | undefined;
    defaultItems?: Array<any | dxTabPanelItem | string>;
    onItemsChange?: (value: Array<any | dxTabPanelItem | string>) => void;
    defaultSelectedIndex?: number;
    onSelectedIndexChange?: (value: number) => void;
    defaultSelectedItem?: any | null;
    onSelectedItemChange?: (value: any | null) => void;
    itemRender?: (...params: any) => React.ReactNode;
    itemComponent?: React.ComponentType<any>;
    itemTitleRender?: (...params: any) => React.ReactNode;
    itemTitleComponent?: React.ComponentType<any>;
}>;
declare const TabPanelOptions: ((props: ITabPanelOptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    animationEnabled?: boolean | undefined;
    dataSource?: string | any[] | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null | undefined;
    deferRendering?: boolean | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    focusStateEnabled?: boolean | undefined;
    height?: number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    iconPosition?: TabsIconPosition | undefined;
    itemHoldTimeout?: number | undefined;
    items?: any[] | undefined;
    itemTemplate?: template | ((itemData: any, itemIndex: number, itemElement: any) => string | any) | undefined;
    itemTitleTemplate?: template | ((itemData: any, itemIndex: number, itemElement: any) => string | any) | undefined;
    keyExpr?: string | ((item: any) => any) | undefined;
    loop?: boolean | undefined;
    noDataText?: string | undefined;
    onContentReady?: ((e: TabPanelContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: TabPanelDisposingEvent) => void) | undefined;
    onInitialized?: ((e: TabPanelInitializedEvent) => void) | undefined;
    onItemClick?: ((e: ItemClickEvent) => void) | undefined;
    onItemContextMenu?: ((e: ItemContextMenuEvent) => void) | undefined;
    onItemHold?: ((e: ItemHoldEvent) => void) | undefined;
    onItemRendered?: ((e: ItemRenderedEvent) => void) | undefined;
    onOptionChanged?: ((e: TabPanelOptionChangedEvent) => void) | undefined;
    onSelectionChanged?: ((e: SelectionChangedEvent) => void) | undefined;
    onSelectionChanging?: ((e: SelectionChangingEvent) => void) | undefined;
    onTitleClick?: ((e: TitleClickEvent) => void) | undefined;
    onTitleHold?: ((e: TitleHoldEvent) => void) | undefined;
    onTitleRendered?: ((e: TitleRenderedEvent) => void) | undefined;
    repaintChangesOnly?: boolean | undefined;
    rtlEnabled?: boolean | undefined;
    scrollByContent?: boolean | undefined;
    scrollingEnabled?: boolean | undefined;
    selectedIndex?: number | undefined;
    selectedItem?: any | null;
    showNavButtons?: boolean | undefined;
    stylingMode?: TabsStyle | undefined;
    swipeEnabled?: boolean | undefined;
    tabIndex?: number | undefined;
    tabsPosition?: CommonPosition | undefined;
    visible?: boolean | undefined;
    width?: number | string | undefined;
    defaultItems?: any[] | undefined;
    onItemsChange?: ((value: Array<any | dxTabPanelItem | string>) => void) | undefined;
    defaultSelectedIndex?: number | undefined;
    onSelectedIndexChange?: ((value: number) => void) | undefined;
    defaultSelectedItem?: any | null;
    onSelectedItemChange?: ((value: any | null) => void) | undefined;
    itemRender?: ((...params: any) => React.ReactNode) | undefined;
    itemComponent?: React.ComponentType<any> | undefined;
    itemTitleRender?: ((...params: any) => React.ReactNode) | undefined;
    itemTitleComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITabPanelOptionsItemProps = React.PropsWithChildren<{
    badge?: string;
    disabled?: boolean;
    html?: string;
    icon?: string;
    tabTemplate?: (() => string | any) | template;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    title?: string;
    visible?: boolean;
    tabRender?: (...params: any) => React.ReactNode;
    tabComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const TabPanelOptionsItem: ((props: ITabPanelOptionsItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    badge?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    icon?: string | undefined;
    tabTemplate?: template | (() => string | any) | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    title?: string | undefined;
    visible?: boolean | undefined;
    tabRender?: ((...params: any) => React.ReactNode) | undefined;
    tabComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITextsProps = React.PropsWithChildren<{
    addCard?: string;
    confirmDeleteMessage?: string;
    confirmDeleteTitle?: string;
    deleteCard?: string;
    editCard?: string;
    saveCard?: string;
    clearFilter?: string;
    createFilter?: string;
    filterEnabledHint?: string;
    cancel?: string;
    emptyValue?: string;
    ok?: string;
}>;
declare const Texts: ((props: ITextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    addCard?: string | undefined;
    confirmDeleteMessage?: string | undefined;
    confirmDeleteTitle?: string | undefined;
    deleteCard?: string | undefined;
    editCard?: string | undefined;
    saveCard?: string | undefined;
    clearFilter?: string | undefined;
    createFilter?: string | undefined;
    filterEnabledHint?: string | undefined;
    cancel?: string | undefined;
    emptyValue?: string | undefined;
    ok?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const To: ((props: IToProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarProps = React.PropsWithChildren<{
    disabled?: boolean;
    items?: Array<dxCardViewToolbarItem | PredefinedToolbarItem>;
    multiline?: boolean;
    visible?: boolean | undefined;
}>;
declare const Toolbar: ((props: IToolbarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    disabled?: boolean | undefined;
    items?: (PredefinedToolbarItem | CardViewTypes.ToolbarItem)[] | undefined;
    multiline?: boolean | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    name?: PredefinedToolbarItem | string;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const ToolbarItem: ((props: IToolbarItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    name?: string | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValidationRuleProps = React.PropsWithChildren<{
    message?: string;
    trim?: boolean;
    type?: ValidationRuleType;
    ignoreEmptyValue?: boolean;
    max?: Date | number | string;
    min?: Date | number | string;
    reevaluate?: boolean;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    comparisonTarget?: (() => any);
    comparisonType?: ComparisonOperator;
    pattern?: RegExp | string;
}>;
declare const ValidationRule: ((props: IValidationRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    message?: string | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    ignoreEmptyValue?: boolean | undefined;
    max?: string | number | Date | undefined;
    min?: string | number | Date | undefined;
    reevaluate?: boolean | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean) | undefined;
    comparisonTarget?: (() => any) | undefined;
    comparisonType?: ComparisonOperator | undefined;
    pattern?: string | RegExp | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default CardView;
export { CardView, ICardViewOptions, CardViewRef, AIOptions, IAIOptionsProps, Animation, IAnimationProps, AsyncRule, IAsyncRuleProps, At, IAtProps, BoundaryOffset, IBoundaryOffsetProps, ButtonItem, IButtonItemProps, ButtonOptions, IButtonOptionsProps, CardCover, ICardCoverProps, CardHeader, ICardHeaderProps, CardHeaderItem, ICardHeaderItemProps, CardViewHeaderFilter, ICardViewHeaderFilterProps, CardViewHeaderFilterSearch, ICardViewHeaderFilterSearchProps, CardViewHeaderFilterTexts, ICardViewHeaderFilterTextsProps, CardViewSelection, ICardViewSelectionProps, Change, IChangeProps, ColCountByScreen, IColCountByScreenProps, Collision, ICollisionProps, Column, IColumnProps, ColumnChooser, IColumnChooserProps, ColumnChooserSearch, IColumnChooserSearchProps, ColumnChooserSelection, IColumnChooserSelectionProps, ColumnHeaderFilter, IColumnHeaderFilterProps, ColumnHeaderFilterSearch, IColumnHeaderFilterSearchProps, CompareRule, ICompareRuleProps, CustomOperation, ICustomOperationProps, CustomRule, ICustomRuleProps, Dragging, IDraggingProps, Editing, IEditingProps, EditingTexts, IEditingTextsProps, EmailRule, IEmailRuleProps, EmptyItem, IEmptyItemProps, Field, IFieldProps, FilterBuilder, IFilterBuilderProps, FilterOperationDescriptions, IFilterOperationDescriptionsProps, FilterPanel, IFilterPanelProps, FilterPanelTexts, IFilterPanelTextsProps, Form, IFormProps, Format, IFormatProps, FormItem, IFormItemProps, From, IFromProps, GroupItem, IGroupItemProps, GroupOperationDescriptions, IGroupOperationDescriptionsProps, HeaderFilter, IHeaderFilterProps, HeaderPanel, IHeaderPanelProps, Hide, IHideProps, IndicatorOptions, IIndicatorOptionsProps, Item, IItemProps, Label, ILabelProps, LoadPanel, ILoadPanelProps, Lookup, ILookupProps, My, IMyProps, NumericRule, INumericRuleProps, Offset, IOffsetProps, Pager, IPagerProps, Paging, IPagingProps, PatternRule, IPatternRuleProps, Position, IPositionProps, RangeRule, IRangeRuleProps, RemoteOperations, IRemoteOperationsProps, RequiredRule, IRequiredRuleProps, Scrolling, IScrollingProps, Search, ISearchProps, SearchPanel, ISearchPanelProps, Selection, ISelectionProps, Show, IShowProps, SimpleItem, ISimpleItemProps, Sorting, ISortingProps, StringLengthRule, IStringLengthRuleProps, Tab, ITabProps, TabbedItem, ITabbedItemProps, TabPanelOptions, ITabPanelOptionsProps, TabPanelOptionsItem, ITabPanelOptionsItemProps, Texts, ITextsProps, To, IToProps, Toolbar, IToolbarProps, ToolbarItem, IToolbarItemProps, ValidationRule, IValidationRuleProps };
import type * as CardViewTypes from 'devextreme/ui/card_view_types';
export { CardViewTypes };
